# 黑白琴弦（我的复现版 WP）

## 最终 FLAG

```text
ISCC{OKwbosL4uQZEYfh4151515}
```

---

## 题目信息

- 题目名称：黑白琴弦
- 题目类型：Misc
- flag 格式：`ISCC{}`
- 附件：
  - `attachment-18.rar`

这题的核心不是“单纯扫条码”，而是：

1. 外层解压得到 21 张 `barcode_*.png` 和一个二层压缩包 `score.rar`；
2. 21 张 PNG 中的数据分散在 **三路隐藏源**：
   - PNG `Comment`
   - 第 0 行红色通道 LSB
   - Code128 条码正文
3. 拼齐 `A..U` 共 21 组数据后，重建 `21×21` 二维码；
4. 二维码解出二层 RAR 的密码；
5. 再从 PDF 的隐藏文本和乐谱内容中取出最后数字，拼接 flag。

---

## 一、外层压缩包分析

附件为：

```text
attachment-18.rar
```

先解压：

```bash
7z x attachment-18.rar -oouter
```

得到：

```text
barcode_00.png
barcode_01.png
...
barcode_20.png
score.rar
```

这里可以立刻判断：

- `score.rar` 大概率被加密；
- 21 张条码图一定是第一层密码来源；
- 题目名“黑白琴弦”暗示黑白图像、二维码、乐谱、琴键等二次结构。

---

## 二、分析 21 张 barcode 图片

最开始很容易只去扫 Code128，但这题真正有效信息分散在三路：

1. PNG `Comment`
2. 第 0 行红通道 LSB
3. Code128 正文

### 1）Code128 正文

批量扫描后，可得到诸如：

```text
G1fd57fG
e1VvTGpS
RmxhZz0=
...
U1fd0e3U
```

其中有些是普通 Base64 文本，有些则正好满足一种统一格式：

```text
字母 + 6 位十六进制 + 相同字母
```

例如：

```text
G1fd57fG
R174a9aR
S1757f1S
U1fd0e3U
```

这些不是普通字符串，而是二维码行数据。

---

### 2）PNG Comment

继续看图片元数据：

```bash
exiftool barcode_00.png
strings barcode_00.png
```

可以发现一批 `Comment` 也是同样格式：

```text
A1fc97fA
E17445dE
F104041F
...
Q175fd2Q
```

---

### 3）第 0 行红通道 LSB

只看条码和 Comment 还不够，必须再读第 0 行红通道 LSB。

提取代码如下：

```python
from PIL import Image

def read_first_row_red_lsb(path):
    img = Image.open(path).convert("RGBA")
    w, h = img.size

    bits = []
    for x in range(w):
        r, g, b, a = img.getpixel((x, 0))
        bits.append(r & 1)

    data = bytearray()
    for i in range(0, len(bits) // 8 * 8, 8):
        v = 0
        for bit in bits[i:i + 8]:
            v = (v << 1) | bit
        data.append(v)

    if not data:
        return ""

    length = data[0]
    return bytes(data[1:1 + length]).decode(errors="ignore")
```

在这一路里能得到：

```text
B104e41B
D174b5dD
J139b1eJ
K1b4b5bK
M106caaM
O1fd7fbO
```

---

## 三、统一三路数据，拼出 A..U 共 21 行

把三路合并后，正好能得到完整的 `A..U`：

```text
A 1fc97f   <- Comment
B 104e41   <- row0 LSB
C 17595d   <- Comment
D 174b5d   <- row0 LSB
E 17445d   <- Comment
F 104041   <- Comment
G 1fd57f   <- Code128
H 001b00   <- Comment
I 1dffc4   <- Code128
J 139b1e   <- row0 LSB
K 1b4b5b   <- row0 LSB
L 041421   <- Comment
M 106caa   <- row0 LSB
N 001422   <- Comment
O 1fd7fb   <- row0 LSB
P 105411   <- Comment
Q 175fd2   <- Comment
R 174a9a   <- Code128
S 1757f1   <- Code128
T 105f12   <- Comment
U 1fd0e3   <- Code128
```

这一步是整题最关键的坑点：

> 不是只靠 Comment，也不是只靠条码正文，而是三路混合取数。

---

## 四、重建 21×21 二维码

每组数据是 6 位 hex：

```text
6 hex = 24 bit
```

题目实际使用每组的 **后 21 bit** 作为二维码的一行：

```python
bits24 = bin(int(hex6, 16))[2:].zfill(24)
row_bits = bits24[-21:]
```

按 `A..U` 排序，就得到一个：

```text
21 × 21 QR Code
```

这正好是 QR Code Version 1 的大小。

生成二维码的代码如下：

```python
from PIL import Image

def save_qr(rows_bits, out_png, scale=12, quiet=4):
    n = 21
    img = Image.new("L", ((n + quiet * 2) * scale, (n + quiet * 2) * scale), 255)

    for y, row in enumerate(rows_bits):
        for x, bit in enumerate(row):
            if bit == "1":
                for yy in range((y + quiet) * scale, (y + quiet + 1) * scale):
                    for xx in range((x + quiet) * scale, (x + quiet + 1) * scale):
                        img.putpixel((xx, yy), 0)

    img.save(out_png)
```

然后用 OpenCV 或 pyzbar 解码：

```python
import cv2

mat = cv2.imread("qr_rebuild.png")
val, pts, straight = cv2.QRCodeDetector().detectAndDecode(mat)
print(val)
```

---

## 五、二维码的真实结果

我本地按上述流程复现出来的二维码结果是：

```text
OKwbosL4uQZEYfh
```

这一点和另一篇 WP 最大不同。

为了确认它不是误扫，我进一步用 `score.rar` 的 **RAR5 头校验**做了验证，结果：

- `OKwbosL4uQZEYfh`：**通过**
- 其他候选：**不通过**

因此它就是 `score.rar` 的真实密码。

---

## 六、解开二层压缩包

使用二维码解出的口令解压：

```bash
7z x score.rar -pOKwbosL4uQZEYfh -oscore_out
```

成功得到：

```text
music score.pdf
```

---

## 七、分析 PDF 隐藏文本

使用 `pypdf` 提取文本：

```python
from pypdf import PdfReader

reader = PdfReader("music score.pdf")
for page in reader.pages:
    print(page.extract_text())
```

输出：

```text
KEY+bnVtYmVyYWJvdmVsaW5l3
```

把 `KEY+` 后面的部分拆开：

- Base64 部分：

```text
bnVtYmVyYWJvdmVsaW5l
```

解码：

```bash
echo bnVtYmVyYWJvdmVsaW5l | base64 -d
```

得到：

```text
numberaboveline
```

再结合最后的 `3`，完整提示就是：

```text
KEY + number above line 3
```

其中：

```text
KEY = OKwbosL4uQZEYfh
```

---

## 八、查看第 3 行上方数字

把 PDF 渲染成图片：

```python
import fitz

doc = fitz.open("music score.pdf")
pix = doc[0].get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False)
pix.save("page1.png")
```

观察乐谱第 3 行上方的指法数字，得到：

```text
4151515
```

这是题目最后一段数字。

---

## 九、拼接最终 flag

根据 PDF 提示：

```text
KEY + number above line 3
```

代入：

```text
KEY = OKwbosL4uQZEYfh
number above line 3 = 4151515
```

得到：

```text
OKwbosL4uQZEYfh4151515
```

包上题目要求的 `ISCC{}`：

```text
ISCC{OKwbosL4uQZEYfh4151515}
```

---

## 十、最终答案

```text
ISCC{OKwbosL4uQZEYfh4151515}
```

---

## 十一、通用化思路总结

这题可抽象成一种通用 Misc 模板：

### 1. 多通道取数

当附件是一组图片时，不要只看单一来源，应同时检查：

- 图像正文（条码、二维码、像素阵列）
- 元数据（Comment / tEXt / EXIF）
- 指定位平面（LSB）

### 2. 字符串格式识别

若出现：

```text
字母 + 固定长度 hex + 相同字母
```

很可能表示：

- 行编号
- 数据内容
- 校验尾字母

### 3. 行重建思路

如果行数很整齐，例如：

- 21 行
- 每行若干 bit

就优先怀疑：

- QR Code
- DataMatrix
- 二维位图

### 4. 二层文件验证

若二维码/条码结果用于压缩包密码，最好做**结构级验证**：

- 能否真正解压
- 或使用头部校验验证密码真伪

不要只凭“看起来像字符串”就认定成功。

### 5. PDF 不只看可见内容

PDF 常见藏法：

- 直接可抽文本
- 压缩流里的隐藏字符串
- 元数据
- 页面不可见对象
- 渲染图中人工读数

---

## 十二、配套脚本

本目录已提供一份通用脚本：

```text
C:\tmp\ISCC2\MISC\2\solve_black_white_strings.py
```

使用方式：

```bash
python solve_black_white_strings.py --root "C:\tmp\ISCC2\MISC\2" --line3-digits 4151515
```

脚本会自动：

1. 解压外层 RAR  
2. 提取三路数据  
3. 重建 QR  
4. 解出 `score.rar`  
5. 抽取 PDF 提示  
6. 拼接最终 flag

