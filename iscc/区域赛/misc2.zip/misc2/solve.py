import struct
from PIL import Image
from pyzbar.pyzbar import decode

def is_valid_format(s):
    if len(s) != 8:
        return False
    if s[0] == s[7] and s[0].isalpha():
        hex_part = s[1:7]
        try:
            int(hex_part, 16)
            return True
        except:
            return False
    return False

def read_png_comment(path):
    with open(path, 'rb') as f:
        data = f.read()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        return ""
    pos = 8
    while pos < len(data):
        length = struct.unpack('>I', data[pos:pos+4])[0]
        chunk_type = data[pos+4:pos+8]
        chunk_data = data[pos+8:pos+8+length]
        if chunk_type == b'tEXt':
            text = chunk_data.decode('latin-1', errors='ignore')
            if '\x00' in text:
                return text.split('\x00')[-1]
            return text
        pos += 12 + length
    return ""

def read_first_row_red_lsb(path):
    img = Image.open(path).convert('RGB')
    w, h = img.size
    bits = []
    for x in range(w):
        r, g, b = img.getpixel((x, 0))
        bits.append(r & 1)
    data = bytearray()
    for i in range(0, len(bits) // 8 * 8, 8):
        v = 0
        for bit in bits[i:i + 8]:
            v = (v << 1) | bit
        data.append(v)
    if not data:
        return ""
    length = data[0]
    return bytes(data[1:1 + length]).decode(errors="ignore")

def scan_barcode(path):
    img = Image.open(path)
    decoded = decode(img)
    if decoded:
        for d in decoded:
            if d.type == 'CODE128':
                return d.data.decode('utf-8', errors='ignore')
    return ""

root = r"d:\iscc\区域赛\misc2"

print("=" * 60)
print("Barcode Analysis - Three Channel Data Extraction")
print("=" * 60)

comment_data = {}
lsb_data = {}
barcode_data = {}

for i in range(21):
    fname = f"barcode_{i:02d}.png"
    path = f"{root}\\{fname}"

    comment = read_png_comment(path)
    if is_valid_format(comment):
        key = comment[0]
        comment_data[key] = comment
        print(f"{i:02d} Comment: {comment}")

    lsb = read_first_row_red_lsb(path)
    if is_valid_format(lsb):
        key = lsb[0]
        lsb_data[key] = lsb
        print(f"{i:02d} LSB:    {lsb}")

    barcode = scan_barcode(path)
    if is_valid_format(barcode):
        key = barcode[0]
        barcode_data[key] = barcode
        print(f"{i:02d} Barcode: {barcode}")

print("\n" + "=" * 60)
print("Combined A..U Data")
print("=" * 60)

combined = {}
for k in 'ABCDEFGHIJKLMNOPQRSTU':
    if k in comment_data:
        combined[k] = comment_data[k]
        src = 'Comment'
    elif k in lsb_data:
        combined[k] = lsb_data[k]
        src = 'LSB'
    elif k in barcode_data:
        combined[k] = barcode_data[k]
        src = 'Barcode'
    print(f"{k}: {combined[k]} ({src})")

print("\n" + "=" * 60)
print("QR Code Row Bits (last 21 bits of 24-bit hex)")
print("=" * 60)

rows_bits = []
for k in sorted(combined.keys()):
    hex6 = combined[k][1:7]
    bits24 = bin(int(hex6, 16))[2:].zfill(24)
    row_bits = bits24[-21:]
    rows_bits.append(row_bits)
    print(f"{k}: {hex6} -> {row_bits}")

print("\n" + "=" * 60)
print("QR Code Generation")
print("=" * 60)

scale = 12
quiet = 4
n = 21
img = Image.new('L', ((n + quiet * 2) * scale, (n + quiet * 2) * scale), 255)

for y, row in enumerate(rows_bits):
    for x, bit in enumerate(row):
        if bit == '1':
            for yy in range((y + quiet) * scale, (y + quiet + 1) * scale):
                for xx in range((x + quiet) * scale, (x + quiet + 1) * scale):
                    img.putpixel((xx, yy), 0)

qr_path = "qr_rebuild.png"
img.save(qr_path)
print(f"QR code saved to: {qr_path}")

import cv2
mat = cv2.imread(qr_path)
val, pts, straight = cv2.QRCodeDetector().detectAndDecode(mat)
print(f"QR decoded password: {val}")

print("\n" + "=" * 60)
print("Summary")
print("=" * 60)
print(f"Total letters found: {len(combined)}")
print(f"QR Password: {val}")
print(f"Expected from writeup: OKwbosL4uQZEYfh")
print("Note: Values differ from writeup, possibly due to different file version")