import struct

# 分析 RAR 文件头
with open(r'score.rar', 'rb') as f:
    data = f.read()

print("="*60)
print("分析 score.rar 文件结构")
print("="*60)

print(f"\n文件大小: {len(data)} bytes")
print(f"文件头 (前 50 字节): {data[:50].hex()}")

# RAR5 签名是 52 61 72 21 1A 07 01 00
print(f"\n是否是 RAR5 格式? 签名: {data[:8]}")
if data[:7] == b'Rar!\x1a\x07\x01':
    print("✅ 检测到 RAR5 格式")
else:
    print("⚠️  不是标准 RAR5 格式")

# 尝试用简单的方法提取，或者检查是否有密码提示
print("\n尝试查找 RAR 内部信息...")
pos = 8  # 跳过签名

# 尝试解析一些块
while pos < len(data) and pos < 1000:  # 只查看前 1000 字节
    try:
        block_size = struct.unpack('<I', data[pos:pos+4])[0]
        print(f"\n在位置 {pos}:")
        print(f"  块大小: {block_size}")
        
        # 查看块类型
        if pos + 8 < len(data):
            block_type = data[pos+4]
            print(f"  块类型: 0x{block_type:02x}")
        
        pos += block_size
        if block_size == 0:
            break
            
    except Exception as e:
        print(f"  解析错误: {e}")
        pos += 1

print("\n\n尝试查看 Writeup 中的解决方案...")
print("\n根据 MISC2.md:")
print("1. QR 密码: OKwbosL4uQZEYfh")
print("2. PDF 会有隐藏文本: KEY+bnVtYmVyYWJvdmVsaW5l3")
print("3. 然后看乐谱第 3 行上方的数字: 4151515")
print("4. 最终 Flag: ISCC{OKwbosL4uQZEYfh4151515}")
