from PIL import Image
import zlib
import struct
import os

def read_png_comment(path):
    with open(path, 'rb') as f:
        data = f.read()

    if data[:8] != b'\x89PNG\r\n\x1a\n':
        return ""

    pos = 8
    while pos < len(data):
        length = struct.unpack('>I', data[pos:pos+4])[0]
        chunk_type = data[pos+4:pos+8]
        chunk_data = data[pos+8:pos+8+length]
        crc = struct.unpack('>I', data[pos+8+length:pos+12+length])[0]

        if chunk_type == b'IEND':
            break

        if chunk_type == b'tEXt':
            return chunk_data.decode('latin-1', errors='ignore').split('\x00')[-1]

        pos += 12 + length

    return ""

def read_first_row_red_lsb(path):
    img = Image.open(path).convert("RGBA")
    w, h = img.size

    bits = []
    for x in range(w):
        r, g, b, a = img.getpixel((x, 0))
        bits.append(r & 1)

    data = bytearray()
    for i in range(0, len(bits) // 8 * 8, 8):
        v = 0
        for bit in bits[i:i + 8]:
            v = (v << 1) | bit
        data.append(v)

    if not data:
        return ""

    length = data[0]
    return bytes(data[1:1 + length]).decode(errors="ignore")

def scan_barcode(path):
    try:
        from pyzbar.pyzbar import decode
        img = Image.open(path)
        decoded = decode(img)
        if decoded:
            for d in decoded:
                if d.type == 'CODE128':
                    return d.data.decode('utf-8', errors='ignore')
        return ""
    except Exception as e:
        return ""

def is_valid_format(s):
    if len(s) != 8:
        return False
    if s[0] == s[7] and s[0].isalpha():
        hex_part = s[1:7]
        try:
            int(hex_part, 16)
            return True
        except:
            return False
    return False

root = r"d:\iscc\区域赛\misc2"

comment_data = {}
lsb_data = {}
barcode_data = {}

for i in range(21):
    fname = f"barcode_{i:02d}.png"
    path = os.path.join(root, fname)

    comment = read_png_comment(path)
    if is_valid_format(comment):
        key = comment[0]
        comment_data[key] = comment

    lsb = read_first_row_red_lsb(path)
    if is_valid_format(lsb):
        key = lsb[0]
        lsb_data[key] = lsb

    barcode = scan_barcode(path)
    if is_valid_format(barcode):
        key = barcode[0]
        barcode_data[key] = barcode

    print(f"{i:02d}: comment={comment!r}, lsb={lsb!r}, barcode={barcode!r}")

print("\n=== Comment Data ===")
for k in sorted(comment_data.keys()):
    print(f"{k}: {comment_data[k]}")

print("\n=== LSB Data ===")
for k in sorted(lsb_data.keys()):
    print(f"{k}: {lsb_data[k]}")

print("\n=== Barcode Data ===")
for k in sorted(barcode_data.keys()):
    print(f"{k}: {barcode_data[k]}")

print("\n=== Combined A..U ===")
combined = {}
for k in 'ABCDEFGHIJKLMNOPQRSTU':
    if k in comment_data:
        combined[k] = comment_data[k]
    elif k in lsb_data:
        combined[k] = lsb_data[k]
    elif k in barcode_data:
        combined[k] = barcode_data[k]

for k in sorted(combined.keys()):
    print(f"{k}: {combined[k]}")

rows_bits = []
for k in sorted(combined.keys()):
    hex6 = combined[k][1:7]
    bits24 = bin(int(hex6, 16))[2:].zfill(24)
    row_bits = bits24[-21:]
    rows_bits.append(row_bits)
    print(f"{k}: hex={hex6}, bits24={bits24}, row={row_bits}")

qr_path = os.path.join(root, "qr_rebuild.png")
scale = 12
quiet = 4
n = 21
img = Image.new("L", ((n + quiet * 2) * scale, (n + quiet * 2) * scale), 255)

for y, row in enumerate(rows_bits):
    for x, bit in enumerate(row):
        if bit == "1":
            for yy in range((y + quiet) * scale, (y + quiet + 1) * scale):
                for xx in range((x + quiet) * scale, (x + quiet + 1) * scale):
                    img.putpixel((xx, yy), 0)

img.save(qr_path)
print(f"\nQR code saved to {qr_path}")

import cv2
mat = cv2.imread(qr_path)
val, pts, straight = cv2.QRCodeDetector().detectAndDecode(mat)
print(f"QR decoded: {val!r}")