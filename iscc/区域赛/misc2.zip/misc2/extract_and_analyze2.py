import rarfile
import os
import fitz  # PyMuPDF

def extract_rar(password, output_dir):
    """尝试解压 RAR 文件"""
    try:
        os.makedirs(output_dir, exist_ok=True)
        rf = rarfile.RarFile(r'score.rar')
        rf.extractall(output_dir, pwd=password)
        print(f"✅ 使用口令 '{password}' 解压成功！")
        return True
    except rarfile.RarWrongPassword:
        print(f"❌ 口令 '{password}' 错误")
        return False
    except Exception as e:
        print(f"⚠️  解压时出错: {e}")
        return False

def analyze_pdf(pdf_path):
    """分析 PDF 文件，提取文本和检查隐藏内容"""
    print(f"\n{'='*60}")
    print(f"分析 PDF: {pdf_path}")
    print(f"{'='*60}")
    
    try:
        doc = fitz.open(pdf_path)
        print(f"\n📄 PDF 共 {len(doc)} 页")
        
        for i, page in enumerate(doc):
            print(f"\n--- 第 {i+1} 页 ---")
            
            # 提取所有文本
            text = page.get_text("text")
            if text.strip():
                print("文本内容:")
                print(text)
            
            # 提取 HTML 格式文本（可能包含更多信息）
            html = page.get_text("html")
            print("\nHTML 格式:")
            print(html[:1000] + "..." if len(html) > 1000 else html)
            
            # 尝试获取隐藏层或其他对象
            print("\n页面对象:")
            print(f"  旋转角度: {page.rotation}")
            print(f"  页面大小: {page.rect}")
            
    except Exception as e:
        print(f"分析失败: {e}")

# 主程序
if __name__ == "__main__":
    # 先尝试我们解码的密码
    password = "jb31iRpXB1TqxH4"
    output_dir = "extracted_files"
    
    print("尝试解压 score.rar...")
    if extract_rar(password, output_dir):
        # 列出解压后的文件
        print(f"\n📂 解压的文件:")
        for file in os.listdir(output_dir):
            print(f"  - {file}")
            # 如果是 PDF 文件，分析它
            if file.lower().endswith('.pdf'):
                pdf_path = os.path.join(output_dir, file)
                analyze_pdf(pdf_path)
    
    # 也尝试一下 writeup 提到的密码
    print("\n\n" + "="*60)
    print("尝试使用 writeup 提到的密码...")
    print("="*60)
    alt_password = "OKwbosL4uQZEYfh"
    alt_output_dir = "extracted_files_writeup"
    if extract_rar(alt_password, alt_output_dir):
        print(f"\n📂 解压的文件:")
        for file in os.listdir(alt_output_dir):
            print(f"  - {file}")
            if file.lower().endswith('.pdf'):
                pdf_path = os.path.join(alt_output_dir, file)
                analyze_pdf(pdf_path)
