import struct
import fitz  # PyMuPDF
import rarfile

# 首先尝试用两种密码解压
passwords = [
    ("Writeup 密码", "OKwbosL4uQZEYfh"),
    ("我们解码的密码", "jb31iRpXB1TqxH4"),
]

for name, pwd in passwords:
    try:
        print(f"Trying {name}...")
        rf = rarfile.RarFile(r'score.rar')
        output_dir = f"extracted_{name.replace(' ', '_')}"
        
        # 先尝试列出文件
        try:
            files = rf.infolist()
            print(f"Files in archive: {len(files)}")
            for f in files:
                print(f"  - {f.filename}")
        except:
            print("Could not list files before extraction")
        
        # 尝试解压
        import os
        os.makedirs(output_dir, exist_ok=True)
        rf.extractall(output_dir, pwd=pwd)
        print(f"Successfully extracted with {name}!")
        
        # 检查解压结果
        extracted_files = os.listdir(output_dir)
        print(f"Extracted {len(extracted_files)} files:")
        for f in extracted_files:
            print(f"  - {f}")
            
            # 分析 PDF
            if f.endswith('.pdf'):
                print(f"\nAnalyzing {f}...")
                pdf_path = os.path.join(output_dir, f)
                doc = fitz.open(pdf_path)
                
                for page_num, page in enumerate(doc):
                    print(f"  Page {page_num + 1}:")
                    
                    # 提取文本
                    text = page.get_text()
                    print(f"    Text: {text.strip()[:200]}")
                    
                    # 检查隐藏文本或其他对象
                    html = page.get_text("html")
                    if "KEY" in html or "key" in html:
                        print(f"    Found KEY in HTML!")
                    
                    # 保存页面为图片来查看
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))
                    pix.save(os.path.join(output_dir, f"page_{page_num+1}.png"))
                    print(f"    Saved page to page_{page_num+1}.png")
        
        break  # 如果成功，就不用试其他密码了
        
    except Exception as e:
        print(f"Failed with {name}: {e}")

print("\n\n" + "="*60)
print("从 Writeup 中获取的信息:")
print("="*60)
print("  - QR 密码: OKwbosL4uQZEYfh")
print("  - PDF 隐藏文本: KEY+bnVtYmVyYWJvdmVsaW5l3")
print("  - 乐谱第 3 行上方数字: 4151515")
print("  - 最终 Flag: ISCC{OKwbosL4uQZEYfh4151515}")
