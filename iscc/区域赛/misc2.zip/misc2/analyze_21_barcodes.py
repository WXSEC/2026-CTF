from __future__ import annotations

import argparse
import json
import re
import struct
import zlib
from pathlib import Path

from PIL import Image
from pyzbar.pyzbar import ZBarSymbol, decode


VALID_RE = re.compile(r"^([A-U])([0-9a-fA-F]{6})\1$")


def read_png_text_payloads(path: Path) -> list[str]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        return []

    payloads: list[str] = []
    pos = 8

    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        chunk_type = data[pos + 4 : pos + 8]
        chunk_data = data[pos + 8 : pos + 8 + length]

        if chunk_type == b"tEXt":
            text = chunk_data.decode("latin-1", errors="ignore")
            payloads.append(text.split("\x00", 1)[-1])
        elif chunk_type == b"zTXt":
            parts = chunk_data.split(b"\x00", 1)
            if len(parts) == 2 and len(parts[1]) >= 2:
                compressed = parts[1][1:]
                try:
                    payloads.append(
                        zlib.decompress(compressed).decode("latin-1", errors="ignore")
                    )
                except zlib.error:
                    pass
        elif chunk_type == b"iTXt":
            parts = chunk_data.split(b"\x00", 5)
            if len(parts) == 6:
                _, comp_flag, _, _, _, text_bytes = parts
                try:
                    if comp_flag == b"\x01":
                        text_bytes = zlib.decompress(text_bytes)
                    payloads.append(text_bytes.decode("utf-8", errors="ignore"))
                except zlib.error:
                    pass

        pos += 12 + length
        if chunk_type == b"IEND":
            break

    return payloads


def read_first_row_red_lsb(path: Path) -> tuple[str, list[int]]:
    img = Image.open(path).convert("RGBA")
    width, _ = img.size

    bits = [img.getpixel((x, 0))[0] & 1 for x in range(width)]
    data = bytearray()

    for i in range(0, len(bits) // 8 * 8, 8):
        value = 0
        for bit in bits[i : i + 8]:
            value = (value << 1) | bit
        data.append(value)

    if not data:
        return "", bits

    payload_len = data[0]
    payload = bytes(data[1 : 1 + payload_len]).decode("latin-1", errors="ignore")
    return payload, bits


def decode_code128(path: Path) -> list[str]:
    img = Image.open(path)
    decoded = decode(img, symbols=[ZBarSymbol.CODE128])
    return [item.data.decode("latin-1", errors="ignore") for item in decoded]


def pick_valid_value(values: list[str]) -> str:
    for value in values:
        if VALID_RE.fullmatch(value):
            return value
    return ""


def analyze_image(path: Path) -> dict:
    with Image.open(path) as img:
        width, height = img.size

    comment_candidates = read_png_text_payloads(path)
    comment = pick_valid_value(comment_candidates) or (comment_candidates[0] if comment_candidates else "")

    lsb, bits = read_first_row_red_lsb(path)
    barcode_candidates = decode_code128(path)
    barcode = pick_valid_value(barcode_candidates) or (barcode_candidates[0] if barcode_candidates else "")

    selected = ""
    source = ""
    for candidate_source, candidate_value in (
        ("comment", comment if VALID_RE.fullmatch(comment or "") else ""),
        ("lsb", lsb if VALID_RE.fullmatch(lsb or "") else ""),
        ("barcode", barcode if VALID_RE.fullmatch(barcode or "") else ""),
    ):
        if candidate_value:
            selected = candidate_value
            source = candidate_source
            break

    return {
        "file": path.name,
        "size": f"{width}x{height}",
        "comment": comment,
        "comment_valid": bool(VALID_RE.fullmatch(comment or "")),
        "lsb": lsb,
        "lsb_valid": bool(VALID_RE.fullmatch(lsb or "")),
        "barcode": barcode,
        "barcode_valid": bool(VALID_RE.fullmatch(barcode or "")),
        "selected": selected,
        "source": source,
        "letter": selected[0] if selected else "",
        "hex6": selected[1:7] if selected else "",
        "first_row_red_lsb_bit_count": len(bits),
    }


def rebuild_qr(rows: dict[str, str], output_path: Path, scale: int = 12, quiet: int = 4) -> None:
    letters = "ABCDEFGHIJKLMNOPQRSTU"
    size = 21
    canvas = Image.new("L", ((size + quiet * 2) * scale, (size + quiet * 2) * scale), 255)

    for y, letter in enumerate(letters):
        bits24 = bin(int(rows[letter], 16))[2:].zfill(24)
        row_bits = bits24[-21:]
        for x, bit in enumerate(row_bits):
            if bit == "1":
                for yy in range((y + quiet) * scale, (y + quiet + 1) * scale):
                    for xx in range((x + quiet) * scale, (x + quiet + 1) * scale):
                        canvas.putpixel((xx, yy), 0)

    canvas.save(output_path)


def print_table(results: list[dict]) -> None:
    for item in results:
        selected = f"{item['source']} -> {item['selected']}" if item["selected"] else "no valid payload"
        print(
            f"{item['file']:<14} "
            f"comment={item['comment']!r:<12} "
            f"lsb={item['lsb']!r:<12} "
            f"barcode={item['barcode']!r:<12} "
            f"{selected}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze 21 barcode PNGs and rebuild the QR payload.")
    parser.add_argument("target", nargs="?", default=".", help="Directory containing barcode_*.png")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    parser.add_argument(
        "--qr-out",
        default="qr_from_21_barcodes.png",
        help="Output path for the rebuilt QR image",
    )
    args = parser.parse_args()

    root = Path(args.target)
    files = sorted(root.glob("barcode_*.png"))
    if not files:
        raise SystemExit(f"No barcode_*.png found in {root}")

    results = [analyze_image(path) for path in files]
    rows = {item["letter"]: item["hex6"] for item in results if item["letter"]}

    qr_image_saved = False
    if set(rows) == set("ABCDEFGHIJKLMNOPQRSTU"):
        rebuild_qr(rows, Path(args.qr_out))
        qr_image_saved = True

    summary = {
        "results": results,
        "rows": rows,
        "qr_image": args.qr_out if qr_image_saved else "",
    }

    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    print_table(results)
    print()
    print("Combined rows:")
    for letter in "ABCDEFGHIJKLMNOPQRSTU":
        print(f"{letter}={rows.get(letter, '')}")

    if qr_image_saved:
        print()
        print(f"QR image saved to: {args.qr_out}")


if __name__ == "__main__":
    main()
