import rarfile
import os

def check_and_extract():
    """检查 RAR 文件并尝试两种密码"""
    
    # 打开 RAR 文件查看内容
    print("="*60)
    print("检查 score.rar 内容")
    print("="*60)
    
    try:
        rf = rarfile.RarFile(r'score.rar')
        print("RAR 文件信息:")
        
        # 尝试不使用密码列出文件（RAR5 密码会隐藏文件名）
        try:
            print("\n尝试列出文件...")
            file_list = rf.infolist()
            if file_list:
                print("RAR 包含以下文件:")
                for f in file_list:
                    print(f"  - {f.filename} (大小: {f.file_size} bytes)")
        except Exception as e:
            print(f"无法列出文件 (可能被加密): {e}")
        
        # 尝试第一种密码
        print("\n\n尝试密码 1: jb31iRpXB1TqxH4")
        try:
            os.makedirs("extracted_1", exist_ok=True)
            rf.extractall("extracted_1", pwd="jb31iRpXB1TqxH4")
            print("✅ 密码 1 成功！")
            print(f"解压后的文件: {os.listdir('extracted_1')}")
        except Exception as e:
            print(f"❌ 密码 1 失败: {e}")
        
        # 尝试第二种密码
        print("\n\n尝试密码 2: OKwbosL4uQZEYfh")
        try:
            os.makedirs("extracted_2", exist_ok=True)
            rf2 = rarfile.RarFile(r'score.rar')
            rf2.extractall("extracted_2", pwd="OKwbosL4uQZEYfh")
            print("✅ 密码 2 成功！")
            print(f"解压后的文件: {os.listdir('extracted_2')}")
        except Exception as e:
            print(f"❌ 密码 2 失败: {e}")
            
    except Exception as e:
        print(f"打开 RAR 文件失败: {e}")

if __name__ == "__main__":
    check_and_extract()
