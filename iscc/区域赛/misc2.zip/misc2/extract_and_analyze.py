import rarfile
import os
from pypdf import PdfReader
import fitz  # PyMuPDF

def extract_rar(password, output_dir):
    """尝试解压 RAR 文件"""
    try:
        os.makedirs(output_dir, exist_ok=True)
        rf = rarfile.RarFile(r'score.rar')
        rf.extractall(output_dir, pwd=password)
        print(f"✅ 使用口令 '{password}' 解压成功！")
        return True
    except rarfile.RarWrongPassword:
        print(f"❌ 口令 '{password}' 错误")
        return False
    except Exception as e:
        print(f"⚠️  解压时出错: {e}")
        return False

def analyze_pdf(pdf_path):
    """分析 PDF 文件，提取文本和检查隐藏内容"""
    print(f"\n{'='*60}")
    print(f"分析 PDF: {pdf_path}")
    print(f"{'='*60}")
    
    # 1. 使用 pypdf 提取文本
    print("\n📄 使用 pypdf 提取文本:")
    try:
        reader = PdfReader(pdf_path)
        for i, page in enumerate(reader.pages):
            text = page.extract_text()
            if text.strip():
                print(f"\n第 {i+1} 页:")
                print(text)
    except Exception as e:
        print(f"pypdf 提取文本失败: {e}")
    
    # 2. 使用 PyMuPDF 更全面地提取
    print("\n🔍 使用 PyMuPDF 全面分析:")
    try:
        doc = fitz.open(pdf_path)
        for i, page in enumerate(doc):
            # 提取所有文本（包括隐藏和带格式的）
            text = page.get_text("text")
            html = page.get_text("html")
            dict_text = page.get_text("dict")
            
            print(f"\n第 {i+1} 页:")
            print("文本:")
            print(text)
            
            # 检查是否有隐藏的注释或对象
            annots = page.annots()
            if annots:
                print("\n📝 页面注释:")
                for annot in annots:
                    print(annot)
    except Exception as e:
        print(f"PyMuPDF 分析失败: {e}")

# 主程序
if __name__ == "__main__":
    password = "jb31iRpXB1TqxH4"  # 我们解码的密码
    output_dir = "extracted_files"
    
    print("尝试解压 score.rar...")
    if extract_rar(password, output_dir):
        # 列出解压后的文件
        print(f"\n📂 解压的文件:")
        for file in os.listdir(output_dir):
            print(f"  - {file}")
            # 如果是 PDF 文件，分析它
            if file.lower().endswith('.pdf'):
                pdf_path = os.path.join(output_dir, file)
                analyze_pdf(pdf_path)
    
    # 也尝试一下 writeup 提到的密码
    print("\n\n" + "="*60)
    print("尝试使用 writeup 提到的密码...")
    print("="*60)
    alt_password = "OKwbosL4uQZEYfh"
    alt_output_dir = "extracted_files_writeup"
    if extract_rar(alt_password, alt_output_dir):
        print(f"\n📂 解压的文件:")
        for file in os.listdir(alt_output_dir):
            print(f"  - {file}")
            if file.lower().endswith('.pdf'):
                pdf_path = os.path.join(alt_output_dir, file)
                analyze_pdf(pdf_path)
