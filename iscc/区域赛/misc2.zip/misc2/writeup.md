# 黑白琴弦 WP

## 题目分析

附件解压后可以得到两部分内容：

- `21` 张条码图片 `barcode_00.png` 到 `barcode_20.png`
- 一个二层压缩包 `score.rar`

看到图片数量正好是 `21`，很容易联想到它们可能对应一个 `21 x 21` 的二维码，也就是每张图片提供二维码的一行数据。  
因此第一步先处理这 `21` 张条码图。

## 第一步：识别 21 张 Code128 条码

我这里使用的是在线 Code128 识别工具，逐张上传图片识别即可，例如：

- [ZXing Decoder Online](https://zxing.org/w/decode.jspx)
- [Aspose Code 128 Reader](https://products.aspose.app/barcode/recognize/code128)

识别后的结果并不都是有用信息，其中混有很多普通字符串、Base64 字符串和干扰项，例如：

```text
RmxhZz0=
irbUwItZ
qpCLmXSj
y54o5c6P
G1fd57fG
RQ1CMX1Q
D17595dD
n7fOZ30K
aW5ub3Rl
Sk5e0Ywa
MGR3VEN9
H000a00H
K07d362K
4oUKvCQ2
tEHcR0Jl
517NdjBY
F105341F
O1fdf42O
N001714N
cDlCWW5n
T10529cT
R175aa8R
A1fc57fA
L0dbbaeL
J01249fJ
P104a9fP
E174a5dE
I1f73aaI
B104541B
C17445dC
U1fd472U
S175148S
M13ed29M
Q175367Q
```

## 第二步：筛选出真正有结构的数据

观察这些结果可以发现，真正有用的一类字符串都满足同一种格式：

```text
字母 + 6位十六进制 + 相同字母
```

例如：

```text
A1fc57fA
B104541B
D17595dD
Q175367Q
```

这说明：

- 首字母很可能是这一行的编号
- 末尾重复字母起到包裹或校验作用
- 中间 `6` 位十六进制才是真正的数据

因此，把所有识别结果按下面的规则筛选即可：

- 开头是一个大写字母
- 结尾还是同一个大写字母
- 中间正好是 `6` 位十六进制

写成正则就是：

```text
^([A-U])([0-9a-fA-F]{6})\1$
```

这样就能把像 `RmxhZz0=`、`irbUwItZ` 这样的无关结果全部过滤掉，只保留真正的行数据。

## 第三步：提取中间 6 位 hex

对筛选后的每个字符串，去掉首尾字母，只保留中间 `6` 位十六进制。例如：

```text
A1fc57fA  ->  A 1fc57f
B104541B  ->  B 104541
C17445dC  ->  C 17445d
D17595dD  ->  D 17595d
```

全部整理后得到：

```text
A 1fc57f
B 104541
C 17445d
D 17595d
E 174a5d
F 105341
G 1fd57f
H 000a00
I 1f73aa
J 01249f
K 07d362
L 0dbbae
M 13ed29
N 001714
O 1fdf42
P 104a9f
Q 175367
R 175aa8
S 175148
T 10529c
U 1fd472
```

这里有两个很关键的观察：

1. 正好得到 `A~U` 共 `21` 组数据。
2. 每组都是 `6` 位 hex，也就是 `24 bit`。

这和前面 `21` 张图片、`21 x 21` 二维码的猜想正好对应上。

## 第四步：将 21 组 hex 重建成二维码

每组数据都是 `6` 位十六进制，对应 `24 bit`。  
但二维码每一行只需要 `21 bit`，所以做法是：

- 先把每组 hex 转成 `24` 位二进制
- 再取最后 `21` 位
- 按 `A` 到 `U` 的顺序依次作为二维码的第 `1` 到第 `21` 行

我使用的脚本如下：

```python
from PIL import Image

data = {
    'A': '1fc57f', 'B': '104541', 'C': '17445d', 'D': '17595d', 'E': '174a5d',
    'F': '105341', 'G': '1fd57f', 'H': '000a00', 'I': '1f73aa', 'J': '01249f',
    'K': '07d362', 'L': '0dbbae', 'M': '13ed29', 'N': '001714', 'O': '1fdf42',
    'P': '104a9f', 'Q': '175367', 'R': '175aa8', 'S': '175148', 'T': '10529c',
    'U': '1fd472'
}

rows = []
for ch in "ABCDEFGHIJKLMNOPQRSTU":
    bits = bin(int(data[ch], 16))[2:].zfill(24)[-21:]
    rows.append(bits)

size = 21
scale = 12
quiet = 4
img = Image.new("L", ((size + quiet * 2) * scale, (size + quiet * 2) * scale), 255)

for y, row in enumerate(rows):
    for x, bit in enumerate(row):
        if bit == "1":
            for yy in range((y + quiet) * scale, (y + quiet + 1) * scale):
                for xx in range((x + quiet) * scale, (x + quiet + 1) * scale):
                    img.putpixel((xx, yy), 0)

img.save("qr_rebuild.png")
print("saved -> qr_rebuild.png")
```

生成出的二维码扫描后，得到：

```text
IvrOkCp6Bfk7Qgr
```

这就是二层压缩包 `score.rar` 的密码。

## 第五步：解压二层压缩包

使用刚才得到的密码解压：

```bash
7z x score.rar -pIvrOkCp6Bfk7Qgr
```

解压后得到一个 PDF 乐谱文件。

## 第六步：提取 PDF 中的隐藏提示

打开 PDF 后，把鼠标移动到某个位置并尝试选中内容，可以发现有一段隐藏文本。复制出来是：

```text
KEY+bnVtYmVyYWJvdmVsaW5l3
```

把其中的 Base64 部分：

```text
bnVtYmVyYWJvdmVsaW5l
```

解码后得到：

```text
numberaboveline
```

所以这段提示的含义就是：

```text
KEY + number above line 3
```

其中 `KEY` 显然就是前面二维码扫出来的结果：

```text
IvrOkCp6Bfk7Qgr
```

## 第七步：从乐谱中取数字

根据提示去看乐谱第 `3` 行上方的数字，可以读出：

```text
4151515
```

于是最终答案就是：

```text
IvrOkCp6Bfk7Qgr4151515
```

## 最终答案

```text
IvrOkCp6Bfk7Qgr4151515
```

如果平台要求带外层 flag 格式，再按题目实际要求提交即可。

## 总结

这题的关键不只是“扫条码”，而是要继续观察数据结构：

- `21` 张图片对应 `21 x 21` 二维码
- 有效条码结果满足 `字母 + 6位hex + 相同字母`
- 去掉首尾字母后得到二维码每一行的数据
- 重建二维码后拿到 `score.rar` 的密码
- 再结合 PDF 隐藏提示和乐谱内容拼出最终结果

整体是一道条码识别、二维码重建、PDF 隐藏信息提取和乐谱观察结合起来的 Misc 题。
