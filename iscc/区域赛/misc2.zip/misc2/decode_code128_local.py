from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageOps
from pyzbar.pyzbar import ZBarSymbol, decode


def decode_variants(image_path: Path) -> list[tuple[str, str]]:
    """Try a few light preprocessing variants for CODE128 decoding."""
    img = Image.open(image_path).convert("L")

    variants = [
        ("gray", img),
        ("autocontrast", ImageOps.autocontrast(img)),
        ("invert", ImageOps.invert(img)),
        ("binary_96", img.point(lambda p: 255 if p > 96 else 0)),
        ("binary_128", img.point(lambda p: 255 if p > 128 else 0)),
        ("binary_160", img.point(lambda p: 255 if p > 160 else 0)),
    ]

    results: list[tuple[str, str]] = []
    seen: set[str] = set()

    for name, variant in variants:
        decoded = decode(variant, symbols=[ZBarSymbol.CODE128])
        for item in decoded:
            text = item.data.decode("utf-8", errors="replace")
            key = f"{item.type}:{text}"
            if key not in seen:
                seen.add(key)
                results.append((name, text))

    return results


def scan_path(target: Path) -> None:
    if target.is_file():
        files = [target]
    else:
        files = sorted(target.glob("barcode_*.png"))

    if not files:
        print(f"No barcode images found in: {target}")
        return

    for file in files:
        results = decode_variants(file)
        if results:
            joined = ", ".join(f"{variant} -> {text}" for variant, text in results)
            print(f"{file.name}: {joined}")
        else:
            print(f"{file.name}: decode failed")


def main() -> None:
    parser = argparse.ArgumentParser(description="Decode local CODE128 barcode PNGs.")
    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="A barcode PNG file or a directory containing barcode_*.png",
    )
    args = parser.parse_args()
    scan_path(Path(args.target))


if __name__ == "__main__":
    main()
