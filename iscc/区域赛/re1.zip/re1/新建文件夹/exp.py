def solve():
    seed = 0x1A

    target = [
       0x29, 0x4E, 0x2F, 0x5A, 0x4B, 0x4C, 0x29, 0x5B, 0x4C, 0x2F, 0x49, 0x77, 0x43, 0x6F, 0x34, 0x28, 0x33, 0x66, 0x41, 0x24
       ]

    flag_inner = ""
    curr_seed = seed

    for enc_char in target:

        curr_seed = (curr_seed * 1103515245 + 12345) & 0xFFFFFFFF

        shift = ((curr_seed >> 24) & 0xFF) % 95

        plain_code = ((enc_char - 32 - shift) % 95) + 32
        flag_inner += chr(plain_code)

    print(f"解密成功！内部字符串为: {flag_inner}")
    print(f"最终 Flag: ISCC{{{flag_inner}}}")

if __name__ == "__main__":
    solve()