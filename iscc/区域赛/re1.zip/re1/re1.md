# re1

下面给一份可以一步步复现的完整 WP。假设文件名是 caterpillar36.exe。

## 1. 查壳与基本信息

file caterpillar36.exe
strings -a -n 4 caterpillar36.exe | head

结果能看到：

PE32+ executable for MS Windows 6.00 (console), x86-64
UPX0
UPX1
UPX2
UPX!
5.02

说明这是一个 **64 位 Windows PE**，并且被 **UPX** 加壳。

## 2. 查看 PE 段信息

用 Python 解析 PE 头：

import struct
from pathlib import Path

b = Path("caterpillar36.exe").read_bytes()

pe = struct.unpack_from("<I", b, 0x3c)[0]
print(hex(pe), b[pe:pe+4])

Machine, NumSections, TimeDate, PtrSym, NumSym, SizeOpt, Chars = struct.unpack_from("<HHIIIHH", b, pe + 4)

print("Machine:", hex(Machine))
print("Sections:", NumSections)

opt_off = pe + 24
entry = struct.unpack_from("<I", b, opt_off + 16)[0]
imagebase = struct.unpack_from("<Q", b, opt_off + 24)[0]

print("Entry RVA:", hex(entry))
print("ImageBase:", hex(imagebase))

sec_off = opt_off + SizeOpt

for i in range(NumSections):
off = sec_off + 40 * i
name = b[off:off+8].split(b"\x00")[0]
vs, va, rawsz, rawptr = struct.unpack_from("<IIII", b, off + 8)
print(i, name, "VA =", hex(va), "VS =", hex(vs), "RawPtr =", hex(rawptr), "RawSize =", hex(rawsz))

输出类似：

Entry RVA: 0x48da0
ImageBase: 0x140000000

0 b'UPX0' VA = 0x1000  VS = 0x2e000 RawPtr = 0x400   RawSize = 0x0
1 b'UPX1' VA = 0x2f000 VS = 0x1b000 RawPtr = 0x400   RawSize = 0x1ac00
2 b'UPX2' VA = 0x4a000 VS = 0x1000  RawPtr = 0x1b000 RawSize = 0x200

重点：

UPX1 RawPtr = 0x400

压缩数据从文件偏移 0x400 开始。

## 3. 手动脱 UPX

入口点反汇编可以看到 UPX stub：

objdump -D -Mintel,x86-64 caterpillar36.exe | grep -A80 140048da0

关键逻辑：

140048da4: lea rsi,[rip+0xfffffffffffe6255]  ; 0x14002f000
140048dab: lea rdi,[rsi-0x2e000]             ; 0x140001000
140048db3: mov eax,0x46cc3
140048dc2: mov esi,0x19d9c

含义：

压缩输入地址：0x14002f000
解压输出地址：0x140001000
期望解压大小：0x46cc3
压缩数据大小：0x19d9c

UPX 这里使用的是 raw LZMA 数据。前两个字节是 LZMA 参数：

文件偏移 0x400 开始：
1a 03 ...

解析：

pb = 0x1a & 7 = 2
lc = 0x03 & 0xf = 3
lp = 0x03 >> 4 = 0

可以用 Python 的 lzma 模块直接解：

import lzma
from pathlib import Path

data = Path("caterpillar36.exe").read_bytes()

raw_ptr = 0x400
comp_size = 0x19d9c
out_size = 0x46cc3

comp = data[raw_ptr:raw_ptr + comp_size]

p0, p1 = comp[0], comp[1]
lzma_data = comp[2:]

pb = p0 & 7
lc = p1 & 0xf
lp = p1 >> 4

print("lc =", lc, "lp =", lp, "pb =", pb)

dec = lzma.LZMADecompressor(
format=lzma.FORMAT_RAW,
filters=[
{
"id": lzma.FILTER_LZMA1,
"dict_size": 0x100000,
"lc": lc,
"lp": lp,
"pb": pb,
}
],
)

out = dec.decompress(lzma_data, max_length=out_size)

print("decompressed size:", hex(len(out)))
Path("unpacked_raw.bin").write_bytes(out)

得到：

decompressed size: 0x46cc1

少两个字节不影响后面分析，关键逻辑和数据都已经出来了。

## 4. 搜字符串

strings -a -n 4 unpacked_raw.bin | grep -i -E "ISCC|flag|Success|Fail|Invalid|Length"

可以看到：

Input flag in the format ISCC{xxxxxxxxxxxxxxxxxxxx}:
Input too long.
Invalid input length.
Invalid input format. Expected ISCC{xxxxxxxxxxxxxxxxxxxx}.
Length error.
Success!
Fail!

说明 flag 格式是：

ISCC{xxxxxxxxxxxxxxxxxxxx}

中间正好 **20 个字符**。

## 5. 定位主逻辑

原始 ImageBase 是：

0x140000000

解压数据加载到：

0x140001000

所以 unpacked_raw.bin 的文件偏移 0 对应虚拟地址：

0x140001000

反汇编 raw 数据：

objdump -D -b binary -m i386:x86-64 -Mintel,x86-64 \
--adjust-vma=0x140001000 unpacked_raw.bin > unpacked.asm

找关键字符串地址：

from pathlib import Path

b = Path("unpacked_raw.bin").read_bytes()
base = 0x140001000

for s in [
b"Input flag",
b"Success!",
b"Fail!",
b"Invalid input format",
b"Invalid input length",
]:
off = b.find(s)
print(s, hex(off), hex(base + off))

输出：

Input flag              0x2b980 0x14002c980
Success!                0x2ba40 0x14002ca40
Fail!                   0x2ba4c 0x14002ca4c
Invalid input format    0x2b9f0 0x14002c9f0
Invalid input length    0x2b9d8 0x14002c9d8

在 unpacked.asm 里搜索 0x14002ca40 或 0x14002c980，可以定位到主函数附近：

grep -n "14002ca40\|14002c980\|14002c9f0\|14002c9d8" unpacked.asm

主逻辑大概在：

0x140006d30 ~ 0x140007364

## 6. 分析输入检查

核心检查如下：

cmp rax,0x1a

要求输入长度是 0x1a = 26。

随后逐字节比较：

cmp byte ptr [input+0], 'I'
cmp byte ptr [input+1], 'S'
cmp byte ptr [input+2], 'C'
cmp byte ptr [input+3], 'C'
cmp byte ptr [input+4], '{'
cmp byte ptr [input+25], '}'

所以格式是：

ISCC{20 chars}

然后程序会把中间 20 字节取出来参与校验。

## 7. 找到加密比较逻辑

关键加密循环在这里：

1400072c4: imul   r10d,r10d,0x41c64e6d
1400072cb: mov    eax,0x58ed2309
1400072d0: add    r10d,0x3039
1400072d7: mov    ecx,r10d
1400072da: shr    ecx,0x18

...

1400072ef: movzx  eax,BYTE PTR [input+i]
1400072f5: sub    al,0x20

...

1400072fe: add    r9d,eax
...
140007315: imul   eax,eax,0x5f
140007318: sub    r9d,eax
14000731b: add    r9b,0x20

140007337: lea    rdx,[rip+0x37cda] ; 0x14003f018
140007342: call   memcmp

整理成伪代码：

seed = 0x24;

for i in range(20):
seed = seed * 0x41c64e6d + 0x3039;
r = (seed >> 24) % 95;

enc[i] = ((input[i] - 0x20 + r) % 95) + 0x20;

memcmp(enc, target, 20);

其中：

95 = 0x5f
0x20 到 0x7e 是可打印 ASCII 范围

也就是说它把中间 20 个字符在可打印字符范围内做了一个随机偏移。

## 8. 提取 target

程序比较的目标地址是：

0x14003f018

换成 raw 文件偏移：

0x14003f018 - 0x140001000 = 0x3e018

提取数据：

from pathlib import Path

b = Path("unpacked_raw.bin").read_bytes()
base = 0x140001000

target_addr = 0x14003f018
target_off = target_addr - base

target = b[target_off:target_off + 20]
print(target)

输出：

b'*Y{4ZNrxfAYO,a_za&XG'

即：

*Y{4ZNrxfAYO,a_za&XG

## 9. 逆向还原中间 20 字节

已知：

enc[i] = ((plain[i] - 0x20 + r) % 95) + 0x20

反推：

plain[i] = ((enc[i] - 0x20 - r) % 95) + 0x20

写脚本：

target = b"*Y{4ZNrxfAYO,a_za&XG"

seed = 0x24
plain = []

for c in target:
seed = (seed * 0x41c64e6d + 0x3039) & 0xffffffff
r = (seed >> 24) % 95

p = ((c - 0x20 - r) % 95) + 0x20
plain.append(p)

plain = bytes(plain)

print(plain)
print(b"ISCC{" + plain + b"}")

输出：

b'J\'"D* `p6?B}sWNgBe)i'
b'ISCC{J\'"D* `p6?B}sWNgBe)i}'

## 10. 最终 flag

ISCC{J'"D* `p6?B}sWNgBe)i}

注意两个容易复制错的地方：

J'"D* `p6?B}sWNgBe)i

其中：

1. J 后面是单引号 '

1. 单引号后面是双引号 "

1. * 后面有一个空格

1. 空格后面是反引号 `

1. 中间 20 字节里本身包含一个 }，这是正常的，程序只检查最后一个字符也是 }。