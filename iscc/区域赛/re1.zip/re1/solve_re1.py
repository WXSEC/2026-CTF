import lzma
import struct
from pathlib import Path


def unpack_sample(path: str) -> bytes:
    data = Path(path).read_bytes()

    # UPX1 raw data starts at 0x400 for this sample.
    # The first 2 bytes encode raw LZMA parameters used by the stub.
    comp = data[0x400:0x1AC00]
    p0, p1 = comp[0], comp[1]
    pb = p0 & 7
    lc = p1 & 0xF
    lp = p1 >> 4

    dec = lzma.LZMADecompressor(
        format=lzma.FORMAT_RAW,
        filters=[
            {
                "id": lzma.FILTER_LZMA1,
                "dict_size": 0x100000,
                "lc": lc,
                "lp": lp,
                "pb": pb,
            }
        ],
    )

    # The unpacked image length observed from the sample is 0x46CC3.
    return dec.decompress(comp[2:], max_length=0x46CC3)


def recover_flag(unpacked: bytes) -> str:
    seed = struct.unpack_from("<I", unpacked, 0x3E010)[0]
    target = unpacked[0x3E018:0x3E018 + 20]

    plain = []
    cur = seed
    for c in target:
        cur = (cur * 0x41C64E6D + 0x3039) & 0xFFFFFFFF
        r = (cur >> 24) % 95
        p = ((c - 0x20 - r) % 95) + 0x20
        plain.append(p)

    middle = bytes(plain).decode("latin1")
    return f"ISCC{{{middle}}}"


def main() -> None:
    unpacked = unpack_sample("caterpillar26.exe")
    flag = recover_flag(unpacked)
    print(flag)


if __name__ == "__main__":
    main()
