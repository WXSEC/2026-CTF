---
title: "毛毛虫的逆袭"
ctf: "ISCC 区域赛"
date: 2026-05-13
category: reverse
difficulty: medium
points: 0
flag_format: "ISCC{...}"
author: "Codex"
---

# 毛毛虫的逆袭

## Summary

这题是一个 64 位 Windows PE，外层被 UPX 变种壳包装。核心思路是先手动按题目样本的 UPX stub 参数解出 `unpacked_raw.bin`，再定位 flag 校验逻辑，恢复 20 字节中间串。

`re1.md` 给的是同结构旧样本的分析流程，但附件数据和常量不完全相同。当前样本 `caterpillar26.exe` 的关键差异是随机种子不是旧文档中的 `0x24`，而是 `0x1a`，所以不能直接套用文档里的最终 flag。

## Solution

### Step 1: 脱壳并定位真实校验数据

先看样本基础信息，可以从字符串和 PE 结构看出它是 UPX 壳：

- `PE32+ executable for MS Windows, x86-64`
- 节名有 `UPX0 / UPX1 / UPX2`
- `UPX1` 的原始数据从文件偏移 `0x400` 开始

题目目录里的 `re1.md` 已经给出了这一类样本的壳结构。对当前附件复核后，入口和节信息为：

- `Entry RVA = 0x48d60`
- `ImageBase = 0x140000000`
- `UPX1 RawPtr = 0x400`

入口 stub 附近可以看出它把压缩数据从 `0x14002f000` 解到 `0x140001000`，并且使用 raw LZMA 参数：

- `lc = 3`
- `lp = 0`
- `pb = 2`

用 Python 的 `lzma.LZMADecompressor` 直接按 raw 模式解出数据后，可以拿到当前样本的 `unpacked_raw.bin`。

接着从字符串区反推主逻辑位置。`unpacked_raw.bin` 里可以找到：

- `Input flag in the format ISCC{xxxxxxxxxxxxxxxxxxxx}:`
- `Success!`
- `Fail!`

在当前样本的校验循环中，可以看到这段关键逻辑：

```c
seed = *(uint32_t *)0x14003f010;
for (i = 0; i < len; i++) {
    seed = seed * 0x41c64e6d + 0x3039;
    r = (seed >> 24) % 95;
    enc[i] = ((input[i] - 0x20 + r) % 95) + 0x20;
}
memcmp(enc, target, 20);
```

这里最重要的一点是：当前样本的种子来自数据区 `0x14003f010`，值为 `0x1a`。这和 `re1.md` 示例样本的 `0x24` 不同，所以如果直接照抄旧 WP 的结果，会得到错误 flag。

同时可以提取到当前样本真实比较目标：

```python
seed = 0x1a
target = b')N/ZKL)[L/IwCo4(3fA$'
```

### Step 2: 逆推出 20 字节中间串

因为程序的正向变换是：

```python
enc[i] = ((plain[i] - 0x20 + r) % 95) + 0x20
```

所以逆向就是：

```python
plain[i] = ((enc[i] - 0x20 - r) % 95) + 0x20
```

下面这份脚本可以从当前附件 `caterpillar26.exe` 直接还原出最终 flag：

```python
import lzma
import struct
from pathlib import Path


def unpack_sample(path: str) -> bytes:
    data = Path(path).read_bytes()
    comp = data[0x400:0x1AC00]
    p0, p1 = comp[0], comp[1]
    pb = p0 & 7
    lc = p1 & 0xF
    lp = p1 >> 4

    dec = lzma.LZMADecompressor(
        format=lzma.FORMAT_RAW,
        filters=[
            {
                "id": lzma.FILTER_LZMA1,
                "dict_size": 0x100000,
                "lc": lc,
                "lp": lp,
                "pb": pb,
            }
        ],
    )
    return dec.decompress(comp[2:], max_length=0x46CC3)


def recover_flag(unpacked: bytes) -> str:
    seed = struct.unpack_from("<I", unpacked, 0x3E010)[0]
    target = unpacked[0x3E018:0x3E018 + 20]

    plain = []
    cur = seed
    for c in target:
        cur = (cur * 0x41C64E6D + 0x3039) & 0xFFFFFFFF
        r = (cur >> 24) % 95
        p = ((c - 0x20 - r) % 95) + 0x20
        plain.append(p)

    return "ISCC{" + bytes(plain).decode("latin1") + "}"


unpacked = unpack_sample("caterpillar26.exe")
print(recover_flag(unpacked))
```

脚本输出：

```text
ISCC{9t:Wle'0]%}wo`5qV?T{}
```

把这串结果喂给程序，程序返回 `Success!`，说明恢复正确。

## Flag

```text
ISCC{9t:Wle'0]%}wo`5qV?T{}
```
