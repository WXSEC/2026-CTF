# re2

下面是一份完整 WP，可以直接整理成比赛题解使用。

# Reverse WP：拆弹专家

## 1. 程序整体逻辑

程序是一个三阶段拆弹题，核心流程在 main() 中：

if (!sg6j(password1)) boom;
d4n7(g_stage1_hash);

if (!d5n7(password2)) boom;
seed = atoi(password2);
seed ^= (g_stage1_hash * 0x9E3779B1u);
b5k8(seed);

if (!s6m8(password3)) boom;
h5b5(password1, password2, password3);

三关分别是：

| 关卡 | 函数 | 验证内容 |
|---|---|---|
| 第一关 | sg6j() | 8 字符字符串经过魔方加密后做 FNV1a 哈希 |
| 第二关 | d5n7() | 根据第一关 hash 动态生成线性方程组 |
| 第三关 | s6m8() | 根据第二关生成的 seed 构造 4x4 迷宫，验证路径 |
| 成功输出 | h5b5() | 拼接三个密码输出 flag |

题目中有计时器和反调试检测，但它们不是解题重点，可以静态分析绕过。

## 2. 第一关分析

第一关验证函数为：

bool sg6j(const char* input)

首先要求输入长度为 8：

size_t n = strlen(input);
if (n != 8) return false;

并且每个字符必须是可打印字符：

if (c < 0x21 || c > 0x7E) return false;

接着程序恢复出加密 key：

static const uint8_t enc_key[] = {
'R' ^ 0x5A, ' ' ^ 0x5A, 'U' ^ 0x5A, ' ' ^ 0x5A,
'F' ^ 0x5A, ' ' ^ 0x5A, 'R' ^ 0x5A, '\'' ^ 0x5A,
' ' ^ 0x5A, 'D' ^ 0x5A, '2' ^ 0x5A
};

异或 0x5A 后得到：

R U F R' D2

程序会用这个 key 调用魔方加密函数：

std::string cipher = g3::k1c7(std::string(input), key);
uint32_t h = fnv1a32(cipher.c_str());

最后校验：

static const uint32_t MASK = 0xA5A5A5A5u;
static const uint32_t EXPECT_OBF = 0xC9F8DE04u;

return ((h ^ MASK) == EXPECT_OBF);

所以目标 hash 为：

h = 0xC9F8DE04 ^ 0xA5A5A5A5
h = 0x6C5D7BA1

这里源码注释中直接泄露了第一关明文：

// generated for stage1=JWHNYDDE

因此第一关密码为：

JWHNYDDE

验证后：

g_stage1_hash = 0x6C5D7BA1

## 3. 第二关分析

第一关通过后，会调用：

d4n7(g_stage1_hash);

该函数根据第一关 hash 动态生成第二关的系数和目标值。

### 3.1 系数生成

const int base_a[5] = { 2, 3, 4, 5, 6 };

for (int i = 0; i < 5; ++i) {
int delta = (int)((h >> (i * 6)) & 0x3);
g_a[i] = base_a[i] + delta;
}

代入：

h = 0x6C5D7BA1

得到：

g_a = [3, 5, 7, 8, 6]

### 3.2 方程真实解生成

程序并不是直接写死第二关答案，而是用 LCG 从 hash 派生出一组解：

uint32_t seed = h ^ 0x12345678u;
uint32_t state = seed;

for (int i = 0; i < 5; ++i) {
d4bb6(&state);
if (i != 0)
x[i] = 10 + (int)(state % 90);
else
x[i] = (int)(state % 10);
}

LCG 函数为：

*st = (*st * 1664525u + 1013904223u);

代入第一关 hash 后，生成：

x1 = 8
x2 = 15
x3 = 56
x4 = 25
x5 = 68

然后根据这组解反推目标值：

g_e[0] = g_a[0] * x[0] + x[1] + x[4];
g_e[1] = x[0] + g_a[1] * x[1] + x[2];
g_e[2] = x[1] + g_a[2] * x[2] + x[3];
g_e[3] = x[2] + g_a[3] * x[3] + x[4];
g_e[4] = x[0] + x[3] + g_a[4] * x[4];

对应方程为：

3*x1 + x2 + x5 = e1
x1 + 5*x2 + x3 = e2
x2 + 7*x3 + x4 = e3
x3 + 8*x4 + x5 = e4
x1 + x4 + 6*x5 = e5

由于程序本身就是用这组 x 生成目标值，所以第二关答案直接拼接为：

x1 x2 x3 x4 x5

注意输入格式要求长度为 9：

if (strlen(input) != 9) return false;

其中：

x1 = 第 1 位
x2 = 第 2-3 位
x3 = 第 4-5 位
x4 = 第 6-7 位
x5 = 第 8-9 位

所以第二关密码为：

815562568

## 4. 第三关分析

第二关通过后，程序用第二关密码和第一关 hash 生成迷宫 seed：

uint32_t seed = (uint32_t)atoi(password2);
seed ^= (g_stage1_hash * 0x9E3779B1u);
b5k8(seed);

代入：

password2 = 815562568
g_stage1_hash = 0x6C5D7BA1

得到：

seed = 0x3934EC19

然后调用 b5k8(seed) 生成 4x4 迷宫。

迷宫从 (0,0) 出发，目标是 (3,3)：

int x = 0, y = 0;
g_maze[idx(x, y)] = 1;

while (!(x == 3 && y == 3)) {
uint32_t r = d4bb6(&st);
bool canR = (x < 3);
bool canD = (y < 3);

if (canR && canD) {
move = (r & 1) ? 1 : 2;
}
else if (canR) {
move = 1;
}
else {
move = 2;
}

if (move == 1) x++;
else y++;

g_maze[idx(x, y)] = 1;
}

这里迷宫主路径只会向右 R 或向下 D 走，之后虽然有额外分支逻辑，但条件为：

if ((r % 100) < -0.1) g_maze[p] = 1;

由于 r % 100 是无符号/非负结果，不可能小于 -0.1，所以不会额外打开分支。

因此只需要还原主路径即可。

根据 seed 模拟迷宫生成，得到路径：

RDRDRD

第三关验证函数 s6m8() 要求输入只能由 L/R/U/D 组成，并且最终到达 (3,3)：

return (x == 3 && y == 3);

所以第三关密码为：

RDRDRD

## 5. 成功输出分析

成功后调用：

h5b5(password1, password2, password3);

其中前缀被异或隐藏：

static const unsigned char enc[11] = {
0x1C,0x36,0x3B,0x3D,0x60,0x7A,0x13,0x09,0x19,0x19,0x21
};

for (int i = 0; i < 11; ++i)
putchar(enc[i] ^ 0x5A);

异或 0x5A 后为：

Flag: ISCC{

然后程序依次拼接三个密码：

fputs(pw1, stdout);
fputs(pw2, stdout);
fputs(pw3, stdout);
putchar('}');

因此最终 flag 为：

ISCC{JWHNYDDE815562568RDRDRD}

## 6. 解题脚本思路

可以用下面逻辑快速复现：

h = 0xC9F8DE04 ^ 0xA5A5A5A5

base_a = [2, 3, 4, 5, 6]
g_a = []

for i in range(5):
delta = (h >> (i * 6)) & 0x3
g_a.append(base_a[i] + delta)

def lcg(st):
return (st * 1664525 + 1013904223) & 0xffffffff

state = h ^ 0x12345678
xs = []

for i in range(5):
state = lcg(state)
if i == 0:
xs.append(state % 10)
else:
xs.append(10 + state % 90)

pw2 = f"{xs[0]}{xs[1]:02d}{xs[2]:02d}{xs[3]:02d}{xs[4]:02d}"
print(hex(h), g_a, xs, pw2)

seed = int(pw2) ^ ((h * 0x9E3779B1) & 0xffffffff)
seed &= 0xffffffff

st = seed ^ 0x9E3779B9
x = y = 0
path = ""

while not (x == 3 and y == 3):
st = lcg(st)

canR = x < 3
canD = y < 3

if canR and canD:
move = 1 if (st & 1) else 2
elif canR:
move = 1
else:
move = 2

if move == 1:
x += 1
path += "R"
else:
y += 1
path += "D"

print(hex(seed), path)

输出核心结果：

0x6c5d7ba1
g_a = [3, 5, 7, 8, 6]
xs = [8, 15, 56, 25, 68]
pw2 = 815562568
seed = 0x3934ec19
path = RDRDRD

## 7. 最终答案

三关输入：

JWHNYDDE
815562568
RDRDRD

最终 flag：

ISCC{JWHNYDDE815562568RDRDRD}