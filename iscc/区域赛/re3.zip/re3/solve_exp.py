#!/usr/bin/env python3
# ISCC re2 解题脚本
# 根据代码分析，逆向计算出各关卡密码

def main():
    print("=" * 60)
    print("          ISCC re2 拆弹专家 - 解题脚本")
    print("=" * 60)
    
    # ==================== 第一关 ====================
    print("\n[+] 第一关分析：")
    MASK = 0xA5A5A5A5
    EXPECT_OBF = 0xCB040F00
    h = EXPECT_OBF ^ MASK
    print(f"    目标hash: 0x{h:08X}")
    
    # 从代码注释泄露获取密码
    password1 = "CGKKIURA"
    print(f"    密码1 (从代码注释泄露): {password1}")
    
    # ==================== 第二关 ====================
    print("\n[+] 第二关分析：")
    base_a = [2, 3, 4, 5, 6]
    g_a = []
    for i in range(5):
        delta = (h >> (i * 6)) & 0x3
        g_a.append(base_a[i] + delta)
    print(f"    方程组系数: {g_a}")
    
    def lcg(st):
        return (st * 1664525 + 1013904223) & 0xffffffff
    
    state = h ^ 0x12345678
    xs = []
    for i in range(5):
        state = lcg(state)
        if i == 0:
            xs.append(state % 10)
        else:
            xs.append(10 + state % 90)
    print(f"    方程组解: {xs}")
    
    password2 = f"{xs[0]}{xs[1]:02d}{xs[2]:02d}{xs[3]:02d}{xs[4]:02d}"
    print(f"    密码2 (9位数字): {password2}")
    
    # ==================== 第三关 ====================
    print("\n[+] 第三关分析：")
    seed = int(password2) ^ ((h * 0x9E3779B1) & 0xffffffff)
    seed &= 0xffffffff
    print(f"    迷宫seed: 0x{seed:08X}")
    
    st = seed ^ 0x9E3779B9
    x, y = 0, 0
    path = ""
    while not (x == 3 and y == 3):
        st = lcg(st)
        canR = x < 3
        canD = y < 3
        if canR and canD:
            move = 1 if (st & 1) else 2
        elif canR:
            move = 1
        else:
            move = 2
        if move == 1:
            x += 1
            path += "R"
        else:
            y += 1
            path += "D"
    password3 = path
    print(f"    密码3 (路径): {password3}")
    
    # ==================== 最终flag ====================
    print("\n" + "=" * 60)
    print("[+] 三关密码汇总：")
    print(f"    password1: {password1}")
    print(f"    password2: {password2}")
    print(f"    password3: {password3}")
    print("\n[+] 最终flag：")
    flag = f"ISCC{{{password1}{password2}{password3}}}"
    print(f"    {flag}")
    print("=" * 60)
    
    return flag

if __name__ == "__main__":
    main()