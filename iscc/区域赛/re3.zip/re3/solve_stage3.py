def lcg(st):
    """标准LCG伪随机数生成器"""
    return (st * 1664525 + 1013904223) & 0xffffffff

def solve_stage3(stage1_hash, password2):

    # 计算迷宫seed
    seed = int(password2) ^ ((stage1_hash * 0x9E3779B1) & 0xffffffff)
    seed &= 0xffffffff
    print(f"[+] 迷宫seed: 0x{seed:08X}")
    
    # 迷宫生成算法
    st = seed ^ 0x9E3779B9
    x, y = 0, 0
    path = ""
    
    print("[+] 迷宫路径生成过程：")
    print(f"    起点: ({x}, {y})")
    
    while not (x == 3 and y == 3):
        st = lcg(st)
        canR = x < 3
        canD = y < 3
        
        if canR and canD:
            move = 1 if (st & 1) else 2
        elif canR:
            move = 1
        else:
            move = 2
        
        if move == 1:
            x += 1
            path += "R"
        else:
            y += 1
            path += "D"
        
        print(f"    移动: {'R' if move == 1 else 'D'} -> ({x}, {y})")
    
    print(f"    终点: ({x}, {y})")
    return path

def main():
    print("=" * 60)
    print("=" * 60)
    
 
    STAGE1_HASH = 0x6EA1AAA5  # 第一关hash: EXPECT_OBF ^ MASK = 0xCB040F00 ^ 0xA5A5A5A5
    PASSWORD2 = "435182586"    # 第二关密码
    
    print(f"\n[+] 输入参数：")
    print(f"    stage1_hash: 0x{STAGE1_HASH:08X}")
    print(f"    password2: {PASSWORD2}")
    
    # 计算第三关路径
    password3 = solve_stage3(STAGE1_HASH, PASSWORD2)
    
    print(f"\n[+] 第三关密码（路径）：{password3}")
    print("=" * 60)
    
    return password3

if __name__ == "__main__":
    main()