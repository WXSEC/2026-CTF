h = 0x6ea1aaa5
base_a = [2,3,4,5,6]
g_a = []
for i in range(5):
    delta = (h >> (i*6)) & 3
    g_a.append(base_a[i] + delta)
state = h ^ 0x12345678
x = []
for i in range(5):
    state = (state * 1664525 + 1013904223) & 0xFFFFFFFF
    if i == 0: x.append(state % 10)
    else: x.append(10 + state % 90)
pw2 = f"{x[0]}{x[1]:02d}{x[2]:02d}{x[3]:02d}{x[4]:02d}"
print(pw2)
