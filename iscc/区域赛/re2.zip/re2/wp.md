# 如影随形 WP

## 题目信息

- 类型：REVERSE
- 平台：Windows x64
- 附件：[attachment-22.exe](D:/iscc/区域赛/re2/attachment-22.exe)
- 最终 Flag：`ISCC{:{+]tikGqMYiGA^B}`

## 一、初步分析

题目是一个 64 位无壳 PE，直接放进 IDA64 分析。

先按 `Shift+F12` 查看字符串，可以很快看到几个关键提示：

- `Input flag in the format ISCC{xxxxxxxxxxxxxxxx}: `
- `Invalid input format. Expected ISCC{xxxxxxxxxxxxxxxx}.`
- `Correct!`
- `Wrong.`

对 `Correct!` 或 `Wrong.` 交叉引用，回到 `main` 后可以明确输入格式要求：

- 前缀必须为 `ISCC{`
- 末尾必须为 `}`
- 总长度必须为 `22`
- 花括号内有效内容长度必须为 `16`

也就是 Flag 格式固定为：

```text
ISCC{xxxxxxxxxxxxxxxx}
```

## 二、main 函数逻辑

`main` 的关键流程如下：

1. 读取输入并去掉换行符。
2. 校验长度和前后缀。
3. 将花括号内 16 字节拷贝到局部缓冲区。
4. 通过一段看起来较怪的索引，把输入重排成 4x4 矩阵。
5. 调用核心函数对矩阵进行变换。
6. 与 `.data` 段中的 16 字节目标密文逐字节比较，相同则输出 `Correct!`。

在 IDA 里能看到类似这样的赋值：

```c
Source[4 * (v8 >> 2) - 53 + (v10 & 3)] = v9;
```

这看上去很绕，其实只是 IDA 由于栈变量偏移识别造成的假象。注意：

- `v16` 的地址是 `[rsp+20h]`
- `Source` 的地址是 `[rsp+55h]`
- `0x55 - 0x35 = 0x20`

所以本质上这段逻辑只是把输入的 16 字节按行优先方式写入一个 `4 x 4` 矩阵中。

## 三、目标密文与映射矩阵

程序在 `main` 中完成变换后，会把结果与 `.data` 段 `0x140004000` 处的 16 字节常量比较。提取后可得：

```python
TARGET = 'J_[B*RojO>[O1o$5'
```

同时，外层调度函数 `OHF3nw(v16)` 会使用一个 16 字节映射表来决定矩阵元素的处理顺序。该表位于 `.data` 段，提取结果为：

```python
MATRIX_MAP = [
    [0, 12, 13, 2],
    [8, 3, 15, 5],
    [4, 14, 9, 10],
    [7, 1, 11, 6],
]
```

这里的含义是：按矩阵坐标 `(row, col)` 遍历时，会根据 `MATRIX_MAP[row][col]` 映射到另一个目标位置，再计算：

- 行偏移 `row_diff = abs(target_row - row)`
- 列偏移 `col_diff = abs(target_col - col)`

然后把这两个偏移传入核心变换函数。

## 四、核心函数分析

核心逻辑在 `u8afi3`，实际调用地址约为 `0x1400018A0`。这个函数可以拆成两个阶段。

### 1. 第一阶段：链式字符变换

函数前半段会先把整个 `4 x 4` 矩阵拍平成 16 字节串，然后逐字节进行链式运算。

核心特征：

- 运算范围限制在 ASCII `32~126`
- 即总共 `95` 个可打印字符
- 当前字符处理时会受到上一个字符结果的影响

这种形式可以抽象为：

```python
value = ((ch - 32 + cur) % 95) + 32
cur = value - 32
```

逆过程就是：

```python
value = ((ch - 32 - cur) % 95) + 32
cur = ch - 32
```

也就是 Exp 中的 `phase_a_inverse`。

### 2. 第二阶段：基于置换表的非线性替换

函数后半段会针对当前矩阵元素再做一轮非线性映射。这里有两个关键点：

- 程序内嵌了一段干扰字符串：`iscc_{this_is_not_flag}`
- 会根据行偏移 `row_diff` 决定迭代次数

在每一轮迭代中，字符都会先加上一个由干扰字符串导出的偏移，再经过置换表映射。

因此逆向时只要：

1. 先构造置换表的逆映射 `INV`
2. 再按 `row_diff` 次数逆推

即可还原对应字符。这部分对应 Exp 中的 `phase_b_inverse`。

## 五、置换表恢复

程序不会直接明文存放置换表，而是在运行时从 `.rdata` 段读取一块数据后进行异或恢复。

在样本中可定位到：

- `cfg::kMapXor` 地址：`0x1400050E0`

提取 95 字节后可见，程序使用的异或常量实际上是：

```python
0x68
```

而不是 `0x91`。恢复方式如下：

```python
PERM = [b ^ 0x68 for b in kMapXor]
```

恢复出的完整置换表为：

```python
PERM = [80, 51, 64, 12, 55, 25, 83, 14, 38, 92, 86, 2, 85, 43, 70, 31,
        65, 56, 8, 50, 24, 72, 26, 22, 29, 94, 74, 46, 82, 37, 60, 44,
        40, 28, 19, 68, 93, 17, 36, 21, 20, 30, 53, 87, 54, 35, 1, 10,
        41, 63, 89, 52, 0, 4, 27, 42, 66, 7, 71, 49, 59, 76, 32, 15,
        3, 78, 6, 23, 67, 77, 16, 13, 58, 79, 48, 5, 18, 69, 9, 47,
        34, 62, 33, 88, 90, 57, 45, 81, 39, 75, 73, 84, 61, 11, 91]
```

可以验证该表正好是 `0~94` 的一个置换。

## 六、逆向思路

整体加密流程是：

1. 输入 16 字节排成 `4 x 4` 矩阵。
2. 按 `MATRIX_MAP` 指定顺序逐步处理矩阵元素。
3. 每一步先做第二阶段非线性变换，再做第一阶段链式变换。
4. 最终得到目标密文 `J_[B*RojO>[O1o$5`。

因此逆向时只需要完全反着来：

1. 从目标密文构造初始矩阵。
2. 按处理顺序逆序遍历，即从右下到左上。
3. 每次先逆第二阶段，再逆第一阶段。
4. 最后把矩阵按行展开，即得到原始 16 字节明文。

## 七、Exp

```python
TARGET = 'J_[B*RojO>[O1o$5'
FAKE = 'iscc_{this_is_not_flag}'
MATRIX_MAP = [
    [0, 12, 13, 2],
    [8, 3, 15, 5],
    [4, 14, 9, 10],
    [7, 1, 11, 6],
]
PERM = [80, 51, 64, 12, 55, 25, 83, 14, 38, 92, 86, 2, 85, 43, 70, 31,
        65, 56, 8, 50, 24, 72, 26, 22, 29, 94, 74, 46, 82, 37, 60, 44,
        40, 28, 19, 68, 93, 17, 36, 21, 20, 30, 53, 87, 54, 35, 1, 10,
        41, 63, 89, 52, 0, 4, 27, 42, 66, 7, 71, 49, 59, 76, 32, 15,
        3, 78, 6, 23, 67, 77, 16, 13, 58, 79, 48, 5, 18, 69, 9, 47,
        34, 62, 33, 88, 90, 57, 45, 81, 39, 75, 73, 84, 61, 11, 91]

INV = [0] * 95
for i, v in enumerate(PERM):
    INV[v] = i

def phase_a_inverse(chars, shift):
    out = []
    cur = shift % 95
    for ch in chars:
        value = ((ch - 32 - cur) % 95) + 32
        out.append(value)
        cur = ch - 32
    return out

def phase_b_inverse(ch, row_diff):
    if row_diff <= 0:
        return ch
    delta = ord(FAKE[row_diff % len(FAKE)]) % 95
    value = ch
    for _ in range(row_diff):
        tmp = (value - 32 - delta) % 95
        value = INV[tmp] + 32
    return value

def helper_inverse(mat, row, col, col_diff, row_diff):
    mat = [line[:] for line in mat]
    mat[row][col] = phase_b_inverse(mat[row][col], row_diff)
    flat = [mat[r][c] for r in range(4) for c in range(4)]
    flat = phase_a_inverse(flat, col_diff)
    return [flat[i * 4:(i + 1) * 4] for i in range(4)]

def solve():
    mat = [list(map(ord, TARGET[i * 4:(i + 1) * 4])) for i in range(4)]
    for row in range(3, -1, -1):
        for col in range(3, -1, -1):
            mapped = MATRIX_MAP[row][col]
            target_row, target_col = divmod(mapped, 4)
            mat = helper_inverse(mat, row, col,
                                 abs(target_col - col),
                                 abs(target_row - row))
    inner = ''.join(chr(mat[r][c]) for r in range(4) for c in range(4))
    print('ISCC{' + inner + '}')

if __name__ == '__main__':
    solve()
```

运行结果：

```text
ISCC{:{+]tikGqMYiGA^B}
```

## 八、验证

将结果输入程序：

```text
ISCC{:{+]tikGqMYiGA^B}
```

程序输出：

```text
Correct!
```

说明逆向结果正确。

## 九、总结

这题的关键点有三个：

1. 看懂 `main` 中那段迷惑性的栈偏移，确认输入被组织成 `4 x 4` 矩阵。
2. 在核心函数中把整体变换拆成“链式模 95 变换”和“置换表替换”两部分。
3. 从样本真实数据中恢复出目标密文、映射矩阵和置换表，再按完全逆序还原。

其中最容易出错的是常量提取：

- 目标密文应为 `J_[B*RojO>[O1o$5`
- 映射矩阵应为 `[[0,12,13,2],[8,3,15,5],[4,14,9,10],[7,1,11,6]]`
- `cfg::kMapXor` 的异或常量应为 `0x68`

最终 Flag：`ISCC{:{+]tikGqMYiGA^B}`
