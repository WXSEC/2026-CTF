from scapy.all import *
packets = rdpcap("misc1.pcapng")
print(f"Total packets: {len(packets)}")
