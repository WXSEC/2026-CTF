from scapy.all import *

packets = rdpcap("misc1.pcapng")
udp = [p for p in packets if UDP in p]
for i, p in enumerate(udp):
    if Raw in p and b'=' in p[Raw].load:
        print(f"Packet {i}: {p[Raw].load}")