from PIL import Image
img = Image.open("image.png")
pixels = list(img.getdata())

bits = []
for r, g, b in pixels:
    bits.append(str(r & 1))
    bits.append(str(g & 1))
    bits.append(str(b & 1))

data = bytes(int(''.join(bits[i:i+8]), 2) for i in range(0, len(bits)-7, 8))
print("Hex dump:", data[:100].hex())
print("\nRaw bytes:", data[:50])
