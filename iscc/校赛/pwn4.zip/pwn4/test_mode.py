from pwn import *
import time

context.log_level = 'info'
context.arch = 'amd64'

HOST = '39.96.193.120'
PORT = 10016

r = remote(HOST, PORT, timeout=30)
data = r.recv(8192)
r.sendline(b'0')  # teacher
time.sleep(0.5)
r.recv(8192)

# Add student 0
r.sendline(b'1')
time.sleep(0.3)
r.recv(8192)
r.sendline(b'9')
time.sleep(0.3)
r.recv(8192)

# Give score
r.sendline(b'2')
time.sleep(1.5)
r.recv(8192)

# Switch to student role
r.sendline(b'5')
time.sleep(0.3)
r.recv(8192)
r.sendline(b'1')
time.sleep(0.3)
r.recv(8192)

# Directly use option 4 WITHOUT calling option 3 first
# mode should be 0 (initial)
r.sendline(b'4')
time.sleep(0.5)
data = r.recv(8192).decode(errors='ignore')
log.info(f"Option 4 (mode=0 expected): {repr(data[:200])}")

# If mode=0, should output 'enter your comment:'
# If mode=1, should output 'enter your pray score: 0 to 100'

r.close()
