from pwn import *
import time

context.log_level = 'info'
context.arch = 'amd64'

HOST = '39.96.193.120'
PORT = 10016

r = remote(HOST, PORT, timeout=30)
data = r.recv(8192)
r.sendline(b'0')  # teacher
time.sleep(0.5)
r.recv(8192)

# Add student 0
r.sendline(b'1')
time.sleep(0.3)
r.recv(8192)
r.sendline(b'9')
time.sleep(0.3)
r.recv(8192)

# Give score
r.sendline(b'2')
time.sleep(1.5)
data = r.recv(8192).decode(errors='ignore')
log.info(f"Score: {data[:200]}")

# Switch to student role
r.sendline(b'5')
time.sleep(0.3)
r.recv(8192)
r.sendline(b'1')
time.sleep(0.3)
data = r.recv(8192).decode(errors='ignore')
log.info(f"Student menu: {data}")

# Test each menu option
for i in range(1, 7):
    r.sendline(str(i).encode())
    time.sleep(0.5)
    data = r.recv(8192).decode(errors='ignore')
    log.info(f"Option {i} output: {repr(data[:200])}")
    # Try to continue
    if 'score:' in data.lower():
        r.sendline(b'50')
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"Option {i} follow-up: {repr(data[:200])}")
    elif 'comment:' in data.lower():
        r.sendline(b'AAAA')
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"Option {i} follow-up: {repr(data[:200])}")
    elif 'mode!' in data.lower():
        pass  # set mode doesn't need input
    elif 'id:' in data.lower():
        r.sendline(b'0')
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"Option {i} follow-up: {repr(data[:200])}")
    elif 'role:' in data.lower():
        r.sendline(b'1')
        time.sleep(0.3)
        data = r.recv(8192).decode(errors='ignore')
        log.info(f"Option {i} follow-up: {repr(data[:200])}")

r.close()
