
from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

vuln_addr = elf.symbols['vuln']
vuln_bytes = elf.read(vuln_addr, 0x120)

print(f"vuln function at 0x{vuln_addr:x}")
print(f"Disassembly:")

try:
    print(disasm(vuln_bytes, arch='i386', vma=vuln_addr))
except:
    print("disasm failed, printing raw bytes")
    for i in range(0, len(vuln_bytes), 16):
        chunk = vuln_bytes[i:i+16]
        hex_str = ' '.join(f'{b:02x}' for b in chunk)
        print(f'  0x{vuln_addr + i:08x}: {hex_str}')
