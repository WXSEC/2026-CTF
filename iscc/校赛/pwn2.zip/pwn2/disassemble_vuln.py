
from pwn import *

elf = ELF('pwn_permission')

vuln_addr = elf.symbols['vuln']
print(f"vuln函数地址: 0x{vuln_addr:x}")

# 读取vuln函数的字节
vuln_bytes = elf.read(vuln_addr, 0x100)

# 反汇编
print("\nvuln函数反汇编:")
print(disasm(vuln_bytes, arch='i386'))
