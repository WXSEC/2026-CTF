from pwn import *

context(arch='i386', os='linux', log_level='info')

# Leaked addresses from the format string:
# puts: 0xf7d961e0 (last 12 bits: 0x1e0)
# printf: 0xf7d43de0 (last 12 bits: 0xde0)
# Other addresses found:
# 0xf7d969c0 (last 12 bits: 0x9c0)
# 0xf7e743b0 (last 12 bits: 0x3b0)
# 0xf7d78d30 (last 12 bits: 0xd30)

# Let me query libc.rip with puts and printf last 12 bits
import requests

api_url = "https://libc.rip/api/find"

# Try with puts and printf
data = {
    "symbols": {
        "puts": "0x61e0",
        "printf": "0x3de0",
    }
}

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        log.info(f"Found {len(libs)} matching libc versions with puts=0x61e0, printf=0x3de0:")
        for lib in libs:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            log.info(f"\n{lib_id}:")
            for sym in ['puts', 'printf', 'system', 'str_bin_sh', '__libc_start_main', 'write', 'execve']:
                if sym in symbols:
                    log.info(f"  {sym}: 0x{symbols[sym]}")
    else:
        log.error(f"API error: {resp.status_code} - {resp.text}")
except Exception as e:
    log.error(f"API query failed: {e}")

# Also try with just puts
data2 = {
    "symbols": {
        "puts": "0x61e0",
    }
}

try:
    resp2 = requests.post(api_url, json=data2, timeout=10)
    if resp2.status_code == 200:
        libs2 = resp2.json()
        log.info(f"\n\nFound {len(libs2)} matching libc versions with puts=0x61e0:")
        seen = set()
        for lib in libs2:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            puts_off = symbols.get('puts', '0')
            printf_off = symbols.get('printf', '0')
            system_off = symbols.get('system', '0')
            binsh_off = symbols.get('str_bin_sh', '0')
            
            key = (puts_off, system_off, binsh_off)
            if key in seen:
                continue
            seen.add(key)
            
            # Check if printf offset matches
            if isinstance(printf_off, str) and isinstance(puts_off, str):
                try:
                    po = int(puts_off, 16)
                    pro = int(printf_off, 16)
                    # We know printf - puts = -0x52400
                    # So printf_offset - puts_offset should also be -0x52400
                    # Or: puts_offset - printf_offset = 0x52400
                    diff = po - pro
                    if diff == 0x52400:
                        log.success(f"\n{lib_id}:")
                        log.info(f"  puts: 0x{puts_off}")
                        log.info(f"  printf: 0x{printf_off}")
                        log.info(f"  system: 0x{system_off}")
                        log.info(f"  str_bin_sh: 0x{binsh_off}")
                        log.info(f"  puts - printf = 0x{diff:x} ✓")
                except:
                    pass
    else:
        log.error(f"API error 2: {resp2.status_code}")
except Exception as e:
    log.error(f"API query 2 failed: {e}")