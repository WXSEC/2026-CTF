from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

import requests

# Query libc.rip for the correct offsets
api_url = "https://libc.rip/api/find"
data = {
    "symbols": {
        "puts": "0x6d1e0"
    }
}

resp = requests.post(api_url, json=data, timeout=10)
if resp.status_code == 200:
    libs = resp.json()
    for lib in libs:
        lib_id = lib.get('id', 'unknown')
        symbols = lib.get('symbols', {})
        puts_off = symbols.get('puts', '?')
        system_off = symbols.get('system', '?')
        binsh_off = symbols.get('str_bin_sh', '?')
        log.info(f"{lib_id}:")
        log.info(f"  puts=0x{puts_off}, system=0x{system_off}, /bin/sh=0x{binsh_off}")
        
        # Also dump the offsets
        dump_url = "https://libc.rip/api/dump"
        dump_data = {"id": lib_id, "symbols": ["system", "str_bin_sh"]}
        try:
            dump_resp = requests.post(dump_url, json=dump_data, timeout=10)
            if dump_resp.status_code == 200:
                dump_result = dump_resp.json()
                log.info(f"  Dump: {dump_result}")
        except:
            pass