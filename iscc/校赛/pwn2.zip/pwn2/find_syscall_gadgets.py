
from pwn import *

elf = ELF('pwn_permission')

# 程序基址
base = 0x8048000

# 我们需要的gadget：
# 1. pop eax; ret → 0x58, 0xc3
# 2. pop ebx; pop ecx; pop edx; ret → 0x5b, 0x59, 0x5a, 0xc3
# 3. int 0x80 → 0xcd, 0x80

print("=== 搜索gadget ===")

# 获取.text段
text = elf.get_section_by_name('.text')
text_data = text.data()
text_addr = text.header.sh_addr

print(f".text段地址: 0x{text_addr:x}")
print(f".text段大小: {len(text_data)} bytes")

# 1. 搜索 pop eax; ret → b'\x58\xc3'
print("\n1. 搜索 pop eax; ret:")
for i in range(len(text_data) - 1):
    if text_data[i:i+2] == b'\x58\xc3':
        addr = text_addr + i
        print(f"  找到: 0x{addr:x}")
        
# 2. 搜索 pop ebx; pop ecx; pop edx; ret → b'\x5b\x59\x5a\xc3'
print("\n2. 搜索 pop ebx; pop ecx; pop edx; ret:")
for i in range(len(text_data) - 3):
    if text_data[i:i+4] == b'\x5b\x59\x5a\xc3':
        addr = text_addr + i
        print(f"  找到: 0x{addr:x}")

# 3. 搜索 int 0x80 → b'\xcd\x80'
print("\n3. 搜索 int 0x80:")
for i in range(len(text_data) - 1):
    if text_data[i:i+2] == b'\xcd\x80':
        addr = text_addr + i
        print(f"  找到: 0x{addr:x}")

# 4. 也搜索其他可能的组合，比如 pop ebx; ret; pop ecx; ret; 等
print("\n4. 搜索 pop ebx; pop ecx; ret:")
for i in range(len(text_data) - 3):
    if text_data[i:i+3] == b'\x5b\x59\xc3':
        addr = text_addr + i
        print(f"  找到: 0x{addr:x}")

print("\n=== 搜索完成 ===")
