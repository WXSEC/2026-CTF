from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

vuln_addr = elf.symbols['vuln']
main_addr = elf.symbols['main']

vuln_bytes = elf.read(vuln_addr, 0x200)

print(f"vuln at 0x{vuln_addr:x}")
print(f"main at 0x{main_addr:x}")
print()

from pwnlib.asm import disasm

try:
    print("Disassembly of vuln:")
    print(disasm(vuln_bytes, arch='i386', vma=vuln_addr))
except Exception as e:
    print(f"disasm failed: {e}")
    print("\nRaw bytes:")
    for i in range(0, min(len(vuln_bytes), 0x120), 16):
        chunk = vuln_bytes[i:i+16]
        hex_str = ' '.join(f'{b:02x}' for b in chunk)
        ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        print(f'  0x{vuln_addr + i:08x}: {hex_str:48s} {ascii_str}')

print("\n\nPLT entries:")
for name, addr in sorted(elf.plt.items(), key=lambda x: x[1]):
    print(f"  {name}: 0x{addr:x}")

print("\nGOT entries:")
for name, addr in sorted(elf.got.items(), key=lambda x: x[1]):
    print(f"  {name}: 0x{addr:x}")

print(f"\nAll symbols containing 'vuln' or 'main' or 'target':")
for name, addr in elf.symbols.items():
    if 'vuln' in name or 'main' in name or 'target' in name:
        print(f"  {name}: 0x{addr:x}")
