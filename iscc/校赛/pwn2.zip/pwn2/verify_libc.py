
from pwn import *
import requests
import json

context.log_level = 'info'

# ====== 我们泄露的偏移 ======
puts_offset = 0x6d1e0
write_offset = 0xf0830
read_offset = 0xf0790
printf_offset = 0x4fd30
libc_start_main_offset = 0x1ade0

# ====== 查询libc.rip ======
api_url = "https://libc.rip/api/find"

data = {
    "symbols": {
        "puts": hex(puts_offset),
        "write": hex(write_offset),
        "read": hex(read_offset),
        "printf": hex(printf_offset),
        "__libc_start_main": hex(libc_start_main_offset)
    }
}

log.info("查询libc.rip...")
log.info(f"查询参数: {data}")

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        log.info(f"找到 {len(libs)} 个匹配的libc!")
        
        for lib in libs:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            log.info(f"\nlibc版本: {lib_id}")
            for sym_name, sym_val in sorted(symbols.items()):
                log.info(f"  {sym_name}: {sym_val}")
                
    else:
        log.error(f"API错误: {resp.status_code}")
except Exception as e:
    log.error(f"查询失败: {e}")

# ====== 尝试只查一部分 ======
log.info("\n\n尝试只查put和write...")
data2 = {
    "symbols": {
        "puts": hex(puts_offset),
        "write": hex(write_offset)
    }
}

try:
    resp2 = requests.post(api_url, json=data2, timeout=10)
    if resp2.status_code == 200:
        libs2 = resp2.json()
        log.info(f"找到 {len(libs2)} 个匹配的libc!")
        for lib in libs2:
            log.info(f"libc: {lib.get('id', 'unknown')}")
            symbols = lib.get('symbols', {})
            log.info(f"  system: {symbols.get('system')}")
            log.info(f"  str_bin_sh: {symbols.get('str_bin_sh')}")
except Exception as e:
    log.error(f"查询失败: {e}")
