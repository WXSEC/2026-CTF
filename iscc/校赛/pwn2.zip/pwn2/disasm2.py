from pwn import *

elf = ELF('pwn_permission')
from capstone import Cs, CS_ARCH_X86, CS_MODE_32
md = Cs(CS_ARCH_X86, CS_MODE_32)

# Continue disassembling main from 0x80492ff
log.info("=== main function (continued) ===")
main_addr = 0x80492ff
main_data = elf.read(main_addr, 0x30)
for insn in md.disasm(main_data, main_addr):
    log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")

# Also check what strings are at the addresses referenced
# ebx + offset strings
ebx_base = 0x8049287 + 0x2d79  # After add ebx, 0x2d79
log.info(f"\nebx base = 0x{ebx_base:x}")

# String at ebx - 0x1ff0 (used in first puts)
str1_addr = ebx_base - 0x1ff0
str1 = elf.string(str1_addr)
log.info(f"String at 0x{str1_addr:x}: {str1}")

# String at ebx - 0x1fa8 (used in second puts)
str2_addr = ebx_base - 0x1fa8
str2 = elf.string(str2_addr)
log.info(f"String at 0x{str2_addr:x}: {str2}")

# String at ebx - 0x1ff8 (used in vuln write)
str3_addr = ebx_base - 0x1ff8
str3 = elf.string(str3_addr)
log.info(f"String at 0x{str3_addr:x}: {str3}")

# String at ebx - 0x1f88 (used in main after jne)
str4_addr = ebx_base - 0x1f88
str4 = elf.string(str4_addr)
log.info(f"String at 0x{str4_addr:x}: {str4}")

# Check what ebx + 0x34 points to
target_addr = ebx_base + 0x34
log.info(f"\nebx + 0x34 = 0x{target_addr:x}")
target_data = elf.read(target_addr, 4)
log.info(f"Value at ebx + 0x34: 0x{u32(target_data):x}")

# This should be target_val pointer
log.info(f"target_val symbol: 0x{elf.symbols['target_val']:x}")
log.info(f"x symbol: 0x{elf.symbols['x']:x}")

# Read the actual value at target_val
tv = elf.read(elf.symbols['target_val'], 4)
log.info(f"target_val initial value: {u32(tv)}")