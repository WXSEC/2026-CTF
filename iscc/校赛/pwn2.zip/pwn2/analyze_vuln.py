
from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

print("PLT entries:")
for name, addr in sorted(elf.plt.items(), key=lambda x: x[1]):
    print(f"  {name}: 0x{addr:x}")

print("\nGOT entries:")
for name, addr in sorted(elf.got.items(), key=lambda x: x[1]):
    print(f"  {name}: 0x{addr:x}")

print(f"\nvuln: 0x{elf.symbols['vuln']:x}")
print(f"main: 0x{elf.symbols['main']:x}")

# 检查vuln函数调用了哪些PLT函数
vuln_addr = elf.symbols['vuln']
vuln_bytes = elf.read(vuln_addr, 0x100)

print(f"\nvuln function bytes ({len(vuln_bytes)} bytes):")
for i in range(0, len(vuln_bytes), 4):
    chunk = vuln_bytes[i:i+4]
    val = int.from_bytes(chunk, 'little')
    # 检查是否是PLT地址
    for name, plt_addr in elf.plt.items():
        if val == plt_addr:
            print(f"  Offset +0x{i:x}: 0x{val:08x}  <-- {name}@plt!")
            break
    else:
        for name, got_addr in elf.got.items():
            if val == got_addr:
                print(f"  Offset +0x{i:x}: 0x{val:08x}  <-- {name}@GOT!")
                break

# 搜索call指令
print("\nCall targets in vuln:")
for i in range(len(vuln_bytes) - 4):
    if vuln_bytes[i] == 0xe8:  # call instruction
        offset = int.from_bytes(vuln_bytes[i+1:i+5], 'little', signed=True)
        target = vuln_addr + i + 5 + offset
        # 检查是否是PLT函数
        for name, plt_addr in elf.plt.items():
            if target == plt_addr:
                print(f"  0x{vuln_addr+i:x}: call {name}@plt (0x{target:x})")
                break
        else:
            if 0x08049000 <= target <= 0x0804a000:
                print(f"  0x{vuln_addr+i:x}: call 0x{target:x}")
