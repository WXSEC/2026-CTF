
from pwn import *
import requests
import json

context.log_level = 'info'

# 使用我们刚才泄露的偏移来查询libc.rip
api_url = "https://libc.rip/api/find"

# 我们泄露的偏移
data = {
    "symbols": {
        "puts": "0x6d1e0",
        "write": "0xf0830",
        "read": "0xf0790",
        "printf": "0x4fd30",
        "__libc_start_main": "0x1ade0"
    }
}

log.info("=== Querying libc.rip with leaked offsets ===")

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        log.info(f"Found {len(libs)} matching libc versions")
        
        if len(libs) == 0:
            log.warning("No exact match found! Trying with fewer symbols...")
            
            # 尝试只用puts和write
            data2 = {
                "symbols": {
                    "puts": "0x6d1e0",
                    "write": "0xf0830"
                }
            }
            resp2 = requests.post(api_url, json=data2, timeout=10)
            if resp2.status_code == 200:
                libs2 = resp2.json()
                log.info(f"Found {len(libs2)} matching libc versions with just puts + write")
                
                for lib in libs2:
                    lib_id = lib.get('id', 'unknown')
                    symbols = lib.get('symbols', {})
                    log.info(f"\n{lib_id}:")
                    for sym_name, sym_val in sorted(symbols.items()):
                        if sym_name in ['puts', 'system', 'str_bin_sh', 'write', 'read', 'printf', '__libc_start_main']:
                            log.info(f"  {sym_name}: 0x{sym_val}")
        else:
            for lib in libs:
                lib_id = lib.get('id', 'unknown')
                symbols = lib.get('symbols', {})
                log.info(f"\n{lib_id}:")
                for sym_name, sym_val in sorted(symbols.items()):
                    if sym_name in ['puts', 'system', 'str_bin_sh', 'write', 'read', 'printf', '__libc_start_main']:
                        log.info(f"  {sym_name}: 0x{sym_val}")
    else:
        log.error(f"API error: {resp.status_code}")
except Exception as e:
    log.error(f"API query failed: {e}")
