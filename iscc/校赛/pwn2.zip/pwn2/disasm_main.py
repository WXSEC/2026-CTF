from pwn import *

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

print("=== Checking what's at 0x080491c6 (first call target in main) ===")
addr = 0x080491c6
bytes_at = elf.read(addr, 32)
hex_str = ' '.join(f'{b:02x}' for b in bytes_at)
print(f"  0x{addr:x}: {hex_str}")

print("\n=== Checking call targets in main ===")
main_addr = 0x08049270
main_bytes = elf.read(main_addr, 0xB0)

for i in range(len(main_bytes) - 4):
    if main_bytes[i] == 0xe8:
        offset = int.from_bytes(main_bytes[i+1:i+5], 'little', signed=True)
        target = main_addr + i + 5 + offset
        call_addr = main_addr + i
        
        target_name = "unknown"
        for name, sym_addr in elf.symbols.items():
            if sym_addr == target:
                target_name = name
                break
        for name, plt_addr in elf.plt.items():
            if plt_addr == target:
                target_name = f"{name}@plt"
                break
        
        print(f"  0x{call_addr:x}: call 0x{target:x} ({target_name})")

print("\n=== All symbols ===")
for name, addr in sorted(elf.symbols.items(), key=lambda x: x[1]):
    if 0x08049000 <= addr <= 0x0804a000:
        print(f"  {name}: 0x{addr:x}")

print("\n=== Re-examining main function byte by byte ===")
main_bytes = elf.read(main_addr, 0xB4)
i = 0
while i < len(main_bytes):
    addr = main_addr + i
    b = main_bytes[i]
    
    if b == 0xe8 and i + 4 < len(main_bytes):
        offset = int.from_bytes(main_bytes[i+1:i+5], 'little', signed=True)
        target = addr + 5 + offset
        target_name = "?"
        for name, sym_addr in elf.symbols.items():
            if sym_addr == target:
                target_name = name
                break
        for name, plt_addr in elf.plt.items():
            if plt_addr == target:
                target_name = f"{name}@plt"
                break
        print(f"  0x{addr:08x}: e8 {main_bytes[i+1]:02x} {main_bytes[i+2]:02x} {main_bytes[i+3]:02x} {main_bytes[i+4]:02x}  call 0x{target:x} ({target_name})")
        i += 5
    elif b == 0x55:
        print(f"  0x{addr:08x}: 55                    push ebp")
        i += 1
    elif b == 0x89 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xe5:
        print(f"  0x{addr:08x}: 89 e5                 mov ebp, esp")
        i += 2
    elif b == 0x53:
        print(f"  0x{addr:08x}: 53                    push ebx")
        i += 1
    elif b == 0x51:
        print(f"  0x{addr:08x}: 51                    push ecx")
        i += 1
    elif b == 0x83 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xec:
        if i + 2 < len(main_bytes):
            imm = main_bytes[i+2]
            print(f"  0x{addr:08x}: 83 ec {imm:02x}              sub esp, 0x{imm:x}")
            i += 3
        else:
            i += 1
    elif b == 0x81 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xec:
        imm = int.from_bytes(main_bytes[i+2:i+6], 'little')
        print(f"  0x{addr:08x}: 81 ec {main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}{main_bytes[i+5]:02x}      sub esp, 0x{imm:x}")
        i += 6
    elif b == 0x81 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xc3:
        imm = int.from_bytes(main_bytes[i+2:i+6], 'little')
        print(f"  0x{addr:08x}: 81 c3 {main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}{main_bytes[i+5]:02x}      add ebx, 0x{imm:x}")
        i += 6
    elif b == 0x6a:
        imm = main_bytes[i+1]
        print(f"  0x{addr:08x}: 6a {imm:02x}                 push 0x{imm:x}")
        i += 2
    elif b == 0x68:
        imm = int.from_bytes(main_bytes[i+1:i+5], 'little')
        print(f"  0x{addr:08x}: 68 {main_bytes[i+1]:02x}{main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}            push 0x{imm:x}")
        i += 5
    elif b == 0x50:
        print(f"  0x{addr:08x}: 50                    push eax")
        i += 1
    elif b == 0x83 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xc4:
        imm = main_bytes[i+2]
        print(f"  0x{addr:08x}: 83 c4 {imm:02x}              add esp, 0x{imm:x}")
        i += 3
    elif b == 0x8d and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x83:
        imm = int.from_bytes(main_bytes[i+2:i+6], 'little', signed=True)
        print(f"  0x{addr:08x}: 8d 83 {main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}{main_bytes[i+5]:02x}      lea eax, [ebx+0x{imm:x}]")
        i += 6
    elif b == 0x8d and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x45:
        imm = main_bytes[i+2]
        if imm > 0x7f:
            imm = imm - 0x100
        print(f"  0x{addr:08x}: 8d 45 {main_bytes[i+2]:02x}              lea eax, [ebp+0x{imm:x}]")
        i += 3
    elif b == 0x8d and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x4c and main_bytes[i+2] == 0x24:
        imm = main_bytes[i+3]
        print(f"  0x{addr:08x}: 8d 4c 24 {imm:02x}           lea ecx, [esp+0x{imm:x}]")
        i += 4
    elif b == 0x83 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xe4:
        imm = main_bytes[i+2]
        print(f"  0x{addr:08x}: 83 e4 {imm:02x}              and esp, 0x{imm:x}")
        i += 3
    elif b == 0xff and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x71:
        imm = main_bytes[i+2]
        print(f"  0x{addr:08x}: ff 71 {imm:02x}              push [ecx+0x{imm:x}]")
        i += 3
    elif b == 0x83 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xf8:
        imm = main_bytes[i+2]
        print(f"  0x{addr:08x}: 83 f8 {imm:02x}              cmp eax, 0x{imm:x}")
        i += 3
    elif b == 0x75:
        imm = main_bytes[i+1]
        if imm > 0x7f:
            imm = imm - 0x100
        target = addr + 2 + imm
        print(f"  0x{addr:08x}: 75 {main_bytes[i+1]:02x}                 jne 0x{target:x}")
        i += 2
    elif b == 0xeb:
        imm = main_bytes[i+1]
        if imm > 0x7f:
            imm = imm - 0x100
        target = addr + 2 + imm
        print(f"  0x{addr:08x}: eb {main_bytes[i+1]:02x}                 jmp 0x{target:x}")
        i += 2
    elif b == 0xc3:
        print(f"  0x{addr:08x}: c3                    ret")
        i += 1
    elif b == 0xc9:
        print(f"  0x{addr:08x}: c9                    leave")
        i += 1
    elif b == 0x8b and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x83:
        imm = int.from_bytes(main_bytes[i+2:i+6], 'little', signed=True)
        print(f"  0x{addr:08x}: 8b 83 {main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}{main_bytes[i+5]:02x}      mov eax, [ebx+0x{imm:x}]")
        i += 6
    elif b == 0x8b and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x00:
        print(f"  0x{addr:08x}: 8b 00                 mov eax, [eax]")
        i += 2
    elif b == 0x8b and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x5d:
        imm = main_bytes[i+2]
        print(f"  0x{addr:08x}: 8b 5d {imm:02x}              mov ebx, [ebp+0x{imm:x}]")
        i += 3
    elif b == 0xb8:
        imm = int.from_bytes(main_bytes[i+1:i+5], 'little')
        print(f"  0x{addr:08x}: b8 {main_bytes[i+1]:02x}{main_bytes[i+2]:02x}{main_bytes[i+3]:02x}{main_bytes[i+4]:02x}            mov eax, 0x{imm:x}")
        i += 5
    elif b == 0x8d and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x65:
        imm = main_bytes[i+2]
        if imm > 0x7f:
            imm = imm - 0x100
        print(f"  0x{addr:08x}: 8d 65 {main_bytes[i+2]:02x}              lea esp, [ebp+0x{imm:x}]")
        i += 3
    elif b == 0x8d and i + 1 < len(main_bytes) and main_bytes[i+1] == 0x61:
        imm = main_bytes[i+2]
        if imm > 0x7f:
            imm = imm - 0x100
        print(f"  0x{addr:08x}: 8d 61 {main_bytes[i+2]:02x}              lea esp, [ecx+0x{imm:x}]")
        i += 3
    elif b == 0x5b:
        print(f"  0x{addr:08x}: 5b                    pop ebx")
        i += 1
    elif b == 0x5d:
        print(f"  0x{addr:08x}: 5d                    pop ebp")
        i += 1
    elif b == 0x59:
        print(f"  0x{addr:08x}: 59                    pop ecx")
        i += 1
    elif b == 0x89 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xe5:
        print(f"  0x{addr:08x}: 89 e5                 mov ebp, esp")
        i += 2
    elif b == 0x89 and i + 1 < len(main_bytes) and main_bytes[i+1] == 0xeb:
        print(f"  0x{addr:08x}: 89 eb                 mov ebx, ebp")
        i += 2
    else:
        print(f"  0x{addr:08x}: {b:02x}                    ???")
        i += 1
