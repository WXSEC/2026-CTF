from pwn import *

context.log_level = 'debug'

elf = ELF('pwn_permission')

# Disassemble vuln function
log.info("=== Disassembling vuln function ===")
vuln_addr = elf.symbols['vuln']
vuln_data = elf.read(vuln_addr, 200)
for i in range(0, len(vuln_data), 16):
    hex_str = ' '.join(f'{b:02x}' for b in vuln_data[i:i+16])
    log.info(f"0x{vuln_addr + i:x}: {hex_str}")

# Disassemble main function
log.info("\n=== Disassembling main function ===")
main_addr = elf.symbols['main']
main_data = elf.read(main_addr, 300)
for i in range(0, len(main_data), 16):
    hex_str = ' '.join(f'{b:02x}' for b in main_data[i:i+16])
    log.info(f"0x{main_addr + i:x}: {hex_str}")

# Check target_val and x symbols
log.info(f"\ntarget_val address: 0x{elf.symbols['target_val']:x}")
log.info(f"x address: 0x{elf.symbols['x']:x}")

# Read current values
target_val_data = elf.read(elf.symbols['target_val'], 4)
log.info(f"target_val value: {u32(target_val_data)}")

x_data = elf.read(elf.symbols['x'], 4)
log.info(f"x value: {u32(x_data)}")