from pwn import *

elf = ELF('pwn_permission')

# Disassemble using Capstone
try:
    from capstone import Cs, CS_ARCH_X86, CS_MODE_32
    md = Cs(CS_ARCH_X86, CS_MODE_32)
    
    # Disassemble vuln function
    log.info("=== vuln function ===")
    vuln_addr = elf.symbols['vuln']
    vuln_data = elf.read(vuln_addr, 0x49)
    for insn in md.disasm(vuln_data, vuln_addr):
        log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")
    
    # Disassemble main function
    log.info("\n=== main function ===")
    main_addr = elf.symbols['main']
    main_data = elf.read(main_addr, 0x90)
    for insn in md.disasm(main_data, main_addr):
        log.info(f"0x{insn.address:x}:\t{insn.mnemonic}\t{insn.op_str}")
except ImportError:
    log.error("Capstone not installed, trying manual disassembly")
    # Use objdump via subprocess
    import subprocess
    result = subprocess.run(['objdump', '-d', '-M', 'intel', 'pwn_permission'], 
                          capture_output=True, text=True)
    log.info(result.stdout[:5000])