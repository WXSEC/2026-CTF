
from pwn import *

elf = ELF('pwn_permission')

vuln_addr = elf.symbols['vuln']
print(f"vuln函数地址: 0x{vuln_addr:x}")

# 读取vuln函数的字节
vuln_bytes = elf.read(vuln_addr, 0x200)

print("\nvuln函数字节（十六进制）:")
for i in range(0, len(vuln_bytes), 16):
    chunk = vuln_bytes[i:i+16]
    hex_str = ' '.join(f'{b:02x}' for b in chunk)
    print(f'0x{vuln_addr + i:08x}: {hex_str:<48} | {repr("".join(chr(b) if 32<=b<127 else "." for b in chunk))}')
