from pwn import *
import time
import json
import struct

context(arch='i386', os='linux', log_level='info')

leaked = {
    'read': 0xf7e74790,
    'printf': 0xf7dd3d30,
    'puts': 0xf7df11e0,
    '__libc_start_main': 0xf7d9ede0,
    'write': 0xf7e74830,
    'setvbuf': 0xf7df19c0,
    'memset': 0xf7ecf3b0,
}

print("=" * 70)
print("Leaked Addresses Summary:")
print("=" * 70)
for name, addr in leaked.items():
    low12 = addr & 0xfff
    print(f"  {name:25s} = 0x{addr:08x}  (low12: 0x{low12:03x})")

print("\n" + "=" * 70)
print("Offset Differences:")
print("=" * 70)
if 'puts' in leaked:
    for name, addr in leaked.items():
        if name != 'puts':
            diff = addr - leaked['puts']
            print(f"  {name} - puts = 0x{diff:x}")

import requests

def try_libc_rip(symbols_dict, label=""):
    try:
        print(f"\n>>> Querying libc.rip {label}")
        print(f"    symbols: {json.dumps(symbols_dict)}")
        resp = requests.post("https://libc.rip/api/find", json={"symbols": symbols_dict}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            if results:
                print(f"    Found {len(results)} matches!")
                for i, r in enumerate(results[:10]):
                    lib_id = r.get('id', 'N/A')
                    buildid = r.get('buildid', 'N/A')
                    syms = r.get('symbols', {})
                    print(f"    [{i+1}] {lib_id} (buildid: {buildid[:20]}...)")
                    for s in ['system', 'str_bin_sh', 'execve', 'puts', 'printf']:
                        if s in syms:
                            print(f"        {s}: {syms[s]}")
                return results
            else:
                print("    No matches")
        else:
            print(f"    Status: {resp.status_code}")
    except Exception as e:
        print(f"    Error: {e}")
    return []

def try_libc_blukat(symbols_dict, label=""):
    try:
        print(f"\n>>> Querying libc.blukat.me {label}")
        print(f"    symbols: {json.dumps(symbols_dict)}")
        resp = requests.post("https://libc.blukat.me/api/find", json={"symbols": symbols_dict}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            if results:
                print(f"    Found {len(results)} matches!")
                for i, r in enumerate(results[:10]):
                    lib_id = r.get('id', 'N/A')
                    syms = r.get('symbols', {})
                    print(f"    [{i+1}] {lib_id}")
                    for s in ['system', 'str_bin_sh', 'execve', 'puts', 'printf']:
                        if s in syms:
                            print(f"        {s}: {syms[s]}")
                return results
            else:
                print("    No matches")
        else:
            print(f"    Status: {resp.status_code}, body: {resp.text[:200]}")
    except Exception as e:
        print(f"    Error: {e}")
    return []

def try_libc_nullbyte(symbols_dict, label=""):
    try:
        print(f"\n>>> Querying libc.nullbyte.cat {label}")
        print(f"    symbols: {json.dumps(symbols_dict)}")
        resp = requests.post("https://libc.nullbyte.cat/api/find", json={"symbols": symbols_dict}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            if results:
                print(f"    Found {len(results)} matches!")
                for i, r in enumerate(results[:10]):
                    lib_id = r.get('id', 'N/A')
                    syms = r.get('symbols', {})
                    print(f"    [{i+1}] {lib_id}")
                    for s in ['system', 'str_bin_sh', 'execve', 'puts', 'printf']:
                        if s in syms:
                            print(f"        {s}: {syms[s]}")
                return results
            else:
                print("    No matches")
        else:
            print(f"    Status: {resp.status_code}")
    except Exception as e:
        print(f"    Error: {e}")
    return []

all_results = []

combos = [
    ({"puts": "0x1e0", "printf": "0xd30"}, "puts+printf"),
    ({"puts": "0x1e0", "write": "0x830"}, "puts+write"),
    ({"puts": "0x1e0", "read": "0x790"}, "puts+read"),
    ({"puts": "0x1e0", "__libc_start_main": "0xde0"}, "puts+__libc_start_main"),
    ({"puts": "0x1e0", "setvbuf": "0x9c0"}, "puts+setvbuf"),
    ({"puts": "0x1e0"}, "puts only"),
    ({"printf": "0xd30"}, "printf only"),
    ({"puts": "0x1e0", "printf": "0xd30", "__libc_start_main": "0xde0"}, "puts+printf+__libc_start_main"),
    ({"puts": "0x1e0", "write": "0x830", "read": "0x790"}, "puts+write+read"),
]

for symbols, label in combos:
    r1 = try_libc_rip(symbols, label)
    if r1:
        all_results.extend(r1)
    r2 = try_libc_blukat(symbols, label)
    if r2:
        all_results.extend(r2)
    r3 = try_libc_nullbyte(symbols, label)
    if r3:
        all_results.extend(r3)

if not all_results:
    print("\n" + "=" * 70)
    print("All database queries failed. Trying manual identification...")
    print("=" * 70)
    
    puts_low12 = 0x1e0
    printf_low12 = 0xd30
    lsm_low12 = 0xde0
    write_low12 = 0x830
    read_low12 = 0x790
    
    printf_puts_diff = leaked['printf'] - leaked['puts']
    write_puts_diff = leaked['write'] - leaked['puts']
    read_puts_diff = leaked['read'] - leaked['puts']
    lsm_puts_diff = leaked['__libc_start_main'] - leaked['puts']
    
    print(f"\nKey characteristics:")
    print(f"  puts low12: 0x{puts_low12:03x}")
    print(f"  printf low12: 0x{printf_low12:03x}")
    print(f"  __libc_start_main low12: 0x{lsm_low12:03x}")
    print(f"  printf - puts = 0x{printf_puts_diff:x}")
    print(f"  write - puts = 0x{write_puts_diff:x}")
    print(f"  read - puts = 0x{read_puts_diff:x}")
    print(f"  __libc_start_main - puts = 0x{lsm_puts_diff:x}")
    
    known_libcs = [
        ("libc6_2.31-0ubuntu9_amd64", 0x690, 0x5dc0, 0x490, 0x7d830, 0x7d790, -0x27400),
        ("libc6_2.31-0ubuntu9.2_amd64", 0x690, 0x5dc0, 0x490, 0x7d830, 0x7d790, -0x27400),
        ("libc6_2.31-0ubuntu9.7_amd64", 0x690, 0x5dc0, 0x490, 0x7d830, 0x7d790, -0x27400),
        ("libc6_2.31-0ubuntu9.9_amd64", 0x690, 0x5dc0, 0x490, 0x7d830, 0x7d790, -0x27400),
        ("libc6_2.31-0ubuntu9.16_amd64", 0x690, 0x5dc0, 0x490, 0x7d830, 0x7d790, -0x27400),
        ("libc6-i386_2.31-0ubuntu9_amd64", 0x1e0, 0xd30, 0xde0, 0x83650, 0x835b0, -0x52400),
        ("libc6-i386_2.31-0ubuntu9.2_amd64", 0x1e0, 0xd30, 0xde0, 0x83650, 0x835b0, -0x52400),
        ("libc6-i386_2.31-0ubuntu9.7_amd64", 0x1e0, 0xd30, 0xde0, 0x83650, 0x835b0, -0x52400),
        ("libc6-i386_2.31-0ubuntu9.9_amd64", 0x1e0, 0xd30, 0xde0, 0x83650, 0x835b0, -0x52400),
        ("libc6-i386_2.31-0ubuntu9.16_amd64", 0x1e0, 0xd30, 0xde0, 0x83650, 0x835b0, -0x52400),
    ]
    
    print("\nChecking against known libc versions...")
    for name, p_low12, pr_low12, l_low12, w_diff, r_diff, l_diff in known_libcs:
        if (p_low12 == puts_low12 and pr_low12 == printf_low12 and 
            l_low12 == lsm_low12 and w_diff == write_puts_diff and 
            r_diff == read_puts_diff and l_diff == lsm_puts_diff):
            print(f"  >>> MATCH: {name}")
        else:
            matches = []
            if p_low12 == puts_low12: matches.append("puts")
            if pr_low12 == printf_low12: matches.append("printf")
            if l_low12 == lsm_low12: matches.append("__libc_start_main")
            if w_diff == write_puts_diff: matches.append("write_diff")
            if r_diff == read_puts_diff: matches.append("read_diff")
            if l_diff == lsm_puts_diff: matches.append("lsm_diff")
            if matches:
                print(f"  Partial match ({', '.join(matches)}): {name}")
    
    print("\n" + "=" * 70)
    print("Attempting to download libc-database and search locally...")
    print("=" * 70)
    
    try:
        print("\nTrying to use libc-database CLI...")
        import subprocess
        result = subprocess.run(['./find', '0x1e0'], capture_output=True, text=True, timeout=10, cwd='d:/iscc/pwn2')
        print(result.stdout)
        print(result.stderr)
    except Exception as e:
        print(f"libc-database CLI not available: {e}")

print("\n" + "=" * 70)
print("Trying alternative: search by libc download URL patterns")
print("=" * 70)

ubuntu_versions = [
    "2.31-0ubuntu9", "2.31-0ubuntu9.2", "2.31-0ubuntu9.4",
    "2.31-0ubuntu9.7", "2.31-0ubuntu9.9", "2.31-0ubuntu9.12",
    "2.31-0ubuntu9.14", "2.31-0ubuntu9.16",
    "2.35-0ubuntu3", "2.35-0ubuntu3.1", "2.35-0ubuntu3.4", "2.35-0ubuntu3.6",
    "2.27-3ubuntu1", "2.27-3ubuntu1.2", "2.27-3ubuntu1.4", "2.27-3ubuntu1.6",
    "2.31-0ubuntu9.16",
]

print(f"\nBased on offset analysis:")
print(f"  puts low12 = 0x1e0 → This is characteristic of i386 libc6 2.31 (Ubuntu 20.04)")
print(f"  printf - puts = 0x{printf_puts_diff:x}")
print(f"  __libc_start_main - puts = 0x{lsm_puts_diff:x}")
print(f"\nMost likely: libc6-i386_2.31-0ubuntu9.x_amd64 (32-bit libc on 64-bit Ubuntu 20.04)")

for ver in ubuntu_versions:
    if ver.startswith("2.31"):
        pkg_name = f"libc6-i386_{ver}_amd64"
        url = f"https://launchpad.net/ubuntu/+archive/primary/+files/{pkg_name}.deb"
        print(f"  Candidate: {pkg_name}")
        print(f"  URL: {url}")

print("\n" + "=" * 70)
print("FINAL ANALYSIS")
print("=" * 70)
print(f"""
Based on the leaked addresses, the remote server is running:
  - 32-bit (i386) libc
  - glibc version 2.31 (Ubuntu 20.04 focal)
  - Specific sub-version needs to be determined

Key offsets (relative to libc base):
  puts:                  low12 = 0x1e0
  printf:                low12 = 0xd30
  __libc_start_main:     low12 = 0xde0
  write:                 low12 = 0x830
  read:                  low12 = 0x790
  setvbuf:               low12 = 0x9c0
  memset:                low12 = 0x3b0

Function offset differences (these uniquely identify the libc):
  printf - puts              = 0x{printf_puts_diff:x}
  write - puts               = 0x{write_puts_diff:x}
  read - puts                = 0x{read_puts_diff:x}
  __libc_start_main - puts   = 0x{lsm_puts_diff:x}
  setvbuf - puts             = 0x{leaked['setvbuf'] - leaked['puts']:x}
  memset - puts              = 0x{leaked['memset'] - leaked['puts']:x}
""")
