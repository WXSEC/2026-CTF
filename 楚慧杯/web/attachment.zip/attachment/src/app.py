import binascii
import os
import random
import re
import shutil
import sqlite3
import string
import tarfile

from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
)
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, field_validator
from starlette.middleware.sessions import SessionMiddleware

from encrypt import DataEncrypt

app = FastAPI()
DATABASE_DIR = "./databases"
PASSWORD_SET = set()
SALT = "".join(random.choices(string.ascii_letters + string.digits, k=16))
db_files = {
    "customers": "./databases/customers.sqlite",
    "orders": "./databases/orders.sqlite",
    "finances": "./databases/finances.sqlite",
    "projects": "./databases/projects.sqlite",
}

app.add_middleware(
    SessionMiddleware,
    secret_key="".join(random.choices(string.ascii_letters + string.digits, k=128)),
)


templates = Jinja2Templates(directory="templates")


class ProfileUpdate(BaseModel):
    employee_number: str
    email: str
    phone_number: str
    first_name: str
    last_name: str
    date_of_birth: str
    address: str

    @field_validator("employee_number", "phone_number", "first_name", "last_name", "address", mode="before")
    def check_special_characters(cls, v):
        if v and re.search(r"[^\w\s]", v):
            raise HTTPException(400, "您的输入不正确，请重新检查。")
        return v

    @field_validator("date_of_birth", mode="before")
    def validate_date_of_birth(cls, v):
        if not re.match(r"\d{4}-\d{2}-\d{2}", v):
            raise HTTPException(400, "出生日期格式不正确，必须是 YYYY-MM-DD")
        return v


def close_db(conn):
    conn.close()


def admin_required(request: Request):
    username = request.session.get("username")
    if not username:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if username != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    return username


def login_required(request: Request):
    username = request.session.get("username")
    if not username:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return username


def fetch_data_from_db(db_path: str, query: str, params: tuple = ()):
    if os.path.exists(db_path):
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(query, params)
        data = cursor.fetchall()
        conn.close()
        return data
    else:
        raise HTTPException(status_code=404, detail="Database not found")


async def get_registration_data(request: Request):
    if request.headers.get("content-type") == "application/json":
        return await request.json()
    else:
        form_data = await request.form()
        return form_data


@app.on_event("startup")
async def startup_event():
    USER_DATABASE_PATH = "./databases/users.sqlite"
    if os.path.exists(USER_DATABASE_PATH):
        os.remove(USER_DATABASE_PATH)
    conn = sqlite3.connect(USER_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,   
            username TEXT UNIQUE NOT NULL,          
            password TEXT NOT NULL,                 
            employee_number TEXT,            
            email TEXT,                      
            phone_number TEXT,                      
            first_name TEXT,                        
            last_name TEXT,                         
            date_of_birth DATE,                     
            address TEXT,                           
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
        )
    """)
    cursor.execute(
        """
        INSERT INTO users (username, password, employee_number, email, phone_number, first_name, last_name, date_of_birth, address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "admin",
            DataEncrypt().encrypt(
                (SALT + "".join(random.choices(string.ascii_letters + string.digits, k=64))).encode()
            ),
            "A00001",
            "admin@example.com",
            "1234567890",
            "Admin",
            "User",
            "1980-01-01",
            "Admin Street",
        ),
    )

    conn.commit()


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    try:
        conn = sqlite3.connect("./databases/users.sqlite")
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT password FROM users WHERE username = 'admin'
            """,
        )
        if cursor.fetchone()[0] in PASSWORD_SET:
            raise Exception
    except Exception:
        conn.close()
        await startup_event()
    response = await call_next(request)
    return response


@app.get("/", response_class=HTMLResponse)
async def index_page(request: Request):
    if request.session.get("username"):
        return RedirectResponse("/info", status_code=302)
    else:
        return templates.TemplateResponse("index.html", {"request": request})


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@app.post("/register")
async def register(request: Request, data=Depends(get_registration_data)):
    try:
        username = binascii.a2b_hex(data.get("username")).decode("utf-8")
        password = binascii.a2b_hex(data.get("password"))
        employee_number = data.get("employee_number")
        email = data.get("email")
        phone_number = data.get("phone_number")
        first_name = data.get("first_name")
        last_name = data.get("last_name")
        date_of_birth = data.get("date_of_birth")
        address = data.get("address")
        conn = sqlite3.connect("./databases/users.sqlite")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user = cursor.fetchone()

    except Exception:
        raise HTTPException(status_code=500, detail="服务器错误")

    if user:
        raise HTTPException(status_code=400, detail="用户名已存在")
    try:
        enc_password = DataEncrypt().encrypt(SALT.encode() + password)
        PASSWORD_SET.add(enc_password)
        cursor.execute(
            """
            INSERT INTO users ( username, password, employee_number, email, phone_number, first_name, last_name, date_of_birth, address )
            VALUES
                ( ?, ?, ?, ?, ?, ?, ?, ?, ? )
            """,
            (
                username,
                enc_password,
                employee_number,
                email,
                phone_number,
                first_name,
                last_name,
                date_of_birth,
                address,
            ),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise HTTPException(status_code=500, detail="注册失败，可能是工号或邮箱已被注册。")
    finally:
        conn.close()
    request.session["username"] = username
    return {"message": "注册成功"}


@app.post("/login")
async def login(request: Request, data=Depends(get_registration_data)):
    conn = sqlite3.connect("./databases/users.sqlite")
    cursor = conn.cursor()
    try:
        username = binascii.a2b_hex(data.get("username")).decode("utf-8")
        password = binascii.a2b_hex(data.get("password"))
        cursor.execute(f"SELECT password FROM users WHERE username = '{username}'")
        fetch_password = cursor.fetchone()[0]
    except Exception:
        raise HTTPException(status_code=500, detail="不存在的用户")
    finally:
        conn.close()
    if fetch_password == DataEncrypt().encrypt(SALT.encode() + password):
        request.session["username"] = username
        return RedirectResponse("/info", status_code=302)
    else:
        raise HTTPException(status_code=400, detail="密码不正确")


@app.get("/logout")
async def logout(request: Request):
    request.session.pop("username", None)
    return RedirectResponse("/", status_code=302)


@app.get("/api/customers", response_class=HTMLResponse)
async def get_all_customers(request: Request):
    query = "SELECT * FROM customers"
    data = fetch_data_from_db("./databases/customers.sqlite", query)
    if not data:
        raise HTTPException(status_code=404, detail="暂无用户记录")
    return JSONResponse(content=data)


@app.get("/api/orders", response_class=HTMLResponse)
async def get_all_orders(request: Request):
    query = "SELECT * FROM orders"
    data = fetch_data_from_db("./databases/orders.sqlite", query)
    if not data:
        raise HTTPException(status_code=404, detail="暂无订单记录")
    return JSONResponse(content=data)


@app.get("/api/finances", response_class=HTMLResponse)
async def get_all_finances(request: Request):
    query = "SELECT * FROM finances"
    data = fetch_data_from_db("./databases/finances.sqlite", query)
    if not data:
        raise HTTPException(status_code=404, detail="暂无财务记录")
    return JSONResponse(content=data)


@app.get("/api/projects", response_class=HTMLResponse)
async def get_all_projects(request: Request):
    query = "SELECT * FROM projects"
    data = fetch_data_from_db("./databases/projects.sqlite", query)
    if not data:
        raise HTTPException(status_code=404, detail="暂无项目记录")
    return JSONResponse(content=data)


@app.get("/info", response_class=HTMLResponse)
async def info_page(request: Request, username: str = Depends(login_required)):
    try:
        conn = sqlite3.connect("./databases/users.sqlite")
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT username, employee_number, email, phone_number, first_name, last_name, date_of_birth, address 
            FROM users 
            WHERE username = ?
        """,
            (username,),
        )

        user = cursor.fetchone()

        if not user:
            raise HTTPException(status_code=404, detail="用户未找到")

        user_info = {
            "username": user[0],
            "employee_number": user[1],
            "email": user[2],
            "phone_number": user[3],
            "first_name": user[4],
            "last_name": user[5],
            "date_of_birth": user[6],
            "address": user[7],
        }

    except Exception:
        raise HTTPException(status_code=500, detail="数据库查询失败")
    finally:
        conn.close()
    return templates.TemplateResponse("info.html", {"request": request, **user_info})


@app.get("/edit-profile", response_class=HTMLResponse)
async def edit_profile_page(request: Request, username: str = Depends(login_required)):
    try:
        conn = sqlite3.connect("./databases/users.sqlite")
        cursor = conn.cursor()

        cursor.execute(
            """
                SELECT employee_number, email, phone_number, first_name, last_name, date_of_birth, address
                FROM users 
                WHERE username = ?
            """,
            (username,),
        )
        user = cursor.fetchone()

        if not user:
            raise HTTPException(status_code=404, detail="用户未找到")

        user_info = {
            "employee_number": user[0],
            "email": user[1],
            "phone_number": user[2],
            "first_name": user[3],
            "last_name": user[4],
            "date_of_birth": user[5],
            "address": user[6],
        }
    except Exception:
        raise HTTPException(status_code=500, detail="数据库查询失败")
    finally:
        conn.close()

    return templates.TemplateResponse(
        "edit_profile.html",
        {"request": request, "username": username, **user_info},
    )


@app.post("/edit-profile")
async def edit_profile(
    username: str = Depends(login_required),
    profile: ProfileUpdate = Depends(),
):
    try:
        conn = sqlite3.connect("./databases/users.sqlite")
        cursor = conn.cursor()
        cursor.executescript(
            f"""
                UPDATE 
                    users 
                SET
                    employee_number = '{profile.employee_number}',
                    email = '{profile.email}',
                    phone_number = '{profile.phone_number}',
                    first_name = '{profile.first_name}',
                    last_name = '{profile.last_name}',
                    date_of_birth = '{profile.date_of_birth}',
                    address = '{profile.address}'
                WHERE
                    username = '{username}'
            """,
        )

        conn.commit()
    except Exception:
        conn.rollback()
        raise HTTPException(status_code=500, detail="更新个人信息失败")
    finally:
        conn.close()

    return {"message": "个人信息更新成功"}


@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request, username: str = Depends(admin_required)):
    return templates.TemplateResponse("admin.html", {"request": request, "username": username})


@app.get("/admin/backup")
async def backup_databases(username: str = Depends(admin_required)):
    backup_dir = "./backup"
    os.makedirs(backup_dir, exist_ok=True)

    for db_file in os.listdir(DATABASE_DIR):
        if db_file.endswith(".sqlite"):
            db_path = os.path.join(DATABASE_DIR, db_file)
            backup_sql_path = os.path.join(backup_dir, f"{db_file}.sql")

            conn = sqlite3.connect(db_path)
            with open(backup_sql_path, "w", encoding="utf-8") as f:
                for line in conn.iterdump():
                    f.write("%s\n" % line)
            conn.close()

    backup_filename = "db_backup.tar"
    backup_filepath = os.path.join(backup_dir, backup_filename)
    with tarfile.open(backup_filepath, "w") as f:
        for sql_file in os.listdir(backup_dir):
            if sql_file.endswith(".sql"):
                f.add(os.path.join(backup_dir, sql_file), arcname=sql_file)

    return FileResponse(backup_filepath, filename=backup_filename)


@app.post("/admin/restore")
async def restore_databases(
    restore_file: UploadFile = File(...),
    username: str = Depends(admin_required),
):
    if not restore_file.filename:
        raise HTTPException(status_code=400, detail="请上传有效的备份文件")
    if not restore_file.filename.endswith(".tar"):
        raise HTTPException(status_code=400, detail="请上传有效的备份文件")

    backup_dir = "./backup"
    shutil.rmtree(backup_dir, ignore_errors=True)
    os.makedirs(backup_dir, exist_ok=True)
    backup_filepath = os.path.join(backup_dir, "backup.tar")
    with open(backup_filepath, "wb") as f:
        shutil.copyfileobj(restore_file.file, f)

        backup_tar_file = tarfile.open(backup_filepath, "r")
        backup_tar_file.extractall(backup_dir)

    for sql_file in os.listdir(backup_dir):
        if sql_file.endswith(".sql"):
            db_name = sql_file.replace(".sql", "")
            db_path = os.path.join(DATABASE_DIR, db_name)
            os.remove(db_path)
            conn = sqlite3.connect(db_path)
            with open(os.path.join(backup_dir, sql_file), "r", encoding="utf-8") as f:
                conn.executescript(f.read())
            conn.close()

    return {"status": "恢复成功"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=5000,
        reload=True,
        reload_excludes=["./backup/", "./databases/", "./templates/"],
    )
